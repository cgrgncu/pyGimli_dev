#**************************************************************************
#   Name: ERTMaker_SimulateForTimeSeries.py
#   Copyright: 
#   Author: HsiupoYeh
#   Version: v20251031a
#   Description: 讀取 JSON 設定檔，建立電極與包含邊界填充區域的二維地形網格，
#                並設定單元 (Cell) 和邊界 (Boundary) Marker，輸出為
#                PNG, VTK, JSON, GEO, TRN 檔案。
#                必須讀取指定位置「Input_ERTMaker_CreateAndModifyMesh/CreateAndModifyMeshSettings.json」的JOSN檔案。
#                設定檔(CreateAndModifyMeshSettings.json)中有說明各參數意義。
#**************************************************************************
import json
import time
import os
import shutil
import numpy as np
from scipy.interpolate import interp1d
import pygimli as pg
import matplotlib.pyplot as plt
from pygimli.physics import ert
from pygimli.viewer.mpl import drawStreams
#--------------------------------------------
# 程式開始計時
# 使用 time.perf_counter() 進行高精度計時
SCRIPT_START_TIME = time.perf_counter()
#--------------------------------------------
print('--')
print('ERTMaker_SimulateForTimeSeries運作開始!')
#--------------------------------------------
# 軟體說明
ERTMaker_Info = f'ERTMaker v1.0(Author: HsiupoYeh) Powered by PyGIMLi v{pg.__version__}'
print(ERTMaker_Info)
#--------------------------------------------
# 指定檔案名稱
json_file_name = 'Input_ERTMaker_SimulateForTimeSeries/SimulateForTimeSeriesSettings.json'
#--------------------------------------------
# 讀取檔案
# 開啟並讀取 JSON 檔案
print("讀取 .json 檔...")
with open(json_file_name, 'r', encoding='utf-8') as json_file:
    temp_json_data = json.load(json_file)
print("讀取 .json 檔...完成!")
#--------------------------------------------
# 若指定輸出檔案資料夾不存在，則創建資料夾，若存在，則刪除。
#--
# TempFile01_BasicMeshPNG_FileName
temp_foldername=temp_json_data["OutputFolderPath"]
if os.path.exists(temp_foldername):
    # 使用 shutil.rmtree() 遞迴刪除資料夾及其所有內容
    shutil.rmtree(temp_foldername)
os.makedirs(temp_foldername, exist_ok=True)
#--
#--------------------------------------------

#--------------------------------------------
# 建立網格
mesh = pg.Mesh(2)
# 使用計算出的節點座標創建網格
print("讀取 .vtk 檔...")
mesh.load(temp_json_data["InputFile01_MeshVTK_FileName"])
print("讀取 .vtk 檔...完成!")
# 確保正確性，重新計算log10的電阻率
mesh['Resistivity_(log10)'] = np.log10(mesh['Resistivity'])
#--------------------------------------------
# 讀取並設定 MeshBCMarkers
print("讀取 MeshBCMarkersJSON 檔...")
# 開啟並讀取 JSON 檔案
with open(temp_json_data["InputFile02_MeshBCMarkersJSON_FileName"], 'r', encoding='utf-8') as json_file:
    FullMeshMarkers_json_data = json.load(json_file)
print("讀取 MeshBCMarkersJSON 檔...完成!")
#--
# 取出最後一直欄(marker)
markers = [row[-1] for row in FullMeshMarkers_json_data['MeshBCMarkers']]
# 設定 針對每一筆記錄，取出 index 與 marker，設定到對應的 boundary
for entry in FullMeshMarkers_json_data['MeshBCMarkers']:
    indexValue, x1Value, y1Value, x2Value, y2Value, markerValue = entry
    b = mesh.boundaries()[int(indexValue)]
    b.setMarker(int(markerValue))
#--
print(f"網格節點數量 (Mesh Node Count): {mesh.nodeCount()}")
print(f"網格單元數量 (Mesh Cell Count): {mesh.cellCount()}")
print(f"網格邊界數量 (Mesh Boundary Count): {mesh.boundaryCount()}")
#--------------------------------------------
# 讀取Ohm檔案
print("載入OHM檔案...")
# Load data
data = ert.load(temp_json_data["InputFile03_OHM_FileName"])
print("載入OHM檔案...完成!")
# 展示並確認資料內容:
print('觀測資料(ohm檔案)資訊:')
print(data)
#--------------------------------------------
# 展示並儲存(不希望使用互動式視窗，將立即關閉plt) 
# 目前是基礎網格 BasicMeshSetTopoRes
temp_output_filename = os.path.join(temp_json_data['OutputFolderPath'],f'{temp_json_data["Output_MainFileName"]}.png')
temp_PNG_DPI=temp_json_data["MeshPNG_DPI"]
temp_PNG_Width=temp_json_data["MeshPNG_Width"]
temp_PNG_Height=temp_json_data["MeshPNG_Height"]
temp_PNG_Title=temp_json_data["MeshPNG_Title"]
temp_PNG_ColorBarResistivityMin=temp_json_data["MeshPNG_ColorBarResistivityMin"]
temp_PNG_ColorBarResistivityMax=temp_json_data["MeshPNG_ColorBarResistivityMax"]
electrodes_position_array = data.sensors().array()
electrodes_position_x_values = electrodes_position_array[:, 0]
electrodes_position_y_values = electrodes_position_array[:, 1]
electrodes_position_z_values = electrodes_position_array[:, 2]
print('儲存PNG檔案...')
ax, _ = pg.show(mesh, data=mesh['Resistivity_(log10)'], 
    markers=False,
    showMesh=True,
    cMap='jet', 
    cMin=np.log10(temp_PNG_ColorBarResistivityMin),
    cMax=np.log10(temp_PNG_ColorBarResistivityMax),
    label="Resistivity(log10)",
    figsize=(temp_PNG_Width / temp_PNG_DPI, temp_PNG_Height / temp_PNG_DPI), 
    dpi=temp_PNG_DPI)
ax.plot(electrodes_position_x_values, electrodes_position_z_values, 'o', markersize=6, color='magenta', markerfacecolor='magenta', markeredgecolor='black', label='Electrode Nodes')
ax.plot(electrodes_position_x_values[-1], electrodes_position_z_values[-1], 'o', markersize=6, color='lightseagreen', markerfacecolor='lightseagreen', markeredgecolor='black', label='Reference Nodes')
ax.set_title(f'{temp_PNG_Title}\n Electrode_Count={len(electrodes_position_x_values)}, Mesh_Node_Count={mesh.nodeCount()}, Mesh_Cell_Count={mesh.cellCount()} ' ,pad=15)  
ax.set_xlabel('Distance (m)')
ax.set_ylabel('Elevation (m)')
ax.legend(loc='upper right',ncol=2,framealpha=0.4)
ax.figure.text(0.98, 0.01, ERTMaker_Info, 
          ha='right', va='bottom', fontsize=8, color='gray')

# 調整邊界
x_min, x_max = ax.get_xlim()
y_min, y_max = ax.get_ylim()
x_range = x_max - x_min
y_range = y_max - y_min
ax.set_ylim(y_min , y_max + 0.1 * y_range)
#--
plt.tight_layout() 
plt.savefig(temp_output_filename)
plt.close()
print('儲存PNG檔案...完成!')
#-------------------------------------------- 
#--------------------------------------------
# 讀取Current Mode檔案
print("載入CurrentMode檔案...")
# Load data
CurrentMode_array = np.loadtxt(temp_json_data["InputFile04_CurrentMode_FileName"], delimiter=',', dtype=int)
print("載入CurrentMode檔案...完成!")
# 展示並確認資料內容:
print('CurrentMode資訊:')
#print(CurrentMode_array)
CurrentMode_array_channels, CurrentMode_array_events = CurrentMode_array.shape
print(f'頻道數量 = {CurrentMode_array_channels}, 事件數量 = {CurrentMode_array_events}')
#--------------------------------------------
if CurrentMode_array_channels  != 64:
    print("錯誤!頻道數量不是64!")
    exit()
if CurrentMode_array_events % 3 != 0:
    # 執行不符合條件時的操作 (例如：印出錯誤訊息)
    print("錯誤!事件數量不是3的倍數!")
    exit()
#--
# 準備空的想要的AB列表
ElectrodeIndexAB_List = []
# 取出代表性事件
new_CurrentMode_array=CurrentMode_array[:, 0::3].T  
# 迴圈填入AB列表
for event_index, channel_value_array in enumerate(new_CurrentMode_array):
    idx_1 = np.where(channel_value_array == 1)[0]
    if idx_1.size > 0:
        channel_number_1 = idx_1[0] + 1
        #print(f"找到第一個 1 位於頻道: {channel_number_1}")        
    else:
        print('錯誤!找不到目標1。')
        exit()
    idx_2 = np.where(channel_value_array == 2)[0]
    if idx_2.size > 0:
        channel_number_2 = idx_2[0] + 1
        #print(f"找到第一個 2 位於頻道: {channel_number_2}")        
    else:
        print('錯誤!找不到目標2。')
        exit()
    ElectrodeIndexAB_List.append([channel_number_1, channel_number_2])
#print(ElectrodeIndexAB_List)   
# 轉換成np陣列
ab_array=np.array(ElectrodeIndexAB_List)
print(ab_array)
if ab_array.max() > data.sensorCount() :
    print('錯誤!需要使用的放電電極AB數量不夠。請檢查ohm檔案。')
    exit()
#--------------------------------------------
# 運行順推，只計算各感應器位置的電位分布
print('運行順推...')
electric_potential = ert.simulate(mesh, scheme=data, res=mesh['Resistivity'], calcOnly=True, returnFields=True, verbose=False)
print('運行順推...完成!')
#--
# 轉換成np陣列
#electric_potential = np.array(electric_potential)
#--
# 使用 np.save 儲存數據
#output_npy_filename = 'electric_potential_RMatrix_data.npy'
#np.save(output_npy_filename, electric_potential)
#--------------------------------------------
print(f'感應器位置數量: {data.sensorCount()}')
sensor_positions = data.sensorPositions()
print(sensor_positions)
#--------------------------------------------
# Ohm檔案的索引編號是從1開始，PyGimli內建的是從0開始，所以調整一下
if ab_array.size == 0 :
    print('AB陣列數量: 0')
else :
    ab_array=ab_array-1
    print(f'AB陣列數量: {len(ab_array[:,1])}')
#--------------------------------------------
# 依序模擬放電情境
for i_ab_idx, ab in enumerate(ab_array):
    print(f'AB電極對 #{i_ab_idx+1}/{len(ab_array[:,1])} 索引: A={ab[0]+1}(X={sensor_positions[ab[0]][0]:.2f},Z={sensor_positions[ab[0]][2]:.2f}), B={ab[1]+1}(X={sensor_positions[ab[1]][0]:.2f},Z={sensor_positions[ab[1]][2]:.2f})')
    pointA = [sensor_positions[ab[0]][0],sensor_positions[ab[0]][2]]
    pointB = [sensor_positions[ab[1]][0],sensor_positions[ab[1]][2]]
    pointRef = [sensor_positions[-1][0],sensor_positions[-1][2]]
    #--
    potential = electric_potential[ab[0]]-electric_potential[ab[1]]
    #--
    R_AB = temp_json_data['ElectrodeIndexAB_Resistance'] 
    # 計算理論電流
    I_theory = temp_json_data['ElectrodeIndexAB_TxVoltageMax'] / R_AB    
    # 實際輸出電流 I_out 受 I_max 限制 ( 實際電流取 I_max 和 I_theory 中的最小值 )
    I_out = np.minimum(temp_json_data['ElectrodeIndexAB_TxCurrentMax'], I_theory)    
    # 實際輸出電壓 V_out
    V_out = I_out * R_AB  
    #--
    if temp_json_data['Output_PNG_Enable'] == 'Yes' :
        print(f'無窮遠處電位為0[V]時，第{i_ab_idx+1}組電極對，A注入B回收的電位分布圖...')    
        #--------------------------------------------
        # 展示並儲存(不希望使用互動式視窗，將立即關閉plt) 
        # 目前是 CurrentFlowLines AB
        temp_output_filename = os.path.join(temp_json_data['OutputFolderPath'],f'{temp_json_data["Output_MainFileName"]}_CurrentFlowLinesAB_{(i_ab_idx+1):04d}.png')
        ax, _ = pg.show(mesh, data=mesh['Resistivity_(log10)'], 
            markers=False,
            showMesh=True,
            cMap='jet', 
            cMin=np.log10(temp_json_data['MeshPNG_ColorBarResistivityMin']),
            cMax=np.log10(temp_json_data['MeshPNG_ColorBarResistivityMax']),
            label="Resistivity(log10)(Ohm-m)",
            figsize=(temp_json_data['MeshPNG_Width'] / temp_json_data['MeshPNG_DPI'], temp_json_data['MeshPNG_Height'] / temp_json_data['MeshPNG_DPI']), 
            dpi=temp_json_data['MeshPNG_DPI'])
        #--
        # 電流方向與電場梯度相反，提供負的電場梯度
        neg_potential = -potential
        drawStreams(
            ax,
            mesh,
            neg_potential,
            coarseMesh=mesh,
            color='Black'
        )
        #--
        # 繪製所有感應器位置
        ax.plot(
            pg.x(sensor_positions),
            pg.z(sensor_positions), 
            marker="o", 
            linestyle='None', 
            fillstyle='none', 
            color='magenta', 
            markersize=6,
            label='Electrode Nodes')
        # 繪製並標註點 A
        ax.plot(pointA[0], pointA[1], marker=".", color='red', ms=10)
        ax.annotate('A', xy=pointA, ha="center", fontsize=10,
                    bbox=dict(boxstyle="round", fc=(0.8, 0.8, 0.8), ec='red'),
                    xytext=(0, 20), textcoords='offset points',
                    arrowprops=dict(arrowstyle="wedge, tail_width=.5", fc='red', ec='red', patchA=None, alpha=0.75))
        #--
        # 繪製並標註點 B
        ax.plot(pointB[0], pointB[1], marker=".", color='red', ms=10)
        ax.annotate('B', xy=pointB, ha="center", fontsize=10,
                    bbox=dict(boxstyle="round", fc=(0.8, 0.8, 0.8), ec='red'),
                    xytext=(0, 20), textcoords='offset points',
                    arrowprops=dict(arrowstyle="wedge, tail_width=.5", fc='red', ec='red', patchA=None, alpha=0.75))
        #--    
        ax.set_title(f'CurrentFlowLines Map ElectrodePair(AB)#{i_ab_idx+1}/{len(ab_array[:,1])}:\n A=({pointA[0]:.2f},{pointA[1]:.2f}) B=({pointB[0]:.2f},{pointB[1]:.2f}) Tx={V_out}[V]/{I_out}[A] AB_Resistance={R_AB}[Ohm]',pad=15)  
        #--
        ax.set_xlabel('Distance (m)')
        ax.set_ylabel('Elevation (m)')
        ax.legend(loc='upper right',ncol=2,framealpha=0.4)
        ax.figure.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
        #--
        # 調整邊界
        x_min, x_max = ax.get_xlim()
        y_min, y_max = ax.get_ylim()
        x_range = x_max - x_min
        y_range = y_max - y_min
        ax.set_ylim(y_min , y_max + 0.1 * y_range)
        # 存圖
        plt.tight_layout() 
        plt.savefig(temp_output_filename)
        plt.close()
        #--
        print(f'無窮遠處電位為0[V]時，第{i_ab_idx+1}組電極對，A注入B回收的電位分布圖的電流方向圖...繪製完成!')
    #--
    print(f'無窮遠處電位為0[V]時，第{i_ab_idx+1}組電極對，模擬R2MS_Lite量測結果...')
    # 輸出CSV檔案
    temp_output_filename = os.path.join(temp_json_data['OutputFolderPath'],f'{temp_json_data["Output_MainFileName"]}_CurrentFlowLinesAB_{(i_ab_idx+1):04d}.v299S.csv')
    #print('儲存CSV檔案...')
    with open(temp_output_filename, 'w', encoding='utf-8') as f:
        #--
        # 前方固定內容
        f.write('Time[ms](R2MS_Lite_v299csv_v20240510a),Tx_Voltage[V],Rx_Current[A],Mode_Index,Electrode_Status(v/+/-),CH01_Voltage[V],CH01_Current[A],CH02_Voltage[V],CH02_Current[A],CH03_Voltage[V],CH03_Current[A],CH04_Voltage[V],CH04_Current[A],CH05_Voltage[V],CH05_Current[A],CH06_Voltage[V],CH06_Current[A],CH07_Voltage[V],CH07_Current[A],CH08_Voltage[V],CH08_Current[A],CH09_Voltage[V],CH09_Current[A],CH10_Voltage[V],CH10_Current[A],CH11_Voltage[V],CH11_Current[A],CH12_Voltage[V],CH12_Current[A],CH13_Voltage[V],CH13_Current[A],CH14_Voltage[V],CH14_Current[A],CH15_Voltage[V],CH15_Current[A],CH16_Voltage[V],CH16_Current[A],CH17_Voltage[V],CH17_Current[A],CH18_Voltage[V],CH18_Current[A],CH19_Voltage[V],CH19_Current[A],CH20_Voltage[V],CH20_Current[A],CH21_Voltage[V],CH21_Current[A],CH22_Voltage[V],CH22_Current[A],CH23_Voltage[V],CH23_Current[A],CH24_Voltage[V],CH24_Current[A],CH25_Voltage[V],CH25_Current[A],CH26_Voltage[V],CH26_Current[A],CH27_Voltage[V],CH27_Current[A],CH28_Voltage[V],CH28_Current[A],CH29_Voltage[V],CH29_Current[A],CH30_Voltage[V],CH30_Current[A],CH31_Voltage[V],CH31_Current[A],CH32_Voltage[V],CH32_Current[A],CH33_Voltage[V],CH33_Current[A],CH34_Voltage[V],CH34_Current[A],CH35_Voltage[V],CH35_Current[A],CH36_Voltage[V],CH36_Current[A],CH37_Voltage[V],CH37_Current[A],CH38_Voltage[V],CH38_Current[A],CH39_Voltage[V],CH39_Current[A],CH40_Voltage[V],CH40_Current[A],CH41_Voltage[V],CH41_Current[A],CH42_Voltage[V],CH42_Current[A],CH43_Voltage[V],CH43_Current[A],CH44_Voltage[V],CH44_Current[A],CH45_Voltage[V],CH45_Current[A],CH46_Voltage[V],CH46_Current[A],CH47_Voltage[V],CH47_Current[A],CH48_Voltage[V],CH48_Current[A],CH49_Voltage[V],CH49_Current[A],CH50_Voltage[V],CH50_Current[A],CH51_Voltage[V],CH51_Current[A],CH52_Voltage[V],CH52_Current[A],CH53_Voltage[V],CH53_Current[A],CH54_Voltage[V],CH54_Current[A],CH55_Voltage[V],CH55_Current[A],CH56_Voltage[V],CH56_Current[A],CH57_Voltage[V],CH57_Current[A],CH58_Voltage[V],CH58_Current[A],CH59_Voltage[V],CH59_Current[A],CH60_Voltage[V],CH60_Current[A],CH61_Voltage[V],CH61_Current[A],CH62_Voltage[V],CH62_Current[A],CH63_Voltage[V],CH63_Current[A],CH64_Voltage[V],CH64_Current[A]\n')
        #--
        # 組成一列文字
        temp_Electrode_Status='vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv'
        # 要更換的索引
        index_to_change = ab[0]+1
        # 更換為+
        temp_Electrode_Status = temp_Electrode_Status[:index_to_change-1] + '+' + temp_Electrode_Status[index_to_change:]
        # 要更換的索引
        index_to_change = ab[1]+1
        # 更換為-
        temp_Electrode_Status = temp_Electrode_Status[:index_to_change-1] + '-' + temp_Electrode_Status[index_to_change:]
        #--
        # 準備資料        
        delta_V_All = np.zeros(64)
        delta_A_All = np.zeros(64)
        # 修改
        number_to_modify = data.sensorCount()
        if number_to_modify > 64:
            number_to_modify = 64
        for i_idx in range(number_to_modify):
            pointM = [sensor_positions[i_idx][0],sensor_positions[i_idx][2]]
            delta_V_All[i_idx] = potential[mesh.findNearestNode(pg.RVector(pointM))]-potential[mesh.findNearestNode(pg.RVector(pointRef))]
            delta_V_All[i_idx] = delta_V_All[i_idx]*I_out
            if pointM == pointA:
                delta_V_All[i_idx]=0
                delta_A_All[i_idx]=I_out
            if pointM == pointB:
                delta_V_All[i_idx]=0
                delta_A_All[i_idx]=-I_out        
        # 填入
        combined_data_string = ",".join(f"{item:.8f}" for v, a in zip(delta_V_All, delta_A_All) for item in (v, a))
        #--
        # 寫入
        line = f'0.1,{V_out},{I_out},0, {temp_Electrode_Status},{combined_data_string}\n'
        f.write(line)
        line = f'0.2,{V_out},{I_out},0, {temp_Electrode_Status},{combined_data_string}\n'
        f.write(line)
        line = f'0.3,{V_out},{I_out},0, {temp_Electrode_Status},{combined_data_string}\n'
        f.write(line)
        line = f'0.4,{V_out},{I_out},0, {temp_Electrode_Status},{combined_data_string}\n'
        f.write(line)
        line = f'0.5,{V_out},{I_out},0, {temp_Electrode_Status},{combined_data_string}\n'
        f.write(line)
        line = f'0.6,{V_out},{I_out},0, {temp_Electrode_Status},{combined_data_string}\n'
        f.write(line)
        line = f'0.7,{V_out},{I_out},0, {temp_Electrode_Status},{combined_data_string}\n'
        f.write(line)
        line = f'0.8,{V_out},{I_out},0, {temp_Electrode_Status},{combined_data_string}\n'
        f.write(line)
        line = f'0.9,{V_out},{I_out},0, {temp_Electrode_Status},{combined_data_string}\n'
        f.write(line)
        line = f'1.0,{V_out},{I_out},0, {temp_Electrode_Status},{combined_data_string}\n'
        f.write(line)
        #--
        # 組成一列文字
        temp_Electrode_Status='vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv'
        # 要更換的索引
        index_to_change = ab[0]+1
        # 更換為+
        temp_Electrode_Status = temp_Electrode_Status[:index_to_change-1] + '-' + temp_Electrode_Status[index_to_change:]
        # 要更換的索引
        index_to_change = ab[1]+1
        # 更換為-
        temp_Electrode_Status = temp_Electrode_Status[:index_to_change-1] + '+' + temp_Electrode_Status[index_to_change:]
        #--
        # 準備資料        
        delta_V_All = np.zeros(64)
        delta_A_All = np.zeros(64)
        # 修改
        number_to_modify = data.sensorCount()
        if number_to_modify > 64:
            number_to_modify = 64
        for i_idx in range(number_to_modify):
            pointM = [sensor_positions[i_idx][0],sensor_positions[i_idx][2]]
            delta_V_All[i_idx] = potential[mesh.findNearestNode(pg.RVector(pointM))]-potential[mesh.findNearestNode(pg.RVector(pointRef))]
            delta_V_All[i_idx] = -delta_V_All[i_idx]*I_out
            if pointM == pointA:
                delta_V_All[i_idx]=0
                delta_A_All[i_idx]=-I_out
            if pointM == pointB:
                delta_V_All[i_idx]=0
                delta_A_All[i_idx]=I_out        
        # 填入
        combined_data_string = ",".join(f"{item:.8f}" for v, a in zip(delta_V_All, delta_A_All) for item in (v, a))
        #--
        # 寫入
        line = f'1.1,{V_out},{I_out},1, {temp_Electrode_Status},{combined_data_string}\n'
        f.write(line)
        line = f'1.2,{V_out},{I_out},1, {temp_Electrode_Status},{combined_data_string}\n'
        f.write(line)
        line = f'1.3,{V_out},{I_out},1, {temp_Electrode_Status},{combined_data_string}\n'
        f.write(line)
        line = f'1.4,{V_out},{I_out},1, {temp_Electrode_Status},{combined_data_string}\n'
        f.write(line)
        line = f'1.5,{V_out},{I_out},1, {temp_Electrode_Status},{combined_data_string}\n'
        f.write(line)
        line = f'1.6,{V_out},{I_out},1, {temp_Electrode_Status},{combined_data_string}\n'
        f.write(line)
        line = f'1.7,{V_out},{I_out},1, {temp_Electrode_Status},{combined_data_string}\n'
        f.write(line)
        line = f'1.8,{V_out},{I_out},1, {temp_Electrode_Status},{combined_data_string}\n'
        f.write(line)
        line = f'1.9,{V_out},{I_out},1, {temp_Electrode_Status},{combined_data_string}\n'
        f.write(line)
        line = f'2.0,{V_out},{I_out},1, {temp_Electrode_Status},{combined_data_string}\n'
        f.write(line)
        #--
        # 組成一列文字
        temp_Electrode_Status='vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv'
        #--
        # 準備資料        
        delta_V_All = np.zeros(64)
        delta_A_All = np.zeros(64)            
        # 填入
        combined_data_string = ",".join(f"{item:.8f}" for v, a in zip(delta_V_All, delta_A_All) for item in (v, a))
        #--
        # 寫入
        line = f'2.1,{V_out},{I_out},2, {temp_Electrode_Status},{combined_data_string}\n'
        f.write(line)
        line = f'2.2,{V_out},{I_out},2, {temp_Electrode_Status},{combined_data_string}\n'
        f.write(line)
        line = f'2.3,{V_out},{I_out},2, {temp_Electrode_Status},{combined_data_string}\n'
        f.write(line)
        line = f'2.4,{V_out},{I_out},2, {temp_Electrode_Status},{combined_data_string}\n'
        f.write(line)
        line = f'2.5,{V_out},{I_out},2, {temp_Electrode_Status},{combined_data_string}\n'
        f.write(line)
        line = f'2.6,{V_out},{I_out},2, {temp_Electrode_Status},{combined_data_string}\n'
        f.write(line)
        line = f'2.7,{V_out},{I_out},2, {temp_Electrode_Status},{combined_data_string}\n'
        f.write(line)
        line = f'2.8,{V_out},{I_out},2, {temp_Electrode_Status},{combined_data_string}\n'
        f.write(line)
        line = f'2.9,{V_out},{I_out},2, {temp_Electrode_Status},{combined_data_string}\n'
        f.write(line)
        line = f'3.0,{V_out},{I_out},2, {temp_Electrode_Status},{combined_data_string}\n'
        f.write(line)
        #--
    #print('儲存CSV檔案...完成!')
    print(f'無窮遠處電位為0[V]時，第{i_ab_idx+1}組電極對，模擬R2MS_Lite量測結果...完成!') 
    #--    
#--------------------------------------------
# 用迴圈整理要合併的檔案名稱
all_csv_files_list=[]
for i_ab_idx, ab in enumerate(ab_array):
    temp_output_filename = os.path.join(temp_json_data['OutputFolderPath'],f'{temp_json_data["Output_MainFileName"]}_CurrentFlowLinesAB_{(i_ab_idx+1):04d}.v299S.csv')
    all_csv_files_list.append(temp_output_filename)
#--
new_csv_header = None # 用於儲存最終要使用的單一檔頭
new_csv_lines_without_header = [] # 儲存所有檔案的非檔頭內容
# 用迴圈逐個載入並解析檔案
for i_csv_index, csv_file_name in enumerate(all_csv_files_list):
    with open(csv_file_name, 'r', encoding='utf-8') as InputCsvFile:
        for line_index, line in enumerate(InputCsvFile):
            if line_index==0:
                # 檔頭
                new_csv_header=line
            else:
                # 非檔頭內容
                new_csv_lines_without_header.append(line)
#--
# 寫新的合併檔案
temp_output_filename = os.path.join(temp_json_data['OutputFolderPath'],f'{temp_json_data["Output_MainFileName"]}_CurrentFlowLinesAB.v299S.csv')
with open(temp_output_filename, 'w', encoding='utf-8') as OutputCsvFile:
    # 寫入唯一的檔頭
    OutputCsvFile.write(new_csv_header)        
    # 寫入所有收集到的非檔頭內容
    OutputCsvFile.writelines(new_csv_lines_without_header)
#--------------------------------------------
# 用迴圈整理要合併的檔案名稱
if temp_json_data['Output_PNG_Enable'] == 'Yes' :
    all_png_files_list=[]
    for i_ab_idx, ab in enumerate(ab_array):
        temp_output_filename = os.path.join(temp_json_data['OutputFolderPath'],f'{temp_json_data["Output_MainFileName"]}_CurrentFlowLinesAB_{(i_ab_idx+1):04d}.png')
        all_png_files_list.append(temp_output_filename)
    #--
    # 1. 打開第一張圖片，作為 GIF 的「起始幀」
    first_frame = Image.open(all_png_files_list[0])
    # 2. 準備其餘的幀
    frames = []
    for filename in all_png_files_list[1:]:
        img = Image.open(filename)
        frames.append(img)
    # 3. 呼叫 save 函式來建立 GIF
    temp_output_filename = os.path.join(temp_json_data['OutputFolderPath'],f'{temp_json_data["Output_MainFileName"]}_CurrentFlowLinesAB.gif')
    print(f"正在合併 {len(all_png_files_list)} 個幀到 {temp_output_filename}...")
    first_frame.save(
        temp_output_filename,
        format='GIF',
        append_images=frames,   # 附加所有後續幀
        save_all=True,          # 必須為 True 才能儲存所有幀
        duration=1000,          # 設定每幀的持續時間(ms)
        loop=0                  # 設定循環次數， 0=無限循環
    )
    print(f"GIF 創建成功: {temp_output_filename}")    
#--------------------------------------------
print('ERTMaker_SimulateForTimeSeries運作結束!')
SCRIPT_END_TIME = time.perf_counter()
TOTAL_DURATION = SCRIPT_END_TIME - SCRIPT_START_TIME
# 格式化輸出，顯示小時、分鐘和秒
hours = int(TOTAL_DURATION // 3600)
minutes = int((TOTAL_DURATION % 3600) // 60)
seconds = TOTAL_DURATION % 60
print(f'運行花費時間: {hours} 小時 {minutes} 分鐘 {seconds:.4f} 秒')
# --------------------------------------------
print('--')
#--------------------------------------------