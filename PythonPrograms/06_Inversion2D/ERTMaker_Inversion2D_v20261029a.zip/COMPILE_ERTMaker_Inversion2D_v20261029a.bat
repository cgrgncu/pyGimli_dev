..\PythonEnv\Python.exe -m py_compile ERTMaker_Inversion2D_v20261029a.py
PAUSE