..\PythonEnv\Python.exe ERTMaker_Inversion2D_v20261029a.py
PAUSE