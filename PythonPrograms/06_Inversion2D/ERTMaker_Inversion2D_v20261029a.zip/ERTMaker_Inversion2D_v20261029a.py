#**************************************************************************
#   Name: ERTMaker_Inversion2D_v20261029a.py
#   Copyright: 
#   Author: HsiupoYeh
#   Version: v20261029a
#   Description: 讀取 JSON 設定檔，進行逆推運算與繪圖。
#                必須讀取指定位置「Input_ERTMaker_Inversion2D/Inversion2D.json」的JSON檔案。
#                設定檔(Inversion2D.json)中有說明各參數意義。
#                修正錯字(包含變數命名)、修正註解內容。不影響功能，但設定檔的參數名稱有變更。
#   已知問題: PyGIMLi在逆推的部分，無法每次運算得到完全一致的結果。
#             這可能是因為在平行運算（Parallel Processing）中，「浮點數問題」（Float Problem）。
#             主要源於浮點數運算不符合結合律（Non-associativity）。
#             這會導致相同的程式在平行執行時，每次運算的結果可能微小不同，進而引發非確定性（Non-determinism）與數值不穩定性。
#==============================================================================
#   逆推流程與觀念:
#   1.先設計符合實際情況的模型網格，也就是製作mesh。方案1:載入自備網格檔，方案2:用參數自動生成網格(預設生成三角網格)。
#   2.準備資料檔案，也就是製作ohm檔案。包含合理的電極位置，以及觀測資料(可以是實際野外資料也可以是人造資料)。
#   3.程式載入上述兩項重要輸入檔案後會先檢查是否合理:
#   3.1.電極只能在模型網格內。
#   3.2.考慮邊界條件是否正確。預設情況下:
#   3.2.1.編號-2的是混合邊界條件(Mixed Boundary Condition)，模擬電位向無限遠處衰減的行為，常用於「側面與底部邊界」，避免邊界效應。
#   3.2.2.編號-1的是諾依曼邊界條件(Neumann Boundary Condition)，模擬一個不導電的邊界（法向電流通量為零），用於地表。
#   3.2.3.因此，我製作的mesh會保留邊界編號-1給全網格的地表，編號-2給全網格的側面和底部邊界。
#     REF: /doc/user-guide/modelling.md
#         Boundary marker (-1) : surface boundary conditions - pg.core.MARKER_BOUND_HOMOGEN_NEUMANN -> 諾依曼邊界條件(Neumann Boundary Condition)，模擬一個不導電的邊界（法向電流通量為零），用於地表。
#         Boundary marker (-2) : mixed-boundary conditions - pg.core.MARKER_BOUND_MIXED -> 混合邊界條件（Robin 型）用解析解描述電位在網格外圍的衰減，把「無限遠」的貢獻折算成邊界上的通量，因此不必把網格延伸到很遠。
#         Boundary marker ( >= 1 ) : no-flow boundaries  -> 無流量邊界（No-flow），法向電流為零，電流不會流出網格；一般用於網格內部的區域交界。
#   4.整理視電阻率資料，使V/I資料變成視電阻率，或直接取用視電阻率資料。而且只允許正的視電阻率。一般情況下:
#   4.1.從檔案中取得V/I資料，並重新計算幾何因子來計算成視電阻率。因為順推只會算出V/I，所以透過幾何因子算成視電阻率。幾何因子有要注意，預設解析解是水平地層假設才可用，否則建議用數值解，最好可以提供網格。
#   4.2.建議可以從迭代0次來判斷幾何因子是否合適。全網格均質的前提下迭代0次的理論觀測資料視電阻率等於真實電阻率。
#   5.移除小於等於零的視電阻率。理由:
#   5.1.物理上不存在負的電阻率。地球材料的電阻率均為正值，不存在理想導體(電阻率為0)。
#   5.2.因為逆推採用對數轉換(自然對數)，不接受小於等於零的電阻率。順推則維持線性尺度，所以更新的網格數值會以線性尺度儲存，展示時會選擇常用對數(Log10)。
#   6.提供相對誤差。理由:
#   6.1.在pyGimli中逆推的目標函數中有考慮相對誤差作為權重。
#   6.1.1.內建的estimateError函數實作了 LaBrecque et al., 1996b 的誤差模型。
#     REF: LaBrecque, Miletto, Daily, Ramirez & Owen (1996), The effects of noise on Occam's inversion of resistivity tomography data, Geophysics 61, 538–548.
#   6.1.2. 具體的使用策略可參考 Coscia et al., 2011
#     REF: Coscia, I., Greenhalgh, S. A., Linde, N., Doetsch, J., Marescot, L., Günther, T., Vogt, T., & Green, A. G. (2011). 3D crosshole ERT for aquifer characterization and monitoring of infiltrating river water. Geophysics, 76(2), G49–G59. https://doi.org/10.1190/1.3553003
#   6.1.3. PyGimli官方預設使用「3%」，個人解讀:可能來自於文獻應用在某野外案例的有效參數。
#     REF: Günther, T., Rücker, C., & Spitzer, K. (2006). Three-dimensional modelling and inversion of dc resistivity data incorporating topography—II. Inversion. Geophysical Journal International, 166(2), 506-517.
#   6.2.一般而言，如果設定的誤差過低(例如 < 1%)，反演算法會試圖去擬合隨機噪訊，導致模型出現不真實的偽影(Artifacts)。
#   7.逆推問題:是在求解一個受約束的非線性最小平方法問題。要最小化目標函數(Objective Function)，英文代號:Phi。
#   7.1.目標函數(Phi)通常由兩個主要部分組成：
#   7.1.1.資料擬合項(Data Misfit)，英文代號:PhiD。
#   7.1.2.模型平滑項(Model Regularization)，英文代號:PhiM。
#   7.1.3.其中PhiM有一個權重參數lambda。
#   7.1.4.最終目標函數Phi=PhiD+(lambda*PhiM)
#   7.2.先關心PhiD，他的計算是 PhiD = sum( ((obs - cal) / error)^2 ) 這只是觀念式。實際計算，Data會轉到log域，error也會轉到log域，則error_i=log(1+(Relative_Error_i))這就是為什麼前面要準備Relative_Error_i。
#   7.3.再來關心PhiM。在pyGimli實作的意義大概是包含平滑約束(Ctype)、先驗模型(isReference)、透過垂直權重(zWeight)來調整非等向性。
#   7.3.1.一般情況下，這幾項都用預設值就好了。預設值是1階平滑約束(Ctype=1)、不使用先驗模型(isReference=False)、等向性(zWeight=1.0)。
#   7.4.當PhiM決定後，lambda的選擇就成了逆推成功與否的最後關鍵。通常被認為是一種權衡，lambda太小模型將由資料主宰有過擬合的風險；lambda太大模型將過度平滑無法反映細節。
#   7.4.1.pyGimli預設的邏輯是利用統計檢定的卡方值(chi^2 = PhiD/N)來評估lambda。當chi^2=1被認為是最理想的狀態，因為模型既解釋了數據，又沒有去擬合雜訊。
#   7.4.2.但這邏輯在實作上更偏向終止準則。這個準則要有效其實依賴選擇的lambda與Relative_Error。當然若無法終止也是個有用的提示。
#   7.4.3.因此，合理的策略是在有限的時間內產生多幅不同lambda+Relative_Error的圖像，進行決策(選擇最佳模型)。
#   7.4.4.常見的決策建議: 地質合理性(不可以出現違反現實的構造)、卡方值能否接近1、殘差值。
#   7.4.5.作者也建議，未知場址可以先用大的lambda，粗略判斷主要特徵，合理後再降低lambda來看細節。
#   7.4.6.此外，還有個奇妙的lambdaFactor可以用，預設是1.0。允許每次疊代都更換lambda為lambda*lambdaFactor。1.0等於更換成同樣的lambda。
#   7.4.7.也可參考 Coscia et al., 2011 的策略來選擇 lambda 。
#   8.逆推運作的開始與結束。
#   8.1.我們需要一個起始模型來進行逆推，在Pygimli的預設方案中，將選擇一個均質的起始模型，其值為觀測資料的中位數。
#   8.2.因為使用迭代法，必須告訴程式何時該停止，包含:
#   8.2.1.最多幾次疊代(maxIter)，預設值20。若真的有必要可以控制這個。
#   8.2.2.目標函數相對改善百分比(minDPhi，呼叫時為 dPhi；底層 deltaPhiAbortPercent)，預設值 = 2，單位:[%]。通常不提供給使用者修改。
#   8.2.3.卡方值停止疊代(stopAtChi1)，預設值True。當chi^2 <= 1時停止。通常不提供給使用者修改。
#--
#   最終選擇的輸入、輸出為:
#   Input_Mesh_File = Demo_SyntheticModel.vtk
#   Input_MeshBC_File = Demo_SyntheticModelBCMarkers.json
#     邊界編號-1給全網格的地表，混合邊界條件(Mixed Boundary Condition)；編號-2給全網格的側面和底部邊界:混合邊界條件(Mixed Boundary Condition)。
#   Input_Ohm_File = Demo_SyntheticModel.ohm
#     檢查電極在網格內
#     幾何因子利用網格計算出來
#     視電阻率利用幾何因子算出來
#     移除負的視電阻率#     
#   Inversion_Settings_Relative_Error = 0.03
#     設定預估相對誤差，如果不知道資料品質狀態建議設為3%。
#   --
#   建立逆推管理器，管理器設定網格後:
#   Info_mgr_Mesh_All_CellCount = mgr.mesh.cellCount()
#   write_log_append(f"管理器中的網格數量 = {Info_mgr_Mesh_All_CellCount}")
#   Info_mgr_Mesh_Marker1_CellCount = np.sum(mgr.mesh.cellMarkers()==1)
#   write_log_append(f"管理器中的附加區域網格數量(Marker=1) = {Info_mgr_Mesh_Marker1_CellCount}")
#   Info_mgr_Mesh_Marker2_CellCount = np.sum(mgr.mesh.cellMarkers() == 2)
#   write_log_append(f"管理器中的研究區域網格數量(Marker=2) = {Info_mgr_Mesh_Marker2_CellCount}")
#   --
#   管理器初始化逆推參數域後:
#   Info_mgr_predict_H2_Mesh_CellCount = Info_mgr_Mesh_All_CellCount*4
#   write_log_append(f"管理器順推使用的H2網格，預期數量 = {Info_mgr_Mesh_All_CellCount}x4 = {Info_mgr_predict_H2_Mesh_CellCount}")
#   Info_mgr_H2_Mesh_CellCount = mgr.fop.mesh().cellCount()
#   write_log_append(f"管理器順推使用的H2網格，數量 = {Info_mgr_H2_Mesh_CellCount}")
#   --
#   檢視逆推資料與網格健康度
#   Info_Obs_Data_Count = Ohm_data.size()
#   write_log_append(f"輸入的觀測資料數量(Obs_N): {Info_Obs_Data_Count}")
#   Info_FullMesh_Count = mgr.mesh.cellCount()
#   write_log_append(f"全網格數量或稱原始網格數量(FullMesh_N): {Info_FullMesh_Count}")
#   Info_PaddingMesh_Count = sum(mgr.mesh.cellMarkers() == 1)
#   write_log_append(f"附加網格區域網格數量(PaddingMesh_N): {Info_PaddingMesh_Count}")
#   Info_StudyAreaMesh_Count = sum(mgr.mesh.cellMarkers() == 2)
#   write_log_append(f"研究區域網格數量(StudyAreaMesh_N): {Info_StudyAreaMesh_Count}")
#   Info_Obs_Data_Count_to_StudyAreaMesh_Count_ratio = Info_Obs_Data_Count / Info_StudyAreaMesh_Count
#   write_log_append(f"資料與逆推參數比例或稱觀測資料與研究區域網格數量比例(Obs_N/StduyAreaMesh_N): {Info_Obs_Data_Count_to_StudyAreaMesh_Count_ratio}")
#   write_log_append(f"經驗上:「Obs_N/StudyAreaMesh_N < 1.0 」時，資訊不足 (Underdetermined)，可能導致產生斑點形狀的結果。")
#   write_log_append(f"經驗上:「1.0 < Obs_N/StudyAreaMesh_N < 3.0」時，資訊平衡 (Well-posed)，是最有效率的逆推情況，能兼顧地層細節與運算穩定性。 ")
#   write_log_append(f"經驗上:「3.0 < Obs_N/StudyAreaMesh_N」時，資訊非常充足 (Overdetermined)，逆推結果會非常穩定，雜訊會被平均掉，地層邊界較平滑。要注意過量的觀測資料影響運算效率。")
#   write_log_append(f"隱藏的陷阱:即使資訊充足，但其實資料主要影響電極附近，距離遠的網格並不一定受資料影響。")
#   write_log_append(f"經驗上:可以依照資訊不足、資訊平衡、資訊非常充足等不同情況，嘗試合適的lam。例如:資訊非常充足時，可以將lam從預設的20調整至10，降低模型約束(平滑化)的權重。降低lam的同時也請考慮過擬合的問題。")
#   write_log_append(f"過擬合(Over-fitting)警告: 調低 lam 會增加過擬合風險。")
#   write_log_append(f"檢查點 1: 若最終 chi^2 << 1.0，代表模型可能正在擬合雜訊，應調高 lam。")
#   write_log_append(f"檢查點 2: 若電極附近出現不自然的「點狀高/低阻異常」，代表 lam 過低。")
#   --
#   設定逆推參數(終止疊代任務相關)
#   REF: inversion.h
#   Default_maxIter = 20 #預設值20，開放使用者修改，視為必填項目。
#   Default_dPhi = 2 #預設值2，單位[%]，禁止使用者修改。[終止疊代任務門檻]：定義目標函數最小化的「相對改善率」下限。當疊代效益 < 1% 時，視為模型已達穩定狀態，提前終止逆推，防止對噪聲過度擬合。
#   逆推參數(正則化相關)
#   Default_lam = 20 #預設值20，開放使用者修改，視為必填項目。
#   Default_lambdaFactor = 1 #預設值1，禁止使用者修改。
#   Default_isReference = False #預設值關閉，禁止使用者修改。。是否要讓起始模型也同時成為先驗模型。 
#   Default_startModel = None #預設值None，開放使用者修改，視為必填項目。預設值None為觀測資料的中位數，單位:[Ohm-m]。
#   --   
#   逆推參數(資料擬合相關)
#   Default_robustData = False #預設值關閉，禁止使用者修改。。False表示使用一般模式(L2範數)，誤差會被平方，適合資料品質好時可達最佳效果。True表示使用強健模式，誤差會被重新加權，來容忍資料品質不好的離群點多的情況。
#   Default_blockyModel = False #預設值關閉，禁止使用者修改。。False表示空間格子應該像漸層，True表示空間格子像塊狀。
#   逆推參數(過程展示相關)
#   Default_showProgress = True #禁止使用者修改。
#   Default_verbose = True #禁止使用者修改。
#   Default_debug = True #禁止使用者修改。
#   --
#   每次逆推運行完可檢查:
#   Inversion_Iteration_count = mgr.inv.iter
#   write_log_append(f"目前迭代次數: {Inversion_Iteration_count}")
#   Info_Inversion_dataTrans = str(mgr.inv.dataTrans)
#   write_log_append(f"逆推運算資料轉換方式: {Info_Inversion_dataTrans}")
#   Info_Inversion_modelTrans = str(mgr.inv.modelTrans).replace("\n", " -> ")
#   write_log_append(f"逆推運算模型轉換方式: {Info_Inversion_modelTrans}")
#--
#   Info_LastInversion_StartModelMesh_Value = mgr.inv.startModel
#   #write_log_append(f"起始模型網格數值內容: {Info_LastInversion_StartModelMesh_Value}")
#   Info_LastInversion_StartModelMesh_CellCount = len(Info_LastInversion_StartModelMesh_Value)
#   write_log_append(f"起始模型網格數量 = {Info_LastInversion_StartModelMesh_CellCount}")
#   Info_LastInversion_StartModelMesh_Value_Min = np.min(Info_LastInversion_StartModelMesh_Value)
#   Info_LastInversion_StartModelMesh_Value_Max = np.max(Info_LastInversion_StartModelMesh_Value)
#   write_log_append(f"起始模型網格數值(Min/Max) = {Info_LastInversion_StartModelMesh_Value_Min:.2f}/{Info_LastInversion_StartModelMesh_Value_Max:.2f}")
#--
#   Info_LastInversion_ForwordH2ModelMesh_Value = mgr.fop.createMappedModel(mgr.inv.modelHistory[Inversion_Iteration_count]) # 研究區域照填，附加區域延續（prolongated）
#   #write_log_append(f"最後一次迭代的順推H2網格數值內容: {Info_LastInversion_ForwordH2ModelMesh_Value}")
#   Info_LastInversion_ForwordH2ModelMesh_CellCount = len(Info_LastInversion_ForwordH2ModelMesh_Value)
#   write_log_append(f"最後一次迭代的順推H2網格數值數量 = {Info_LastInversion_ForwordH2ModelMesh_CellCount}")
#   Info_LastInversion_ForwordH2ModelMesh_Value_Min = np.min(Info_LastInversion_ForwordH2ModelMesh_Value)
#   Info_LastInversion_ForwordH2ModelMesh_Value_Max = np.max(Info_LastInversion_ForwordH2ModelMesh_Value)
#   write_log_append(f"最後一次迭代的順推H2網格數值(Min/Max) = {Info_LastInversion_ForwordH2ModelMesh_Value_Min:.2f}/{Info_LastInversion_ForwordH2ModelMesh_Value_Max:.2f}")
#   Info_LastInversion_InversionModelMesh_Value = mgr.inv.modelHistory[Inversion_Iteration_count]
#   #write_log_append(f"最後一次迭代的逆推網格數值內容: {Info_LastInversion_InversionModelMesh_Value}")
#   Info_LastInversion_InversionModelMesh_CellCount = len(Info_LastInversion_InversionModelMesh_Value)
#   write_log_append(f"最後一次迭代的逆推網格數量 = {Info_LastInversion_InversionModelMesh_CellCount}")
#   Info_LastInversion_InversionModelMesh_Value_Min = np.min(Info_LastInversion_InversionModelMesh_Value)
#   Info_LastInversion_InversionModelMesh_Value_Max = np.max(Info_LastInversion_InversionModelMesh_Value)
#   write_log_append(f"最後一次迭代的逆推網格數值(Min/Max) = {Info_LastInversion_InversionModelMesh_Value_Min:.2f}/{Info_LastInversion_InversionModelMesh_Value_Max:.2f}")
#   Info_LastInversion_Obs_dataVals = mgr.inv.dataVals
#   #write_log_append(f"最後一次迭代的觀測資料內容: {Info_LastInversion_Obs_dataVals}")
#   Info_LastInversion_Obs_dataVals_Count = len(Info_LastInversion_Obs_dataVals)
#   write_log_append(f"最後一次迭代的觀測資料數量 = {Info_LastInversion_Obs_dataVals_Count}")
#   Info_LastInversion_Obs_dataVals_Min = np.min(Info_LastInversion_Obs_dataVals)
#   Info_LastInversion_Obs_dataVals_Max = np.max(Info_LastInversion_Obs_dataVals)
#   write_log_append(f"最後一次迭代的觀測資料數值(Min/Max) = {Info_LastInversion_Obs_dataVals_Min:.2f}/{Info_LastInversion_Obs_dataVals_Max:.2f}")
#   Info_LastInversion_Obs_errorVals = mgr.inv.errorVals
#   #write_log_append(f"最後一次迭代的觀測資料估計相對誤差內容: {Info_LastInversion_Obs_errorVals}")
#   Info_LastInversion_Obs_errorVals_Count = len(Info_LastInversion_Obs_errorVals)
#   write_log_append(f"最後一次迭代的觀測資料估計相對誤差數量 = {Info_LastInversion_Obs_errorVals_Count}")
#   Info_LastInversion_Obs_errorVals_Min = np.min(Info_LastInversion_Obs_errorVals)
#   Info_LastInversion_Obs_errorVals_Max = np.max(Info_LastInversion_Obs_errorVals)
#   write_log_append(f"最後一次迭代的觀測資料估計相對誤差數值(Min/Max) = {Info_LastInversion_Obs_errorVals_Min:.2f}/{Info_LastInversion_Obs_errorVals_Max:.2f}")
#   Info_LastInversion_response_dataVals = mgr.inv.response
#   #write_log_append(f"最後一次迭代的計算資料內容: {Info_LastInversion_response_dataVals}")
#   Info_LastInversion_response_dataVals_Count = len(Info_LastInversion_response_dataVals)
#   write_log_append(f"最後一次迭代的計算資料數量 = {Info_LastInversion_response_dataVals_Count}")
#   Info_LastInversion_response_dataVals_Min = np.min(Info_LastInversion_response_dataVals)
#   Info_LastInversion_response_dataVals_Max = np.max(Info_LastInversion_response_dataVals)
#   write_log_append(f"最後一次迭代的計算資料數值(Min/Max) = {Info_LastInversion_response_dataVals_Min:.2f}/{Info_LastInversion_response_dataVals_Max:.2f}")
#   Info_LastInversion_Lambda = mgr.inv.lam # 這常常取不到
#   write_log_append(f"最後一次迭代的逆推採用Lambda = {Info_LastInversion_Lambda}")
#   Info_LastInversion_RMS = mgr.inv.absrms()
#   #write_log_append(f"最後一次迭代的RMS = {Info_LastInversion_RMS:.2f}")
#   Info_LastInversion_RRMS = mgr.inv.relrms()
#   #write_log_append(f"最後一次迭代的RRMS = {Info_LastInversion_RRMS:.2f}%")
#   write_log_append(f"最後一次迭代的RMS/RRMS = {Info_LastInversion_RMS:.2f}/{Info_LastInversion_RRMS:.2f}%")
#   Info_LastInversion_chi2 = mgr.inv.chi2()
#   write_log_append(f"最後一次迭代的chi2 = {Info_LastInversion_chi2:.2f}")
#   Info_LastInversion_PhiD = mgr.inv.phiData()
#   #write_log_append(f"最後一次迭代的PhiD = {Info_LastInversion_PhiD:.2f}")
#   Info_LastInversion_PhiM = mgr.inv.phiModel()
#   #write_log_append(f"最後一次迭代的PhiM = {Info_LastInversion_PhiM:.2f}")
#   Info_LastInversion_Phi = mgr.inv.phi()
#   write_log_append(f"最後一次迭代的Phi = PhiD+(lam*PhiM) =: {Info_LastInversion_PhiD:.2f}+({Info_LastInversion_Lambda}*{Info_LastInversion_PhiM:.2f}) = {Info_LastInversion_Phi:.2f}")
#--
# log中的資訊解析:
#==============================================================================
# checkError() - 數據權重安全性檢查與計算
# 核心定義： dweight[i] = 1.0 / error[i]
# REF: https://github.com/gimli-org/gimli/blob/v1.5.4/core/src/inversion.h#L241-L262
#------------------------------------------------------------------------------
# 1. min/max(dweight) = 33.3333/33.3333
# 解讀: 相對誤差倒數的最大最小值。無單位。
#------------------------------------------------------------------------------
#dataWeight_ = 1.0 / tD_->error(fixZero(data_, TOLERANCE), error_);
#
#if (verbose_) std::cout << "min/max(dweight) = " << min(dataWeight_) << "/"
#                          << max(dataWeight_) << std::endl;
#==============================================================================
#==============================================================================
# DC Forward Response & Reciprocity Summary - 電阻率正向模擬與互換性摘要
# REF: https://github.com/gimli-org/gimli/blob/v1.5.4/core/src/bert/dcfemmodelling.cpp#L1140-L1191
#------------------------------------------------------------------------------
# 1. Response: min = 78.2413 max = 114.529 mean = 95.6784
# 解讀: 理論資料的最大最小與平均值。單位Ohm-m。
#--
# 2. Reciprocity rms(modelReciprocity) 0.224131%, max: 0.755323%
# 解讀: 理論上，根據互換定理（Reciprocity Theorem），正向與反向測量的結果應該完全相同。
#       數值意義: 在有限元素法 (FEM) 模擬中，由於網格離散化，兩者會有些微差距。
#       建議評價: < 1% = 代表數值模擬非常精確，網格密度 (Mesh density) 足夠。
#                 > 5% ：代表網格可能太粗糙，或電極附近的網格剖分不當，模擬結果不可信。
#==============================================================================
#==============================================================================
# tau (τ) 步長品質 - Line Search 結果
# REF: https://github.com/gimli-org/gimli/blob/v1.5.4/core/src/inversion.h#L615-L675
#      https://github.com/gimli-org/gimli/blob/v1.5.4/core/src/inversion.cpp#L356-L366
#------------------------------------------------------------------------------
# 1. Performing line search with tau = 1
# 解讀: tau 是本次模型更新的步長比例 (0.03 ~ 1.0)，由 line search 求出。
#       tau >= 0.95 : 採全步 (直接使用 tau=1 的模型，不再額外正演)。
#       tau = 1.0   : 通常代表 Phi 單調下降、全步最佳；
#                     也可能是拋物線擬合 > 1.0 被截斷的結果 (inversion.h L656-657)。
#       0.03 <= tau < 0.95 : 部分步長，更新較保守但屬正常修正。
#       tau < 0.03  : 先嘗試拋物線搜尋；若仍 < 0.03 則強制設為 0.03
#                     (log: "tau < 0.03 ==> tau = 0.03")，代表該步幾乎無法降低 Phi。
# 若持續出現 tau = 0.03：建議檢查 Data Error 是否給太小，或提高 Lambda 穩定反演。
# (關閉 line search 時 tau 固定 1.0，此行不會印出)
#==============================================================================
#==============================================================================
# 迭代數據的詳細解讀 (以第 3 次迭代為例)
# REF: https://github.com/gimli-org/gimli/blob/v1.5.4/core/src/inversion.h#L495-L509
#      https://github.com/gimli-org/gimli/blob/v1.5.4/core/src/vectortemplates.h#L243-L247
#------------------------------------------------------------------------------
# 3: Model: min = 45.2478; max = 196.671
# 解讀: 反演得到的地下電阻率範圍。單位：Ohm-m。
# 3: Response: min = 78.1385; max = 114.57
# 解讀: 當前模型產生的視電阻率響應範圍。單位：Ohm-m。
# 3: rms/rrms(data, Response) = 1.36746/1.52795%
# 解讀: 不考慮Log轉換，不考慮誤差權重。
#    - rms  : 即 AbsRMS (絕對均方根殘差)，平均每個點差了 1.37 Ohm-m。
#    - rrms : 相對百分比誤差。1.52% 代表擬合得非常好。
# 3: chi^2(data, Response, error, log) = 0.253918
# 解讀: 考慮Log轉換。考慮誤差權重。
#    - 關鍵判定: 
#      * chi^2 << 1 (如 0.25): 代表「過度擬合 (Overfitting)」。
#      * 原因: 你的 Data Error 給得太大，或者 Lambda 太小。
#      * 影響: 算法會試圖去擬合雜訊，導致模型出現不自然的碎裂。
# 3: Phi = 165.301 + 7.10985 * 20 = 307.497
# 解讀: 總目標函數 (Total Objective Function)。
#    - 165.301 : PhiD (Data misfit) - 數據項。
#    - 7.10985 : PhiM (Model roughness) - 模型項。
#    - 20      : Lambda (Regularization strength) - 正則化權重。
#------------------------------------------------------------------------------
#void echoStatus(const Vec & response, const Vec & model, const std::string & xtra = "") const {
#        double chi2 = getPhiD(response) / data_.size();
#        std::cout << iter_ << ": " << xtra
#                  << "Model: min = " << min(model) << "; max = " << max(model) << std::endl;
#        std::cout << iter_ << ": " << xtra
#                  << "Response: min = " << min(response) << "; max = " << max(response) << std::endl;
#        std::cout << iter_ << ": rms/rrms(data, " << xtra << "Response) = "
#                        << rms(data_, response) << "/"
#                        << rrms(data_, response) * 100.0 << "%" << std::endl;
#        std::cout << iter_ << ": chi^2(data, " << xtra
#                  << "Response, error, log) = " << chi2 <<        std::endl;
#        std::cout << iter_ << ": Phi = " << getPhiD(response) << "+" << getPhiM(model)
#                            << "*" << lambda_ << "=" << getPhi(model, response) << std::endl;
#    }
#==============================================================================
#==============================================================================
# 反演進度監控 (Convergence Monitoring) - 詳細解讀
# REF: https://github.com/gimli-org/gimli/blob/v1.5.4/pygimli/frameworks/inversion.py#L514-L573
#------------------------------------------------------------------------------
# 核心指標： dPhi (總目標函數下降率)
# 公式： dphi = (1 - (phi / lastPhi)) * 100
#------------------------------------------------------------------------------
# 註解說明：
# 1. phi: 當前迭代計算出的總目標函數值 (Total Objective Function)。
# 2. lastPhi: 上一次迭代的總目標函數值。
# 3. dphi : 該次迭代讓目標函數「改善了多少百分比」。範例： dphi=10%。代表這次更新進步了 10%。
# ------------------------------------------------------------------------------
#phi = self.phi()
#dPhi = phi / lastPhi
#
#if self.verbose:
#    print("chi² = {:7.2f} (dPhi = {:.2f}%) lam: {:.1f}".format(
#        chi2, (1 - dPhi) * 100, self.lam))
#==============================================================================
#==============================================================================
# chi^2 = 其實是正規化卡方值，要有效的關鍵就是選到正確的相對誤差。
# 程式碼的計算幾乎就是PhiD/N
# REF: https://github.com/gimli-org/gimli/blob/v1.5.4/pygimli/frameworks/inversion.py#L221-L234
# ------------------------------------------------------------------------------
# Chi-squared (Normalized) Formula:
#             1      N  /  trans(data[i]) - trans(response[i]) \ 2
# Chi^2 =   -----   SUM | ------------------------------------ |
#             N     i=1 \           error_trans[i]             /
# ------------------------------------------------------------------------------
# 註解說明：
# 1. data : 觀測數據向量 (Observed data vector)
# 2. response : 模型響應向量 (Model response / Predicted data)
# 3. N     : 數據點總數 (Total number of data points)
# 4. error : 使用者設定的誤差門檻 (Relative Error)
# 4. 特點  : 使用預期誤差 (error) 當分母 -> 衡量「擬合是否達到誤差預期」。考慮使用者設定的相對誤差 (relativeError)。
# 5. 輸出  : 純量 (Scalar)。
# 6. 判斷準則：
#    - Chi^2 = 1 : 擬合剛好達到你的誤差預期。
#    - Chi^2 > 1 : 擬合不足 (誤差估太小，或模型不足以描述資料)。
#    - Chi^2 < 1 : 殘差小於假設誤差；可能是過度擬合 (誤差估得正確時)，
#                  也可能是相對誤差估得偏大 (保守)，此時模型反而偏平滑。
# ------------------------------------------------------------------------------
#    def chi2(self, response=None):
#        """Chi-squared misfit (mean of squared error-weighted misfit)."""
#        return self.phiData(response) / len(self.dataVals)
#==============================================================================
#==============================================================================
# PhiD (PhiData) = 目標函數的資料約束項 = 誤差權重殘差的平方和
# error-weighted misfit就是residual/error_trans
# REF: https://github.com/gimli-org/gimli/blob/v1.5.4/pygimli/frameworks/inversion.py#L225-L234
#      https://github.com/gimli-org/gimli/blob/v1.5.4/core/src/trans.h#L82-L86
# ------------------------------------------------------------------------------
# 
#              N  /  trans(data[i]) - trans(response[i])  \ 2
# PhiData =   SUM | ------------------------------------ |
#             i=1 \           error_trans[i]             /
#
# ------------------------------------------------------------------------------
# 註解說明：
# 1. N             : 數據點總數 (Total number of data points)。
# 2. i             : 第 i 個數據點的索引。
# 3. data[i]       : 觀測到的原始數據值 (Observed data value)。
# 4. response[i]   : 模型產生的響應值 (Model response / Predicted data)。
# 5. trans()       : 轉換函數 (Data Transformation)。
#                    - 通常為 Log-transformation (logTrans)。ERT 固定使用 TransLogLU(0, 0)，等同不做截斷的 log 轉換(ertManager.py L57)。
#                    - 目的：縮小動態範圍，使反演對高、低電阻率同樣敏感。
# 6. error_trans[i]: 轉換後的誤差權重 (Transformed Error)。
#                    - 定義: error_trans[i] = | data[i] * relError[i] * trans'(data[i]) |  (trans.h L82-86)。
#                    - log 轉換時 trans'(d) = 1/d -> error_trans = relError。
#                    - 意義：對這筆數據的不信任程度；分母越大，該點對目標函數影響越小。
# 7. 與 chi^2 的關係: chi^2 = PhiData / N (PhiData 本身是平方和，沒有除以 N)。
# ------------------------------------------------------------------------------
# def phiData(self, response=None):
#     """Return data objective function (sum of squared error-weighted misfit)."""
#     if response is None:
#         response = self.response
#
#     dT = self.dataTrans
#     dData = (dT.trans(self.dataVals) - dT.trans(response)) / \
#         dT.error(self.dataVals, self.errorVals)
#
#     return pg.math.dot(dData, dData)
#==============================================================================
#==============================================================================
# PhiM (PhiModel) = 模型正則化項 (regularization term) = 粗糙度的平方和
# REF: https://github.com/gimli-org/gimli/blob/v1.5.4/pygimli/frameworks/inversion.py#L1169-L1175 (ERT 實際使用)
#      https://github.com/gimli-org/gimli/blob/v1.5.4/pygimli/frameworks/inversion.py#L236-L254 (InversionBase 版本，僅供對照)
#      https://github.com/gimli-org/gimli/blob/v1.5.4/core/src/inversion.h#L554-L563
#------------------------------------------------------------------------------
# 概念: 對 modelTrans(model) 做一階差分 (梯度) 後取平方和，數值越大代表模型越粗糙。
#       反演目標是讓總目標函數變小，因此本項的作用是抑制粗糙 -> 傾向平滑模型。
# 組成: rough = cWeight * C · ( modelTrans(model) * modelWeight )
#       - C           : 約束矩陣 (constraint matrix)，相鄰網格的一階差分
#       - modelWeight : 各區域的模型權重 (C++ 版才有；Python 版沒有)
#       - cWeight     : 約束權重 (constraintWeights)
#       - ERT 的 modelTrans 為 log 轉換，所以是在 log(電阻率) 空間計算梯度
# 與 Lambda 的關係: Phi = PhiD + Lambda * PhiM
#       - Lambda 越大 -> PhiM 的比重越大 -> 更強力地懲罰粗糙 -> 模型更平滑
#       - Lambda 越小 -> 越強調資料擬合 -> 模型細節多，但可能出現碎裂
# 註: 1.5.4 的 ERT 走 ClassicInversion，phiModel() 呼叫的是 C++ 的
#     self.inv.roughness(model)，即 inversion.h L554-563 這一版，
#     有 reference model 時會扣除 constraintsH_ (L559-561)。
#     但 reference model 預設不存在 (haveReferenceModel_ = false)，
#     只有 run() 收到 isReference=True 才會設定 (inversion.py L1411-1413)；
#     ERTManager.invert() 未預設開啟 (僅 ertIPManager / timelapse 會設為 True)。
#     因此在「無 reference model 且各區域 modelWeight 皆為 1」時，
#     C++ 與 Python 版結果相同。
# ------------------------------------------------------------------------------
#------------------------------------------------------------------------------
# Python 版相關程式碼 (目前不採用, InversionBase L236-254)
#------------------------------------------------------------------------------
# def roughness(self, model=None, weighted=True):
#     modelVector = self.modelTrans(model)
#     pureRoughness = self.fop.constraints().mult(modelVector)
#     if weighted:
#         return self.cWeight * pureRoughness
#
# def phiModel(self, model=None):
#     rough = self.roughness(model, weighted=True)
#     return pg.math.dot(rough, rough)
#------------------------------------------------------------------------------
# C++ 版相關程式碼 (目前採用, ClassicInversion -> self.inv.roughness, inversion.h L554-563)
#------------------------------------------------------------------------------
# RVector roughness(const RVector & model) const {
#     RVector r(*forward_->constraints()
#                * Vec(tM_->trans(model) * modelWeight_)
#                * constraintWeights_);
#
#     if (haveReferenceModel_) {
#         r = r - constraintsH_;
#     }
#     return r;
# }
#
# // ClassicInversion.phiModel (inversion.py L1169-1175)
# def phiModel(self, model=None):
#     if model is None:
#         model = self.model
#     rough = self.inv.roughness(model)      # C++
#     return pg.math.dot(rough, rough)
#------------------------------------------------------------------------------
#==============================================================================
#==============================================================================
# Phi = 完整的目標函數 = PhiD + (Lambda * PhiM)
# REF: https://github.com/gimli-org/gimli/blob/v1.5.4/pygimli/frameworks/inversion.py#L1177-L1183
#------------------------------------------------------------------------------
# 說明:
# - PhiD    : 資料約束項 (誤差權重殘差平方和)
# - PhiM    : 模型正則化項 (粗糙度平方和)
# - Lambda  : 正則化權重 (C++ 的 lambda_，此處用 self.inv.getLambda() 取得)
# - localRegularization 為 True 時只回傳 PhiD (Marquardt 類型，正則化另外處理)；
#   ERT 預設為 False，所以正常情況就是 PhiD + Lambda * PhiM。
# ------------------------------------------------------------------------------
# def phi(self, model=None, response=None):
#     """Total objective function (phiD + lambda * phiM)."""
#     phiD = self.phiData(response)
#     if self.inv.localRegularization():
#         return phiD
#     else:
#         return phiD + self.phiModel(model) * self.inv.getLambda()
#==============================================================================
#==============================================================================
# RRMS = 相對方均根殘差 (Relative Root Mean Square)，不考慮誤差權重
# REF: https://github.com/gimli-org/gimli/blob/v1.5.4/pygimli/frameworks/inversion.py#L1185-L1187 (ERT 實際使用)
#      https://github.com/gimli-org/gimli/blob/v1.5.4/pygimli/frameworks/inversion.py#L267-L269 (InversionBase 版本，僅供對照)
#      https://github.com/gimli-org/gimli/blob/v1.5.4/core/src/inversion.h#L609-L612
#      https://github.com/gimli-org/gimli/blob/v1.5.4/core/src/vectortemplates.h#L243-L247
#      https://github.com/gimli-org/gimli/blob/v1.5.4/pygimli/utils/base.py#L13-L22
#------------------------------------------------------------------------------
# RRMS (Relative Root Mean Square) Formula:
#
#            _______________________________________________________
#           /   1     N  /  | data[i] - response[i] |  \ 2
# RRMS =   /  -----  SUM | ------------------------     |   * 100%
#        \/     N    i=1 \      | data[i]|             /
#
# ------------------------------------------------------------------------------
# 註解說明：
# 1. data     : 觀測數據向量 (Observed data vector)
# 2. response : 模型響應向量 (Model response / Predicted data)
# 3. N        : 數據點總數 (Total number of data points)
# 4. 特點     : 客觀百分比指標，不考慮使用者設定的相對誤差 (relativeError)。
# 5. 輸出     : 純量 (Scalar)。
# 6. 單位     : % (僅 C++ 版；Python 版回傳分數，需自行 *100)
# ------------------------------------------------------------------------------
#------------------------------------------------------------------------------
# Python 版相關程式碼 (目前不採用, InversionBase L267-269 + utils/base.py L13-22)
#------------------------------------------------------------------------------
# def relrms(self):
#     """Relative root-mean-square misfit of the last run."""
#     return pg.math.rrms(self.data, self.response)      # 回傳分數，未 *100
#
# def rrms(a, b, axis=None):
#     """Compute the relative (regarding a) root mean square."""
#     return rms(np.abs(a-b)/np.abs(a), axis)
#
# def rms(v, axis=None):
#     """Compute the root mean square."""
#     return np.sqrt(np.mean(np.abs(v)**2, axis))
#------------------------------------------------------------------------------
# C++ 版相關程式碼 (目前採用, ClassicInversion -> self.inv.relrms, inversion.h L609-612)
#------------------------------------------------------------------------------
# // ClassicInversion.relrms (inversion.py L1185-1187)
# def relrms(self):
#     """Relative root-mean-square misfit of the last run."""
#     return self.inv.relrms()      # C++，已 *100，回傳即為 %
#
# // inversion.h L609-612
# inline double absrms() const { return rms(data_, response_); }
# inline double relrms() const { return rrms(data_, response_) * 100.; }
#
# // vectortemplates.h L243-247
# template < class Vec > double rms(const Vec & a) { return std::sqrt(mean(square(a))); }
# template < class Vec > double rms(const Vec & a, const Vec & b) { return rms(a - b); }
# template < class Vec > double rrms(const Vec & a, const Vec & b) { return rms((a - b) / a); }
#
# // 其中 mean(x) = sum(x)/x.size()，square(x) = x*x (逐元素)
#------------------------------------------------------------------------------
#==============================================================================
#==============================================================================
# ABSRMS = 絕對方均根殘差 (Absolute Root Mean Square)，也被簡單稱作 RMS
# REF: https://github.com/gimli-org/gimli/blob/v1.5.4/pygimli/frameworks/inversion.py#L1189-L1191 (ERT 實際使用)
#      https://github.com/gimli-org/gimli/blob/v1.5.4/pygimli/frameworks/inversion.py#L271-L273 (InversionBase 版本，僅供對照)
#      https://github.com/gimli-org/gimli/blob/v1.5.4/core/src/inversion.h#L609-L612
#      https://github.com/gimli-org/gimli/blob/v1.5.4/core/src/vectortemplates.h#L243-L247
#------------------------------------------------------------------------------
# AbsRMS (Absolute Root Mean Square) Formula:
#
#            _________________________________________________
#           /   1     N
# AbsRMS = /  -----  SUM ( data[i] - response[i] ) ^ 2
#        \/     N    i=1
#
# ------------------------------------------------------------------------------
# 註解說明：
# 1. data     : 觀測數據向量 (Observed data vector)
# 2. response : 模型響應向量 (Model response / Predicted data)
# 3. N        : 數據點總數 (Total number of data points)
# 4. 特點     : 不考慮使用者設定的相對誤差 (relativeError)。不進行歸一化。
# 5. 輸出     : 純量 (Scalar)。
# 6. 單位     : 與原始數據 (data) 單位完全相同 (例如 Ohm-m)。
# ------------------------------------------------------------------------------
#------------------------------------------------------------------------------
# Python 版相關程式碼 (目前不採用, InversionBase L271-273)
#------------------------------------------------------------------------------
# def absrms(self):
#     """Absolute root-mean-square misfit of the last run."""
#     return pg.math.rms(self.data, self.response)
#
# // 註: pg.math 是 pygimli.core.math (C++ 綁定)，不是 utils.base 的 numpy 版；
# //     pg.math.rms(a, b) 等同 C++ 的 rms(a - b)。
#------------------------------------------------------------------------------
# C++ 版相關程式碼 (目前採用, ClassicInversion -> self.inv.absrms, inversion.h L609-L612)
#------------------------------------------------------------------------------
# // ClassicInversion.absrms (inversion.py L1189-1191)
# def absrms(self):
#     """Absolute root-mean-square misfit of the last run."""
#     return self.inv.absrms()
#
# // inversion.h L609-612
# inline double absrms() const { return rms(data_, response_); }
# inline double relrms() const { return rrms(data_, response_) * 100.; }
#
# // vectortemplates.h L243-247
# template < class Vec > double rms(const Vec & a) { return std::sqrt(mean(square(a))); }
# template < class Vec > double rms(const Vec & a, const Vec & b) { return rms(a - b); }
# template < class Vec > double rrms(const Vec & a, const Vec & b) { return rms((a - b) / a); }
#
# // 其中 mean(x) = sum(x)/x.size()，square(x) = x*x (逐元素)
#------------------------------------------------------------------------------
#==============================================================================
#==============================================================================
# Jacobian矩陣，簡稱J矩陣。公式代號J_ij。
# REF: https://github.com/gimli-org/gimli/blob/v1.5.4/core/src/modellingbase.cpp#L66 (ModellingBase::init_)
#      https://github.com/gimli-org/gimli/blob/v1.5.4/core/src/inversion.cpp#L62-L82 (RInversion::checkJacobian)
#      https://github.com/gimli-org/gimli/blob/v1.5.4/core/src/modellingbase.cpp#L332-L355 (ModellingBase::createJacobian 進入點)
#      https://github.com/gimli-org/gimli/blob/v1.5.4/core/src/modellingbase.cpp#L292-L330 (brute force，目前不採用)
#      https://github.com/gimli-org/gimli/blob/v1.5.4/core/src/bert/dcfemmodelling.cpp#L1446-L1475 (DCMultiElectrodeModelling::createJacobian，目前採用)
#      https://github.com/gimli-org/gimli/blob/v1.5.4/core/src/bert/dcfemmodelling.cpp#L1245-L1305 (prepareJacobianT_ 子電位)
#      https://github.com/gimli-org/gimli/blob/v1.5.4/core/src/bert/dcfemmodelling.cpp#L1318-L1328 (createJacobian_)
#      https://github.com/gimli-org/gimli/blob/v1.5.4/core/src/bert/bertJacobian.cpp#L268-L442 (createSensitivityCol 互易/敏感度)
# REF (互易法計算敏感度 / Jacobian):
# 1. McGillivray, P.R. & Oldenburg, D.W. (1990): Methods for calculating Fréchet
#    derivatives and sensitivities for the non-linear inverse problem:
#    A comparative study. Geophysical Prospecting, 38(5), 499-524.
# 2. Rücker, C., Günther, T. & Spitzer, K. (2006): Three-dimensional modelling
#    and inversion of DC resistivity data incorporating topography - I. Modelling.
#    Geophysical Journal International, 166(2), 495-505.
# 3. Rücker, C., Günther, T. & Wagner, F.M. (2017): pyGIMLi: An open-source
#    library for modelling and inversion in geophysics.
#    Computers & Geosciences, 109, 106-123.
#------------------------------------------------------------------------------
# J_ij矩陣的Rows(例如651，i = 1, 2, ..., 651)：每一橫列必須對應一筆觀測數據（Data Container 中的量測點）。
# J_ij矩陣的Cols(例如4200，j = 1, 2, ..., 4200)：每一直行必須對應一個反演網格（Model 空間）。
# Jacobian矩陣的元素計算公式 (J_ij):
#
#              dData[i,j]       ( response_Change[i,j] - response_NoChange[i] )
#    J[i,j] = ------------ = ---------------------------------------------------
#              dModel[j]        ( model_Change[j] - model_NoChange[j] )
#
#    * where i = 1, 2, ..., 651 (Index of Data)
#    * where j = 1, 2, ..., 4200 (Index of Model Cell)
#
# J_ij矩陣結構:
#
#         [ J_1,1    J_1,2    ...   J_1,4200   ]  -- 觀測資料 #1
#         [ J_2,1    J_2,2    ...   J_2,4200   ]  -- 觀測資料 #2
#    J =  [  ...      ...     ...     ...      ]
#         [ J_651,1  J_651,2  ...   J_651,4200 ]  -- 觀測資料 #651
#            |        |               |
#          網格 1   網格 2          網格 #4200
#
#--
# 矩陣尺寸在網格與資料集不變時固定。初次計算時 J 矩陣為空 (0x0)，
# checkJacobian() 比對 rows/cols 與 data/model 數量不符，所以會強制重新計算。
# 另外 recalcJacobian_ 預設為 true，因此每次迭代 (iter > 1) 也會重算 J，不是只算一次。
#--
# J = d(rhoa)/d(rho)，兩者同為 [Ohm-m]，故 J_ij 的單位是 [Ohm-m]/[Ohm-m] = 無單位。
# 不論暴力法或子電位法，回傳的都是同一個量。
#--
#預設值
#void ModellingBase::init_() {
#    regionManager_      = new RegionManager(verbose_);
#    regionManagerInUse_ = false;
#
#    // __MS("ModellingBase::init_: " << this <<  " rm:" << regionManager_)
#
#    mesh_               = 0;
#    jacobian_           = 0;
#    constraints_        = 0;
#    dataContainer_      = 0;
#
#    nThreads_           = min(8, numberOfCPU()-2);
#    nThreadsJacobian_   = 1;
#
#    ownJacobian_        = false;
#    ownConstraints_     = false;
#    ownRegionManager_   = true;
#
#    initJacobian();
#    initConstraints();
#}
#--
# 觸發點: 某個函數呼叫這個
#void RInversion::checkJacobian(bool force) {
#
#    if ((forward_->jacobian()->rows() == data_.size() &&
#        forward_->jacobian()->cols() == model_.size()) && !force) return;
#
#    if (verbose_ &&
#            (forward_->jacobian()->rows() != data_.size() ||
#                forward_->jacobian()->cols() != model_.size())
#        ){
#        std::cout << "check Jacobian: wrong dimensions: "
#                    << "(" << forward_->jacobian()->rows()  << "x" << forward_->jacobian()->cols() << ") should be "
#                    << "(" << data_.size() << "x" << model_.size()  << ") " << " force: " << force << std::endl;
#        std::cout << "jacobian size invalid, forced recalc: " << force << std::endl;
#    }
#
#    Stopwatch swatch(true);
#    if (verbose_) std::cout << "Calculating Jacobian matrix (forced=" << force << ")...";
#    forward_->createJacobian(model_);
#    jacobiNeedRecalc_ = false;
#    if (verbose_) std::cout << "... " << swatch.duration(true) << " s" << std::endl;
#}
#------------------------------------------------------------------------------
# brute force 暴力法相關程式碼 (目前不採用, ModellingBase::createJacobian)
# REF: https://github.com/gimli-org/gimli/blob/v1.5.4/core/src/modellingbase.cpp#L292-L330
#------------------------------------------------------------------------------
# 主要進入點forward_->createJacobian(model_)
#void ModellingBase::createJacobian(const RVector & model){
#    RVector resp;
#    if (nThreadsJacobian_ > 1){
#        resp = response_mt(model);
#    } else {
#        resp = response(model);
#    }
#
#    if (!jacobian_){
#        this->initJacobian();
#    } else {
#        jacobian_->clear();
#    }
#    RMatrix *J = dynamic_cast< RMatrix * >(jacobian_);
#    if (J->rows() != resp.size()){
#        J->resize(resp.size(), model.size());
#    }
#
#    if (nThreadsJacobian_ > 1){
#        return createJacobian_mt(model, resp);
#    } else {
#        return createJacobian(model, resp);
#    }
#}
#--
#去呼叫createJacobian(model, resp)
# 採用「brute force」也就是暴力法。使網格數值增加到1.05倍，這個當dModel。然後去順推再算dData，最後得到J。
# 例如:
# 有4200個網格(cols=4200，公式J_ij的j)，作為原始網格。進行順推模擬取得該次651個response_NoChange，觀測資料有651個(row=651，公式J_ij的i)。
# 接著將跑迴圈(4200次)，每次從原始網格修改一個網格model_NoChange成為擾動網格model_Change，再次進行順推模擬取得該次651個response_Change。
# 該次的651個response_Change拿去與原始網格的原始651個response_NoChange抓去算該次651個J。公式J=(response_Change-response_NoChange) / (model_Change-model_NoChange)。
# 意義上就是，問物理引擎：「如果只有這格調升5%，地表 651 個觀測站看到的電壓會變多少？」
# 跑完之後就會產生row x cols = 651 x 4200的J矩陣
# 成本: 需要 model.size() + 1 次正演 (此例 4201 次)。
#void ModellingBase::createJacobian(const RVector & model,
#                                   const RVector & resp){
#    if (verbose_) std::cout << "Create Jacobian matrix (brute force) ...";
#
#    Stopwatch swatch(true);
#    double fak = 1.05;
#
#    if (!jacobian_){
#        this->initJacobian();
#    }
#    RMatrix *J = dynamic_cast< RMatrix * >(jacobian_);
#    if (J->rows() != resp.size()){ J->resize(resp.size(), model.size()); }
#
#    for (size_t i = 0; i < model.size(); i++) {
#        RVector modelChange(model);
#        modelChange[i] *= fak;
#
#        RVector respChange(response(modelChange));
#
#        if (::fabs(modelChange[i] - model[i]) > TOLERANCE){
#            J->setCol(i, (respChange - resp) / (modelChange[i] - model[i]));
#        } else {
#            J->setCol(i, RVector(resp.size(), 0.0));
#        }
#
#//         __MS(i << " " << min(J->col(i)) << " " << max(J->col(i)))
#
#//         for (size_t j = 0; j < resp.size(); j++){
#//             if (::fabs(modelChange[i] - model[i]) > TOLERANCE){
#//                 (*J)[j][i] = (respChange[j] - resp[j]) / (modelChange[i] - model[i]);
#//             } else {
#//                 (*J)[j][i] = 0.0;
#//             }
#//         }
#    }
#
#    swatch.stop();
#    if (verbose_) std::cout << " ... " << swatch.duration() << " s." << std::endl;
#}
#------------------------------------------------------------------------------
# 子電位 + 互易法相關程式碼 (目前採用, DCMultiElectrodeModelling::createJacobian)
# REF: https://github.com/gimli-org/gimli/blob/v1.5.4/core/src/bert/dcfemmodelling.cpp#L1245-L1305
#      https://github.com/gimli-org/gimli/blob/v1.5.4/core/src/bert/dcfemmodelling.cpp#L1318-L1328
#      https://github.com/gimli-org/gimli/blob/v1.5.4/core/src/bert/dcfemmodelling.cpp#L1446-L1475
#      https://github.com/gimli-org/gimli/blob/v1.5.4/core/src/bert/bertJacobian.cpp#L268-L442
#------------------------------------------------------------------------------
# // dcfemmodelling.cpp L1446-1475 (實數分支)
# void DCMultiElectrodeModelling::createJacobian(const RVector & model){
#     ...
#     RMatrix * u = this->prepareJacobianT_(model);    // 子電位 (subpotentials)
#     ...
#     RMatrix * J = dynamic_cast< RMatrix * >(jacobian_);
#     this->createJacobian_(model, *u, J);             // 子電位 + 互易 -> 敏感度
# }
#
# // dcfemmodelling.cpp L1245-1305 (節錄)
# Matrix<ValueType> * DCMultiElectrodeModelling::prepareJacobianT_(const Vector<ValueType> & model){
#     this->searchElectrodes_();
#     if (dataContainer_){
#         if (!subSolutions_){
#             subpotOwner_ = true;
#             subSolutions_ = new Matrix<ValueType>;
#             // std::cout << "Creating new subpotentials for createJacobian."
#         } else {
#             // std::cout << "Using existing subpotentials for createJacobian."
#         }
#         Matrix<ValueType> *u = dynamic_cast<Matrix<ValueType>*>(subSolutions_);
#         if (u->rows() == 0){
#             ...
#             this->calculate(tmp);       // 一次正演，得到各電極的子電位場
#             ...
#         }
#         return u;
#     }
# }
#
# // dcfemmodelling.cpp L1318-1328 (節錄)
# void DCMultiElectrodeModelling::createJacobian_(const RVector & model,
#                                                 const RMatrix & u, RMatrix * J){
#     createSensitivityCol(*J, *mesh_, this->dataContainer(), u,
#                          weights_, kValues_,
#                          matrixClusterIds, nThreads_, verbose_);
# }
#
# 特徵:
# 1. 先求各電極的子電位場 u（prepareJacobianT_），log 會印
#    "Using existing subpotentials for createJacobian."。
# 2. 再用 u 依互易定理組合出每個網格對每筆資料的敏感度
#    (createSensitivityCol)，乘上幾何因子 k 後得到 d(rhoa)/d(rho)。
# 3. 成本與電極數有關 (每根電極一次正演)，不需要 model.size() 次正演，
#    因此 4200 個網格不會變成 4201 次計算。
# 4. 回傳的仍是 d(rhoa)/d(rho)，單位同為無單位。
#==============================================================================
#==============================================================================
# 覆蓋度coverage與標準化覆蓋度standardizedCoverage:
# REF: https://github.com/gimli-org/gimli/blob/v1.5.4/pygimli/frameworks/methodManager.py#L901-L911
#      https://github.com/gimli-org/gimli/blob/v1.5.4/core/src/bert/bertJacobian.cpp#L569-L598
#      https://github.com/gimli-org/gimli/blob/v1.5.4/pygimli/viewer/showmesh.py#L525-L528
#      https://github.com/gimli-org/gimli/blob/v1.5.4/pygimli/viewer/mpl/colorbar.py#L532-L576
#------------------------------------------------------------------------------
# coverage利用J矩陣，再透過網格面積、網格電阻率、觀測資料進行歸一化算出的覆蓋度。
# 長度 = 網格數 (即 J 矩陣的直行數)，不是與 J 矩陣同尺寸。
# 覆蓋率應用在繪圖中會產生漸漸變化的感覺。
#                     /   covTrans[j]   \
#    Coverage = log10 |   -----------   |
#                     \   cellSize[j]   /
# 這是由 pg.core.coverageDCtrans(J, 1/d, 1/m) 計算出來的結果：
#
#                  651    |          Model[j] |
#    covTrans[j] = SUM    | J[i,j] * -------- |
#                  i=1    |          Data[i]  |
#
# 註: C++ 實作 (bertJacobian.cpp L569-598) 對 J 的元素取 abs，
#     最後再除以 abs(1/model) = |model|，故實際是
#     covTrans[j] = ( SUM_i |J[i,j] / data[i]| ) * |model[j]|。
#
# 標準化覆蓋度standardizedCoverage則是用某個門檻再調整為0或1的內容。長度與 coverage 相同。
# 標準化覆蓋度覆蓋率應用在繪圖中會產生銳利切割的感覺。
#                                   {  1.0  ,  if  abs(coverage()) >  threshold(預設0.01)
#   standardizedCoverage (0或1)  =  {
#                                   {  0.0  ,  if  abs(coverage()) <= threshold(預設0.01)
# 註: 1.5.4 的 coverage() 回傳 log10 值，取 abs 後幾乎都遠大於 0.01，
#     所以 standardizedCoverage 實務上幾乎全部為 1 (全不透明)，參考價值有限。
#
# 使用pg.show繪圖的時候，Coverage轉換成透明度，使用addCoverageAlpha
# (coverage 為純量時則直接 set_alpha(coverage))
# addCoverageAlpha 統計門檻判定 (dropThreshold 預設 0.4)：
#   - 計算所有網格 Coverage 的直方圖 (50 bins) 與累計分佈 (CDF)。
#   - mi = CDF 首次超過 2% 的位置。
#   - ma = CDF 最後一次仍低於 40% 的位置。
#   - 若 min(C) < 0 或 max(C) > 1 或 max(C) < 0.5，才進行下列映射。
#   - C = (C - mi) / (ma - mi)，再將 < 0 設為 0.0、> 0.95 設為 1.0。
# 繪圖效果為漸層到變透明:
#   - 低於 mi (最低約 2%)：完全透明 (Alpha = 0)。
#   - mi 到 ma (約 2% ~ 40%)：線性映射，Alpha 由 0 漸增到 1。
#   - 高於 ma (約 40% 以上)：Alpha = 1 (完全不透明)。
#   - 因此不是「塗白 60%」，而是「塗白最低 2%，2~40% 漸層，40% 以上全清楚」。
# 隱藏的解讀問題與風險:
#   - 相對性偏誤：這套邏輯是「相對比較」而非「絕對正確」。
#     無論資料好壞，程式都會把最低約 2% 的網格塗成全透明，
#     並以 40% 百分位當成「全清楚」的起點。
#     這可能導致解釋者誤以為「清楚的地方一定可信」。
#   - 網格規模陷阱：當反演範圍 (Mesh) 劃分得極為巨大時，外圍存在大量靈敏度趨近於 0 的無效網格。
#     這些「垃圾網格」會把 40% 百分位 (ma) 拉低，導致原本只有普通靈敏度的網格
#     也全部超過 ma，被顯示為完全不透明。
#     讓使用者誤以為探測深度變深了，產生「探測良好」的錯覺。
#   - 若清楚的區域非常多且邊界突兀，表示覆蓋率分佈極端 (例如訊號只集中在地表極淺層)，
#     解釋變得非常危險。
#--
#def coverage(self):
#    """Coverage vector considering the logarithmic transformation."""
#    covTrans = pg.core.coverageDCtrans(self.fop.jacobian(),
#                                       1.0 / self.inv.response,
#                                       1.0 / self.inv.model)
#    nCells = self.fop.paraDomain.cellCount()
#    return np.log10(covTrans[:nCells] / self.fop.paraDomain.cellSizes())
#
#def standardizedCoverage(self, threshold=0.01):
#    """Return standardized coverage vector (0|1) using thresholding."""
#    return 1.0*(abs(self.coverage()) > threshold)
#
#RVector coverageDCtrans(const MatrixBase & S, const RVector & dd, const RVector & mm) {
#    RVector cov;
#
#    if (S.rows() > 0) {
#        cov.resize(S.cols(), 0.0);
#    } else {
#        std::cout << "Sensmatrix invalid" << std::endl;
#    }
#
#    if (S.rtti() == GIMLI_MATRIX_RTTI){
#        const RMatrix *Sl = dynamic_cast < const RMatrix * >(&S);
#
#        for (size_t i = 0; i < S.rows(); i ++) {
#            cov += abs((*Sl)[i] * dd[i]);
#        }
#    } else if (S.rtti() == GIMLI_SPARSE_MAP_MATRIX_RTTI){
#
#        const RSparseMapMatrix * Sl = dynamic_cast < const RSparseMapMatrix * >(&S);
#
#        for (RSparseMapMatrix::const_iterator it = Sl->begin(); it != Sl->end(); it ++){
#            Index row = (*it).first.first;
#            Index col = (*it).first.second;
#            cov[col] += (*it).second * dd[row];
#        }
#    } else {
#        CERR_TO_IMPL
#    }
#
#    return cov / abs(mm);
#}
#--
#def showMesh(mesh, data=None, block=False, colorBar=None,
#             label=None, coverage=None, ax=None, savefig=None,
#             showMesh=False, showBoundary=None, factor=1,
#             markers=False, **kwargs):
#中間略...
#
#    if coverage is not None:
#        if isinstance(coverage, (float, int)):
#            gci.set_alpha(coverage)
#        elif len(data) == len(coverage) == mesh.cellCount():
#            addCoverageAlpha(gci, coverage,
#                             dropThreshold=kwargs.pop('dropThreshold', 0.4))
#        else:
#            pg.error('Coverage needs to be either of type float or an array',
#                     'with the same length as data and mesh.cellCount().')
#            # addCoverageAlpha(gci, pg.core.cellDataToPointData(mesh,
#            #                                                   coverage))
#後面略...
#--
#def addCoverageAlpha(patches, coverage, dropThreshold=0.4):
#    """Add alpha values to the colors of a polygon collection.
#
#    Parameters
#    ----------
#
#    patches : 2D mpl mappable
#
#    coverage : array
#        coverage values. Maximum coverage mean no opaqueness.
#
#    dropThreshold : float
#        relative minimum coverage
#    """
#    patches.set_antialiaseds(True)
#    # generate individual color values here
#    patches.update_scalarmappable()
#
#    cols = patches.get_facecolor()
#
#    C = np.asarray(coverage)
#
#    if (np.min(C) < 0.) | (np.max(C) > 1.) | (np.max(C) < 0.5):
#
#        nn, hh = np.histogram(C, 50)
#        nnn = nn.cumsum(axis=0) / float(len(C))
#
#        mi = hh[np.min(np.where(nnn > 0.02)[0])]
#
#        if np.min(nnn) > dropThreshold:
#            ma = np.max(C)
#        else:
#            ma = hh[np.max(np.where(nnn < dropThreshold)[0])]
#
#        C = (C - mi) / (ma - mi)
#        C[np.where(C < 0.)] = 0.0
#        C[np.where(C > 0.95)] = 1.0
#
#    import matplotlib as mpl
#    from packaging import version
#
#    if version.parse(mpl.__version__) >= version.parse("3.4"):
#        patches.set_alpha(C)
#        patches.set_snap(True)
#    else:
#        cols[:, 3] = C
#        patches.set_facecolors(cols)
#
#    if hasattr(patches, 'ax'):
#        updateAxes(patches.ax)
#    elif hasattr(patches, 'get_axes'):
#        updateAxes(patches.get_axes())
#==============================================================================
#==============================================================================
# 相對殘差百分比: Relative_Misfit_Percentage (%)  (自行計算，非 pyGIMLi 內建)
# Relative_Misfit_Percentage = np.abs((mgr.inv.response - data['rhoa']) / data['rhoa']) * 100
#------------------------------------------------------------------------------
# 1. mgr.inv.response : 最後一次逆推的模型響應 (計算出的 rhoa)，單位 Ohm-m。
# 2. data['rhoa']     : 觀測視電阻率，單位 Ohm-m。
# 3. 分母為觀測值 (不是響應值)，與 pyGIMLi 的 rrms(a,b)=rms((a-b)/a) 一致。
# 4. 輸出為向量，長度等於資料筆數 (ERT 資料的 rhoa 恆為正，不需處理除零)。
#------------------------------------------------------------------------------
# 定位說明:
# - 這是物理/解釋上常用的「逐筆相對殘差」，用來檢視哪幾筆資料擬合較差
#   (例如找出離群點、決定 Remove_Data 的門檻)。
# - pyGIMLi 並沒有把這個逐點公式包裝成函式；它只提供聚合後的
#   absrms()、rrms()、relrms()，也就是「單一純量」的版本。
# - 因此本行屬於自行計算的分析用公式，不屬於 pyGIMLi 的既有輸出。
#------------------------------------------------------------------------------
# 與 pyGIMLi 的 RRMS 關係:
#   RRMS = sqrt( mean( Relative_Misfit_Percentage^2 ) )
#   mean(RMP) <= RRMS (均方根會放大大殘差的權重，兩者不相等)
#------------------------------------------------------------------------------
# REF (僅供對照 pyGIMLi 的聚合版本):
# https://github.com/gimli-org/gimli/blob/v1.5.4/core/src/vectortemplates.h#L243-L247
# https://github.com/gimli-org/gimli/blob/v1.5.4/core/src/inversion.h#L609-L612
# https://github.com/gimli-org/gimli/blob/v1.5.4/pygimli/frameworks/inversion.py#L1185-L1191
#==============================================================================
#==============================================================================
# 目標函數變化比值: dPhi = current_Phi / last_Phi
# REF: https://github.com/gimli-org/gimli/blob/v1.5.4/pygimli/frameworks/inversion.py#L550-L555
#------------------------------------------------------------------------------
# 1. current_Phi : 本次迭代算出的總目標函數 (PhiD + Lambda * PhiM)。
# 2. last_Phi    : 上一次迭代的總目標函數 (迴圈尾端才更新，故為相鄰兩次比較)。
# 3. dPhi        : 比值，不是百分比。
#                  dPhi = 1 -> 沒有變化
#                  dPhi < 1 -> Phi 下降
#                  dPhi > 1 -> Phi 上升
# 4. 下降百分比: dphi[%] = (1 - dPhi) * 100 (log 印出的就是這個值)。
# 5. 注意: 不要和 mgr.invert(..., dPhi=2) 的參數混淆，
#          那個是 minDPhi，單位是 %，用來判斷「改善是否小於門檻」而中止。
#==============================================================================
#==============================================================================
# 網格設計參考:
# REF: https://github.com/gimli-org/gimli/blob/v1.5.4/pygimli/meshtools/polytools.py#L881-L968
#      https://github.com/gimli-org/gimli/blob/v1.5.4/pygimli/meshtools/polytools.py#L986-L1046
#------------------------------------------------------------------------------
#def createParaMeshPLC(sensors, paraDX=1, paraDepth=-1, paraBoundary=2,
#                      paraMaxCellSize=0.0, boundary=-1, boundaryMaxCellSize=0,
#                      balanceDepth=True,
#                      isClosed=False, addNodes=1, **kwargs):
#中間略...
#    eSpacing = kwargs.pop('eSpacing', sensors[0].distance(sensors[1]))
#    paraBound = eSpacing * paraBoundary
#
#    if paraDepth <= 0.0:
#        paraDepth = 0.4 * (xMax - xMin)
#中間略...
#    if boundary < 0:
#        boundary = 4
#
#    bound = abs(xMax - xMin) * boundary
#下面略...
#--
# 預設情況下，先決定參數域深度為測線水平長度的 0.4 倍。
# paraBoundary 的單位是「電極間距的倍數」，故參數域左右各再外擴
# paraBound = eSpacing * paraBoundary (預設 2 倍間距)。
# boundary 再往外擴 bound = 測線長 * 4，且左右各加一次。
#
# 因此:
#   參數域 (marker 2) 寬 = 測線長 + 2 * paraBound
#   參數域 (marker 2) 深 = paraDepth
#   全網格 (marker 1) 寬 = 測線長 + 2 * paraBound + 2 * bound
#   全網格 (marker 1) 深 = paraDepth + bound
#
# 例如:測線長 100 公尺、電極間距 5 公尺，則
#   paraBound = 2 * 5 = 10 公尺
#   bound     = 100 * 4 = 400 公尺
#   參數域: 寬 120 公尺，深 40 公尺，標註 Marker 2。
#   全網格: 寬 120 + 800 = 920 公尺，深 40 + 400 = 440 公尺，標註 Marker 1。
#
# ⚠ 危險: eSpacing 只取「最前面兩隻電極」的距離
#    eSpacing = kwargs.pop('eSpacing', sensors[0].distance(sensors[1]))
#    eSpacing 只被用在 paraBound = eSpacing * paraBoundary 這一行，
#    若電極非等間距，參數域左右外擴量只反映第一格的間距:
#      - 第一格特別小 -> 參數域邊界會貼近外側電極，邊界效應變明顯。
#      - 第一格特別大 -> 參數域左右留白過多，浪費網格。
#    需要時可自行指定 eSpacing=...，或把 paraBoundary 調大以保守處理。
#
# 並標註邊界:
#   Boundary marker (-1) : surface boundary conditions - pg.core.MARKER_BOUND_HOMOGEN_NEUMANN
#                          (地表與左右上緣)
#   Boundary marker (-2) : mixed-boundary conditions - pg.core.MARKER_BOUND_MIXED
#                          (底部與下方側邊)
#
# paraDX 預設 1，走的是 paraDX >= 0.5 分支，會在兩電極之間插入一個中點節點。
# addNodes 只在 addNodes > 1 時才有作用，預設 1 等於不額外增點。
#
# balanceDepth 表示模型最底下是平坦的 (取兩端較深者)。
# isClosed 預設 False，為開放幾何 (地表在上、無上邊界)；
# isClosed=True 時改用 createPolygon 建封閉多邊形 (marker=1、boundary=-1)，
# 不會產生參數域 (marker 2)。
#==============================================================================
#**************************************************************************
import json
import os
import shutil
import numpy as np
from datetime import datetime
import pygimli as pg
#--------------------------------------------
from pygimli.physics import ert
#--
# 因為「ert.show」函數不安全，某些陣列判定會出錯。
# 使用動態「猴子補丁」技術，重寫該函數並覆蓋。
#--
# 定義安全版函數
def safe_generateConfStr(yy, switch=False):
    mO, mT = 100, 10000
    types = ['PP', 'PD', 'DP', 'WA', 'SL', 'DD']
    yy = np.atleast_1d(yy)
    typ_indices = np.round(yy // mT).astype(int)
    
    if switch:
        dip = yy % mO
        spac = np.round(yy // mO) % mO
    else:
        spac = yy % mO
        dip = np.round(yy // mO) % mO

    rendd = (np.mean(spac / (dip + 1)) < 2.1)
    keys = []
    for s, d, t in zip(spac, dip, typ_indices):
        #-----------------------------
        # 核心修正：加入索引合法性檢查
        if 0 <= t < len(types):
            key = types[t]
        else:
            key = f"UNK{int(t)}"
        #-----------------------------  
        if d > 0:
            if rendd and d + 1 == s and t == 5:
                key = 'WB'
            else:
                key = key + str(int(d + 1)) + '-'
        key = key + f"{int(s):2d}"
        keys.append(key)
    return keys
#--
# 直接修改路徑下的函數指標
ert.visualization.generateConfStr = safe_generateConfStr
#--------------------------------------------
import matplotlib.pyplot as plt
def init_log():
    print("--- 工作任務啟動 ---")
    with open("ERTMaker_Inversion2D.log", "w", encoding="utf-8") as f:
        f.write("--- 工作任務啟動 ---\n")
def write_log_append(message):
    print(message)
    with open("ERTMaker_Inversion2D.log", "a", encoding="utf-8") as f:
        f.write(str(message) + "\n")
#--------------------------------------------
# 取得運行開始時間
program_start_time = datetime.now()
#--------------------------------------------
init_log()
#--------------------------------------------
# 版本資訊
VERSION_STR = 'v20261029a'
# 提示畫面
write_log_append('************************************************************')
write_log_append(f'* ERTMaker_Inversion2D_{VERSION_STR}')
write_log_append('* Author: HsiupoYeh')
write_log_append(f'* Version: {VERSION_STR}')
write_log_append('************************************************************')
# 軟體說明
ERTMaker_Info = f'ERTMaker v1.0(Author: HsiupoYeh) Powered by PyGIMLi v{pg.__version__}'
write_log_append(ERTMaker_Info)
#--
write_log_append(f"程式開始運行...時間: {program_start_time.strftime('%Y-%m-%d %H:%M:%S')}")
write_log_append('--')
#--------------------------------------------
# 指定檔案名稱
json_file_name = 'Input_ERTMaker_Inversion2D/Inversion2D.json'
#--------------------------------------------
# 讀取檔案
# 開啟並讀取 JSON 檔案
write_log_append("讀取 .json 檔...")
with open(json_file_name, 'r', encoding='utf-8') as json_file:
    temp_json_data = json.load(json_file)
write_log_append("讀取 .json 檔...完成!")
#--------------------------------------------
# 複製JSON檔案到輸出資料夾
Output_JSON_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],'Inversion2D.json')
if os.path.dirname(Output_JSON_FileName): # 防止空路徑報錯
    os.makedirs(os.path.dirname(Output_JSON_FileName), exist_ok=True)
# 複製檔案
shutil.copy(json_file_name, Output_JSON_FileName)
#--------------------------------------------
# 讀取資料 Ohm檔案
#--
write_log_append("載入Ohm檔案...")
Input_Ohm_FileName = temp_json_data["InputFile01_Ohm_FileName"]
write_log_append(f"目標檔案: {Input_Ohm_FileName}")
#這個棄用Ohm_data = ert.load(Input_Ohm_FileName) # 這個方式會把不合理的資料刪除，若希望保留請使用pg.DataContainerERT(Input_Ohm_FileName,removeInvalid=False)
Ohm_data = pg.DataContainerERT(Input_Ohm_FileName,removeInvalid=False)
if os.path.exists('invalid.data'):
    os.remove('invalid.data')
write_log_append("載入Ohm檔案...完成!")
#--
write_log_append(f"轉換為逆推專用2D座標系統(XY座標)...")
# 如果滿足2D情況，則強迫轉換成X有值，Y有值，Z均為0。
Ohm_data.ensure2D()
if  np.max(np.abs(pg.z(Ohm_data.sensorPositions()))) != 0 :
    write_log_append("Ohm檔案內容不是2D資料，無法進行後續分析，請檢查!")
    exit(1)
write_log_append(f"轉換為逆推專用2D座標系統(XY座標)完成!")
#--
Ohm_data_All_count = Ohm_data.size()
write_log_append(f'Ohm: 感應器數量 = {Ohm_data.sensorCount()}, 資料數量 = {Ohm_data_All_count}')
#--------------------------------------------
write_log_append('--')
#--------------------------------------------
# 準備逆推工具內部要使用的網格
#--
# 初始化可能要用到的參數
AutoMesh_quality = 0
AutoMesh_paraDepth = 0
AutoMesh_boundary = 0
AutoMesh_paraMaxCellSize = 0
AutoMesh_addNodes = 0
AutoMesh_paraDX = 0
# 選擇自動生成(預設電阻率為1[Ohm])或來自檔案
if temp_json_data["Mesh_Setting01_AutoMesh_Enable"] == 'Yes' :
    #--------------------------------------------
    # 自動生成三角形網格的方案
    #--------------------------------------------
    AutoMesh_quality = temp_json_data["Mesh_Setting02_AutoMesh_quality"]
    AutoMesh_paraDepth = temp_json_data["Mesh_Setting03_AutoMesh_paraDepth"]
    AutoMesh_boundary = temp_json_data["Mesh_Setting04_AutoMesh_boundary"]
    AutoMesh_paraMaxCellSize = temp_json_data["Mesh_Setting05_AutoMesh_paraMaxCellSize"]
    AutoMesh_addNodes = temp_json_data["Mesh_Setting06_AutoMesh_addNodes"]
    AutoMesh_paraDX = temp_json_data["Mesh_Setting07_AutoMesh_paraDX"]
    mesh=pg.meshtools.createParaMesh(Ohm_data,quality=AutoMesh_quality,paraDepth=AutoMesh_paraDepth,boundary=AutoMesh_boundary,paraMaxCellSize=AutoMesh_paraMaxCellSize,addNodes=AutoMesh_addNodes,paraDX=AutoMesh_paraDX)
    write_log_append(f"網格節點數量 (Mesh Node Count): {mesh.nodeCount()}")
    write_log_append(f"網格單元數量 (Mesh Cell Count): {mesh.cellCount()}")
    write_log_append(f"附加區域網格單元(Marker=1)的單元數量(Mesh Cell Marker=1 Count): {np.sum(mesh.cellMarkers() == 1)}")
    write_log_append(f"研究區域網格單元(Marker=2)的單元數量(Mesh Cell Marker=2 Count): {np.sum(mesh.cellMarkers() == 2)}")
    write_log_append(f"網格邊界數量 (Mesh Boundary Count): {mesh.boundaryCount()}")
    #--------------------------------------------
    # 填入預設電阻率
    mesh['Resistivity'] = np.ones(mesh.cellCount())
    mesh['Resistivity_(log10)'] = np.log10(mesh['Resistivity'])
    #--------------------------------------------
else:
    #--------------------------------------------
    # 從檔案中讀取網格的方案
    #--------------------------------------------
    # 建立網格
    mesh = pg.Mesh(2)
    # 使用計算出的節點座標創建網格
    write_log_append("讀取 .vtk 檔...")
    mesh.load(temp_json_data["InputFile02_MeshVTK_FileName"])
    write_log_append("讀取 .vtk 檔...完成!")
    # 確保正確性，重新計算log10的電阻率
    mesh['Resistivity_(log10)'] = np.log10(mesh['Resistivity'])
    #--------------------------------------------
    # 讀取並設定 MeshBCMarkers
    write_log_append("讀取 MeshBCMarkersJSON 檔...")
    # 開啟並讀取 JSON 檔案
    with open(temp_json_data["InputFile03_MeshBCMarkersJSON_FileName"], 'r', encoding='utf-8') as json_file:
        FullMeshMarkers_json_data = json.load(json_file)
    write_log_append("讀取 MeshBCMarkersJSON 檔...完成!")
    #--
    # 取出最後一直欄(marker)
    markers = [row[-1] for row in FullMeshMarkers_json_data['MeshBCMarkers']]
    # 設定 針對每一筆記錄，取出 index 與 marker，設定到對應的 boundary
    for entry in FullMeshMarkers_json_data['MeshBCMarkers']:
        indexValue, x1Value, y1Value, x2Value, y2Value, markerValue = entry
        b = mesh.boundaries()[int(indexValue)]
        b.setMarker(int(markerValue))
    #--
    write_log_append(f"網格節點數量 (Mesh Node Count): {mesh.nodeCount()}")
    write_log_append(f"網格單元數量 (Mesh Cell Count): {mesh.cellCount()}")
    write_log_append(f"附加區域網格單元(Marker=1)的單元數量(Mesh Cell Marker=1 Count): {np.sum(mesh.cellMarkers() == 1)}")
    write_log_append(f"研究區域網格單元(Marker=2)的單元數量(Mesh Cell Marker=2 Count): {np.sum(mesh.cellMarkers() == 2)}")
    write_log_append(f"網格邊界數量 (Mesh Boundary Count): {mesh.boundaryCount()}")
    #--------------------------------------------
write_log_append('--')
#--------------------------------------------
# 檢查網格與電極是否匹配
write_log_append("檢查網格與電極是否匹配...")
try:
    # 建立一個 ERT 模擬算子
    temp_fop = ert.ERTModelling()
    # 這是關鍵動作：它會觸發底層的 searchElectrodes_()
    temp_fop.setData(Ohm_data)
    #temp_fop.setMesh(mesh, ignoreRegionManager=True)    
    temp_fop.setMesh(mesh, ignoreRegionManager=False)  
    write_log_append("檢查通過：所有電極均成功匹配網格單元。")
except RuntimeError as e:
    # 當電極在網格之外時，會捕捉到 RuntimeError
    write_log_append("檢查失敗：偵測到電極與網格不匹配！(電極在網格之外嗎?)")
    write_log_append(f"錯誤訊息: {e}")
    exit(1)
write_log_append("檢查網格與電極是否匹配...完成!")
#--------------------------------------------
#==============================================================================
# Pygimli網格繪圖:  繪製全網格剖面(電阻率、電極位置、網格資訊)
#--
# 可填入的資訊
Main_FileName = temp_json_data["Output_MainFileName"]
PNG_Profile_Name = Main_FileName
PNG_NumPy_Electrode_x = Ohm_data.sensors().array()[:, 0]
PNG_NumPy_Electrode_y = Ohm_data.sensors().array()[:, 1]
PNG_NumPy_Electrode_z = Ohm_data.sensors().array()[:, 2]
PNG_mesh = mesh
PNG_mesh_data = mesh['Resistivity_(log10)']
PNG_colorbar_title = 'Resistivity (log10 Ωm)'
PNG_colorbar_ticker_ModifyLog10ToLinear_Enable = True # True = 把colorbar數值文字從對數尺度調整成線性尺度 / False = 維持原本數值
PNG_colorbar_ticker_ModifyLog10ToLinear_title = 'Resistivity (Ωm)'
PNG_Main_Title = f"{PNG_Profile_Name} FullMesh (" + \
    f"AutoMesh={temp_json_data['Mesh_Setting01_AutoMesh_Enable']}," + \
    f"quality={AutoMesh_quality}," + \
    f"paraDepth={AutoMesh_paraDepth}," + \
    f"boundary={AutoMesh_boundary})\n" + \
    f"(paraMaxCellSize={AutoMesh_paraMaxCellSize}," + \
    f"addNodes={AutoMesh_addNodes}," + \
    f"paraDX={AutoMesh_paraDX}) " + \
    f"Cell Count={np.sum(mesh.cellMarkers() == 1)}+{np.sum(mesh.cellMarkers() == 2)}={mesh.cellCount()}, " + \
    f"Data Count={Ohm_data_All_count}, " + \
    f'Electrode Count={Ohm_data.sensorCount()}'                
PNG_mesh_showMesh = True # True / False
PNG_mesh_showBoundary = True # None / True / False ，某些時候None與True效果相同
PNG_cMap = 'jet'
PNG_cMin = np.min(PNG_mesh_data) # None表示自動
PNG_cMax = np.max(PNG_mesh_data) # None表示自動
# 檢查是否所有數值都很接近
if (PNG_cMin - PNG_cMax) < 0.000002:
    # 如果很接近，設定極小的偏移量
    PNG_cMin = PNG_cMin - 0.000001
    PNG_cMax = PNG_cMax + 0.000001
PNG_DPI = 100
PNG_Width = 1280
PNG_Height = 720    
Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_01_InputFullMesh.png')
#--
# 建立畫布
fig, ax = plt.subplots(figsize=((PNG_Width / PNG_DPI, PNG_Height / PNG_DPI)))
# 繪製網格
ax, cbar = pg.show(PNG_mesh, 
    data=PNG_mesh_data, 
    ax=ax,
    markers=False,
    showMesh=PNG_mesh_showMesh,
    showBoundary=PNG_mesh_showBoundary,  
    label=PNG_colorbar_title,     # colorbar的標題。
    axisLabels=False,             # 阻止自動標籤(否則特定條件下會把Y軸轉換成深度)。後面自行填入標籤。
    cMap=PNG_cMap,
    cMin=PNG_cMin,
    cMax=PNG_cMax)
# 繪製電極
ax.plot(PNG_NumPy_Electrode_x, PNG_NumPy_Electrode_y, 'o', markersize=6, color='magenta', markerfacecolor='magenta', markeredgecolor='black', label='Electrode Nodes')    
ax.set_title(PNG_Main_Title, pad=3)  
# 調整XY標籤
ax.set_xlabel('Distance (m)')
ax.set_ylabel('Elevation (m)')
# 調整圖例
ax.legend(loc='upper right',ncol=2,framealpha=0.4)
# 調整colorbar內文字
if PNG_colorbar_ticker_ModifyLog10ToLinear_Enable:
    cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.FuncFormatter(lambda x, pos: f'{10**x:.1f}'.rstrip('0').rstrip('.')))    
    cbar.ax.xaxis.get_offset_text().set_visible(False) # 避免顯示 1eX
    cbar.set_label(PNG_colorbar_ticker_ModifyLog10ToLinear_title) # 使用你設定的 Ωm 標題
else:
    cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.ScalarFormatter(useMathText=False))
    cbar.ax.xaxis.get_major_formatter().set_useOffset(False) #禁用「偏移量 (Offset)」模式
    cbar.ax.xaxis.get_offset_text().set_visible(False)  # 避免顯示 1eX
#--
# 填入版本資訊
fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
# 調整邊界
x_min, x_max = ax.get_xlim()
y_min, y_max = ax.get_ylim()
x_range = x_max - x_min
y_range = y_max - y_min
ax.set_ylim(y_min , y_max + 0.1 * y_range)
#--
#write_log_append(f'儲存 {PNG_Profile_Name} 圖片...')
#Output_PNG_FileName = 'ABCD.png'
if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
    os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
plt.tight_layout() 
plt.savefig(Output_PNG_FileName, dpi=PNG_DPI)
plt.close()
#write_log_append(f'儲存 {PNG_Profile_Name} 圖片...完成!')
#==============================================================================
#--------------------------------------------
# 輸出VTK
# 目前是基礎網格 BasicMeshSetTopo 。
# 輸出VTK前先把預設該存在的資料填1
mesh['Coverage'] = np.ones(mesh.cellCount())
mesh['S_Coverage'] = np.ones(mesh.cellCount())
# 輸出
Main_FileName = temp_json_data["Output_MainFileName"]
temp_output_filename=os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_01_InputFullMesh.vtk')
mesh.exportVTK(temp_output_filename)
#-------------------------------------------- 
# 整理 MeshBCMarkers
#--    
# 印出 index, x1, y1, x2, y2, marker
#write_log_append("index, x1, y1, x2, y2, marker")
#for i, b in enumerate(mesh.boundaries()):
#    write_log_append(f"{i}, {b.nodes()[0].pos()[0]:.6f}, {b.nodes()[0].pos()[1]:.6f}, {b.nodes()[1].pos()[0]:.6f}, {b.nodes()[1].pos()[1]:.6f}, {b.marker()}")
#--
Main_FileName = temp_json_data["Output_MainFileName"]
temp_output_filename=os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_01_InputFullMeshBCMarkers.json')
# 儲存MeshMarkers為JSON檔案
write_log_append('儲存MeshBCMarkers為JSON檔案...')
# 開啟檔案，以 UTF-8 編碼手動寫入 JSON 內容
with open(temp_output_filename, 'w', encoding='utf-8') as f:
    #--
    # 寫入說明行
    f.write('{\n')
    f.write('"MeshBCMarkers_Readme":"index,x1[m],y1[m],x2[m],y2[m],marker",\n')
    f.write('"MeshBCMarkers":[\n')
    #--
    for i, b in enumerate(mesh.boundaries()):
        #--
        # 組成一列文字
        line = f'[{i}, {b.nodes()[0].pos()[0]:.6f}, {b.nodes()[0].pos()[1]:.6f}, {b.nodes()[1].pos()[0]:.6f}, {b.nodes()[1].pos()[1]:.6f}, {b.marker()}]'
        # 最後一列不加逗號，其它加逗號
        if i < mesh.boundaryCount() - 1:
            line += ','
        line += '\n'
        # 寫入
        f.write(line)
        #--
    #--
    # 關閉陣列與大括號
    f.write(']\n')
    f.write('}\n')
    #--
write_log_append('儲存MeshBCMarkers為JSON檔案...完成!')
#--------------------------------------------
#==============================================================================
# Pygimli網格繪圖:  繪製研究區域網格剖面(電阻率、電極位置、網格資訊)
#--
# 可填入的資訊
Main_FileName = temp_json_data["Output_MainFileName"]
PNG_Profile_Name = Main_FileName
PNG_NumPy_Electrode_x = Ohm_data.sensors().array()[:, 0]
PNG_NumPy_Electrode_y = Ohm_data.sensors().array()[:, 1]
PNG_NumPy_Electrode_z = Ohm_data.sensors().array()[:, 2]
PNG_mesh = temp_fop.regionManager().paraDomain()
PNG_mesh_data = mesh['Resistivity_(log10)'][(mesh.cellMarkers() == 2)]
PNG_colorbar_title = 'Resistivity (log10 Ωm)'
PNG_colorbar_ticker_ModifyLog10ToLinear_Enable = True # True = 把colorbar數值文字從對數尺度調整成線性尺度 / False = 維持原本數值
PNG_colorbar_ticker_ModifyLog10ToLinear_title = 'Resistivity (Ωm)'
PNG_Main_Title = f"{PNG_Profile_Name} StudyAreaMesh (" + \
    f"AutoMesh={temp_json_data['Mesh_Setting01_AutoMesh_Enable']}," + \
    f"quality={AutoMesh_quality}," + \
    f"paraDepth={AutoMesh_paraDepth}," + \
    f"boundary={AutoMesh_boundary})\n" + \
    f"(paraMaxCellSize={AutoMesh_paraMaxCellSize}," + \
    f"addNodes={AutoMesh_addNodes}," + \
    f"paraDX={AutoMesh_paraDX}) " + \
    f"Cell Count={np.sum(mesh.cellMarkers() == 1)}+{np.sum(mesh.cellMarkers() == 2)}={mesh.cellCount()}, " + \
    f"Data Count={Ohm_data_All_count}, " + \
    f'Electrode Count={Ohm_data.sensorCount()}'               
PNG_mesh_showMesh = True # True / False
PNG_mesh_showBoundary = True # None / True / False ，某些時候None與True效果相同
PNG_cMap = 'jet'
PNG_cMin = np.min(PNG_mesh_data) # None表示自動
PNG_cMax = np.max(PNG_mesh_data) # None表示自動
# 檢查是否所有數值都很接近
if (PNG_cMin - PNG_cMax) < 0.000002:
    # 如果很接近，設定極小的偏移量
    PNG_cMin = PNG_cMin - 0.000001
    PNG_cMax = PNG_cMax + 0.000001
PNG_DPI = 100
PNG_Width = 1280
PNG_Height = 720    
Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_01_StudyAreaMesh.png')
#--
# 建立畫布
fig, ax = plt.subplots(figsize=((PNG_Width / PNG_DPI, PNG_Height / PNG_DPI)))
# 繪製網格
ax, cbar = pg.show(PNG_mesh, 
    data=PNG_mesh_data, 
    ax=ax,
    markers=False,
    showMesh=PNG_mesh_showMesh,
    showBoundary=PNG_mesh_showBoundary,  
    label=PNG_colorbar_title,     # colorbar的標題。
    axisLabels=False,             # 阻止自動標籤(否則特定條件下會把Y軸轉換成深度)。後面自行填入標籤。
    cMap=PNG_cMap,
    cMin=PNG_cMin,
    cMax=PNG_cMax)
# 繪製電極
ax.plot(PNG_NumPy_Electrode_x, PNG_NumPy_Electrode_y, 'o', markersize=6, color='magenta', markerfacecolor='magenta', markeredgecolor='black', label='Electrode Nodes')    
ax.set_title(PNG_Main_Title, pad=3)  
# 調整XY標籤
ax.set_xlabel('Distance (m)')
ax.set_ylabel('Elevation (m)')
# 調整圖例
ax.legend(loc='upper right',ncol=2,framealpha=0.4)
# 調整colorbar內文字
if PNG_colorbar_ticker_ModifyLog10ToLinear_Enable:
    cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.FuncFormatter(lambda x, pos: f'{10**x:.1f}'.rstrip('0').rstrip('.')))    
    cbar.ax.xaxis.get_offset_text().set_visible(False) # 避免顯示 1eX
    cbar.set_label(PNG_colorbar_ticker_ModifyLog10ToLinear_title) # 使用你設定的 Ωm 標題
else:
    cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.ScalarFormatter(useMathText=False))
    cbar.ax.xaxis.get_major_formatter().set_useOffset(False) #禁用「偏移量 (Offset)」模式
    cbar.ax.xaxis.get_offset_text().set_visible(False)  # 避免顯示 1eX
#--
# 填入版本資訊
fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
# 調整邊界
x_min, x_max = ax.get_xlim()
y_min, y_max = ax.get_ylim()
x_range = x_max - x_min
y_range = y_max - y_min
ax.set_ylim(y_min , y_max + 0.1 * y_range)
#--
#write_log_append(f'儲存 {PNG_Profile_Name} 圖片...')
#Output_PNG_FileName = 'ABCD.png'
if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
    os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
plt.tight_layout() 
plt.savefig(Output_PNG_FileName, dpi=PNG_DPI)
plt.close()
#write_log_append(f'儲存 {PNG_Profile_Name} 圖片...完成!')
#==============================================================================
if temp_json_data["Output_Inversion_XMinMax_Enable"] == 'Yes' :
    #==============================================================================
    # Pygimli網格繪圖:  繪製研究區域網格剖面(電阻率、電極位置、網格資訊)
    #--
    # 可填入的資訊
    Main_FileName = temp_json_data["Output_MainFileName"]
    PNG_Profile_Name = Main_FileName
    PNG_NumPy_Electrode_x = Ohm_data.sensors().array()[:, 0]
    PNG_NumPy_Electrode_y = Ohm_data.sensors().array()[:, 1]
    PNG_NumPy_Electrode_z = Ohm_data.sensors().array()[:, 2]
    PNG_mesh = temp_fop.regionManager().paraDomain()
    PNG_mesh_data = mesh['Resistivity_(log10)'][(mesh.cellMarkers() == 2)]
    PNG_colorbar_title = 'Resistivity (log10 Ωm)'
    PNG_colorbar_ticker_ModifyLog10ToLinear_Enable = True # True = 把colorbar數值文字從對數尺度調整成線性尺度 / False = 維持原本數值
    PNG_colorbar_ticker_ModifyLog10ToLinear_title = 'Resistivity (Ωm)'
    PNG_Main_Title = f"{PNG_Profile_Name} StudyAreaMesh (" + \
        f"AutoMesh={temp_json_data['Mesh_Setting01_AutoMesh_Enable']}," + \
        f"quality={AutoMesh_quality}," + \
        f"paraDepth={AutoMesh_paraDepth}," + \
        f"boundary={AutoMesh_boundary})\n" + \
        f"(paraMaxCellSize={AutoMesh_paraMaxCellSize}," + \
        f"addNodes={AutoMesh_addNodes}," + \
        f"paraDX={AutoMesh_paraDX}) " + \
        f"Cell Count={np.sum(mesh.cellMarkers() == 1)}+{np.sum(mesh.cellMarkers() == 2)}={mesh.cellCount()}, " + \
        f"Data Count={Ohm_data_All_count}, " + \
        f'Electrode Count={Ohm_data.sensorCount()}'               
    PNG_mesh_showMesh = True # True / False
    PNG_mesh_showBoundary = True # None / True / False ，某些時候None與True效果相同
    PNG_cMap = 'jet'
    PNG_cMin = np.min(PNG_mesh_data) # None表示自動
    PNG_cMax = np.max(PNG_mesh_data) # None表示自動
    # 檢查是否所有數值都很接近
    if (PNG_cMin - PNG_cMax) < 0.000002:
        # 如果很接近，設定極小的偏移量
        PNG_cMin = PNG_cMin - 0.000001
        PNG_cMax = PNG_cMax + 0.000001
    PNG_DPI = 100
    PNG_Width = 1280
    PNG_Height = 720    
    Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_01_StudyAreaMesh2.png')
    #--
    # 建立畫布
    fig, ax = plt.subplots(figsize=((PNG_Width / PNG_DPI, PNG_Height / PNG_DPI)))
    # 繪製網格
    ax, cbar = pg.show(PNG_mesh, 
        data=PNG_mesh_data, 
        ax=ax,
        markers=False,
        showMesh=PNG_mesh_showMesh,
        showBoundary=PNG_mesh_showBoundary,  
        label=PNG_colorbar_title,     # colorbar的標題。
        axisLabels=False,             # 阻止自動標籤(否則特定條件下會把Y軸轉換成深度)。後面自行填入標籤。
        cMap=PNG_cMap,
        cMin=PNG_cMin,
        cMax=PNG_cMax)
    # 繪製電極
    ax.plot(PNG_NumPy_Electrode_x, PNG_NumPy_Electrode_y, 'o', markersize=6, color='magenta', markerfacecolor='magenta', markeredgecolor='black', label='Electrode Nodes')    
    ax.set_title(PNG_Main_Title, pad=3)  
    # 調整XY標籤
    ax.set_xlabel('Distance (m)')
    ax.set_ylabel('Elevation (m)')
    # 調整圖例
    ax.legend(loc='upper right',ncol=2,framealpha=0.4)
    # 調整colorbar內文字
    if PNG_colorbar_ticker_ModifyLog10ToLinear_Enable:
        cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.FuncFormatter(lambda x, pos: f'{10**x:.1f}'.rstrip('0').rstrip('.')))    
        cbar.ax.xaxis.get_offset_text().set_visible(False) # 避免顯示 1eX
        cbar.set_label(PNG_colorbar_ticker_ModifyLog10ToLinear_title) # 使用你設定的 Ωm 標題
    else:
        cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.ScalarFormatter(useMathText=False))
        cbar.ax.xaxis.get_major_formatter().set_useOffset(False) #禁用「偏移量 (Offset)」模式
        cbar.ax.xaxis.get_offset_text().set_visible(False)  # 避免顯示 1eX
    #--
    # 填入版本資訊
    fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
    # 調整邊界
    x_min, x_max = ax.get_xlim()
    y_min, y_max = ax.get_ylim()
    x_range = x_max - x_min
    y_range = y_max - y_min    
    #--
    # 依照參數設定繪製範圍
    ax.set_xlim(temp_json_data['Output_Inversion_XMin'] , temp_json_data['Output_Inversion_XMax'])
    ax.set_ylim(temp_json_data['Output_Inversion_YMin'] , temp_json_data['Output_Inversion_YMax'])
    #--
    #write_log_append(f'儲存 {PNG_Profile_Name} 圖片...')
    #Output_PNG_FileName = 'ABCD.png'
    if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
        os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
    plt.tight_layout() 
    plt.savefig(Output_PNG_FileName, dpi=PNG_DPI)
    plt.close()
    #write_log_append(f'儲存 {PNG_Profile_Name} 圖片...完成!')
    #==============================================================================
write_log_append('--')
#--------------------------------------------
Data_Settings_Relative_Error_Percentage = temp_json_data["Data_Setting01_Relative_Error_Percentage"]
#--------------------------------------------
# 重新計算幾何因子與視電阻率並指定誤差
write_log_append("重新計算幾何因子與視電阻率並指定誤差...")
#--------------------------------------------
# K0_Mesh部分 是否要計算
if (temp_json_data["Data_Setting02_GeometricFactorForInversion"] == 'K0_Mesh') or (temp_json_data["OutputFile01_GeometricFactor_K_CrossPlot_PNG_Enable"] == 'Yes'):
    write_log_append('**計算解析解公式的幾何因子!請注意僅適用水平地層!')
    # 計算解析解 (假設水平地面)
    K0_Mesh = ert.createGeometricFactors(Ohm_data, numerical=False)
#--------------------------------------------
# K_Mesh部分 是否要計算
if temp_json_data["Data_Setting02_GeometricFactorForInversion"] == 'K_Mesh' : # 計算網格綁定的幾何因子K_Mesh
    write_log_append('**計算網格綁定的幾何因子K_Mesh!(有考慮地形)')
    #這個棄用Ohm_data['k'] = ert.createGeometricFactors(Ohm_data, mesh=mesh, numerical=True) # 考慮地形使用「numerical=True」並提供「mesh」，考慮水平地層使用「numerical=False」
    # 使用mgr來計算幾何因子
    temp_Ohm_data=Ohm_data.copy()
    # 先填暫時的幾何因子(強制設為1.0)
    temp_Ohm_data['k'] = (temp_Ohm_data['r']*0)+1.0
    # 計算視電阻率(目前視電阻率也是暫時的，只是要騙過管理器)
    temp_Ohm_data["rhoa"] = (temp_Ohm_data['r']*0)+1.0
    # 提供資料估計相對誤差(只是要騙過管理器)
    temp_Ohm_data['err'] = ert.estimateError(temp_Ohm_data, relativeError=Data_Settings_Relative_Error_Percentage/100)  # Estimate relative error
    # 建一個暫時的逆推管理
    write_log_append("**建立暫時的ERTManager物件...")
    if temp_json_data["Inversion_Setting09_SR_Enable"] == 'Yes' :
        temp_mgr = ert.ERTManager(temp_Ohm_data, sr=True)
    else:
        temp_mgr = ert.ERTManager(temp_Ohm_data, sr=False)    
    write_log_append("**建立暫時的ERTManager物件...完成")
    #--
    write_log_append("**使用暫時的管理器運行逆推(maxIter=0)...")
    temp_mgr.invert(mesh=mesh, maxIter=0, startModel=1.0, verbose=False)
    write_log_append("**使用暫時的管理器運行逆推maxIter=0...完成!")
    # 計算正確的幾何因子(K_Mesh暗示這等效於ert.createGeometricFactors(Ohm_data, mesh=mesh, numerical=True))
    K_Mesh = 1/temp_mgr.inv.response  
elif temp_json_data["Data_Setting02_GeometricFactorForInversion"] == 'K0_Mesh' :   # 使用前面算好的解析解
    K_Mesh = K0_Mesh.copy()
else:
    K0_Mesh = ert.createGeometricFactors(Ohm_data, numerical=False)
    K_Mesh = K0_Mesh.copy()
#--------------------------------------------
# K_Ideal部分 是否要計算
if (temp_json_data["Data_Setting00_RecalculateDataMode"] == 'r') and (temp_json_data["Data_Setting03_GeometricFactorForRecalculateData"] == 'Ideal_Mesh') : # 計算理想網格綁定的幾何因子K_Ideal。要讀取參數來建立理想網格。
    #--
    write_log_append("***從參數建立的理想網格計算理想幾何因子...")
    #--------------------------------------------
    K_Ideal_Mesh=pg.meshtools.createParaMesh(
        Ohm_data,quality=temp_json_data["Ideal_Mesh_Setting01_AutoMesh_quality"],
        paraDepth=temp_json_data["Ideal_Mesh_Setting02_AutoMesh_paraDepth"],
        boundary=temp_json_data["Ideal_Mesh_Setting03_AutoMesh_boundary"],
        paraMaxCellSize=temp_json_data["Ideal_Mesh_Setting04_AutoMesh_paraMaxCellSize"],
        addNodes=temp_json_data["Ideal_Mesh_Setting05_AutoMesh_addNodes"],
        paraDX=temp_json_data["Ideal_Mesh_Setting06_AutoMesh_paraDX"])
    write_log_append(f"****網格節點數量 (K_Ideal_Mesh Node Count): {K_Ideal_Mesh.nodeCount()}")
    write_log_append(f"****網格單元數量 (K_Ideal_Mesh Cell Count): {K_Ideal_Mesh.cellCount()}")
    write_log_append(f"****附加區域網格單元(Marker=1)的單元數量(K_Ideal_Mesh Cell Marker=1 Count): {np.sum(K_Ideal_Mesh.cellMarkers() == 1)}")
    write_log_append(f"****研究區域網格單元(Marker=2)的單元數量(K_Ideal_Mesh Cell Marker=2 Count): {np.sum(K_Ideal_Mesh.cellMarkers() == 2)}")
    write_log_append(f"****網格邊界數量 (K_Ideal_Mesh Boundary Count): {K_Ideal_Mesh.boundaryCount()}")
    #--------------------------------------------
    # 填入預設電阻率
    K_Ideal_Mesh['Resistivity'] = np.ones(K_Ideal_Mesh.cellCount())
    K_Ideal_Mesh['Resistivity_(log10)'] = np.log10(K_Ideal_Mesh['Resistivity'])
    #--------------------------------------------
    # 使用mgr來計算幾何因子
    temp_Ohm_data=Ohm_data.copy()
    # 先填暫時的幾何因子(強制設為1.0)
    temp_Ohm_data['k'] = (temp_Ohm_data['r']*0)+1.0
    # 計算視電阻率(目前視電阻率也是暫時的，只是要騙過管理器)
    temp_Ohm_data["rhoa"] = (temp_Ohm_data['r']*0)+1.0
    # 提供資料估計相對誤差(只是要騙過管理器)
    temp_Ohm_data['err'] = ert.estimateError(temp_Ohm_data, relativeError=Data_Settings_Relative_Error_Percentage/100)  # Estimate relative error
    # 建一個暫時的逆推管理
    write_log_append("****建立暫時的ERTManager物件...")
    if temp_json_data["Inversion_Setting09_SR_Enable"] == 'Yes' :
        temp_mgr = ert.ERTManager(temp_Ohm_data, sr=True)
    else:
        temp_mgr = ert.ERTManager(temp_Ohm_data, sr=False)    
    write_log_append("****建立暫時的ERTManager物件...完成")
    #--
    write_log_append("****使用暫時的管理器運行逆推(maxIter=0)...")
    temp_mgr.invert(mesh=K_Ideal_Mesh, maxIter=0, startModel=1.0, verbose=False)
    write_log_append("****使用暫時的管理器運行逆推maxIter=0...完成!")
    # 計算正確的幾何因子
    K_Ideal = 1/temp_mgr.inv.response 
    temp_Ohm_data['k'] = 1/temp_mgr.inv.response
    temp_Ohm_data.save(os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_K_Ideal.dat'),'a b m n r i rhoa k err')
    #--
elif temp_json_data["Data_Setting03_GeometricFactorForRecalculateData"] == 'K_Mesh' :   # 使用前面算好的數值解K_Mesh
    K_Ideal = K_Mesh.copy()
elif temp_json_data["Data_Setting03_GeometricFactorForRecalculateData"] == 'K0_Mesh' :   # 使用前面算好的解析解 
    K_Ideal = K0_Mesh.copy()
else:
    K_Ideal = K_Mesh.copy()
#--------------------------------------------  
if temp_json_data["Data_Setting00_RecalculateDataMode"] == 'rhoa' and Ohm_data.haveData('rhoa') :
    write_log_append("採用檔案中的「rhoa」欄位!")
    # 選擇逆推用的幾何因子
    write_log_append("綁定目前網格的幾何因子「K_Mesh」!")
    Ohm_data['k'] = K_Mesh.copy()
    # 計算正確的V/I(重新計算)
    write_log_append("重新計算正確的V/I!")
    Ohm_data["r"] = Ohm_data['rhoa']/Ohm_data['k']
    # 提供資料估計相對誤差
    Ohm_data['err'] = ert.estimateError(Ohm_data, relativeError=Data_Settings_Relative_Error_Percentage/100)  # Estimate relative error
    # 確保有電流欄位
    if not Ohm_data.haveData('i'):
        write_log_append("自動產生預設電流值(1安培)!")
        Ohm_data['i'] = (Ohm_data['r']*0)+1.0
else:
    write_log_append("採用檔案中的「r」欄位!")
    # 選擇逆推用的幾何因子
    write_log_append("綁定目前網格的幾何因子「K_Mesh」!")
    Ohm_data['k'] = K_Mesh.copy()
    # 計算正確的視電阻率(重新計算)
    write_log_append("重新計算正確的視電阻率!")
    Ohm_data['K_Ideal'] = K_Ideal.copy()
    Ohm_data["rhoa"] = Ohm_data['r'] * Ohm_data['K_Ideal']
    # 提供資料估計相對誤差
    Ohm_data['err'] = ert.estimateError(Ohm_data, relativeError=Data_Settings_Relative_Error_Percentage/100)  # Estimate relative error
    # 確保有電流欄位
    if not Ohm_data.haveData('i'):
        write_log_append("自動產生預設電流值(1安培)!")
        Ohm_data['i'] = (Ohm_data['r']*0)+1.0
write_log_append("重新計算幾何因子與視電阻率並指定誤差...完成!")
#--------------------------------------------
write_log_append("--")
if temp_json_data["OutputFile01_GeometricFactor_K_CrossPlot_PNG_Enable"] == 'Yes' :
    #--------------------------------------------
    # Cross Plot K
    #--
    Main_FileName = temp_json_data["Output_MainFileName"]
    temp_PNG_DPI = 100
    temp_PNG_Width = 1280
    temp_PNG_Height = 720
    #--
    # 建立畫布
    fig, axes = plt.subplots(1, 3, figsize=((temp_PNG_Width / temp_PNG_DPI, temp_PNG_Height / temp_PNG_DPI)))
    #--
    # 子圖1
    #--
    # 繪製資料點
    K0_Mesh_positive_positive = K0_Mesh[(K0_Mesh > 0) & (K_Ideal > 0)]
    K_Ideal_positive_positive = K_Ideal[(K0_Mesh > 0) & (K_Ideal > 0)]
    axes[0].scatter(K0_Mesh_positive_positive, K_Ideal_positive_positive, alpha=0.5, s=5, c='blue',label=f'1+2+({len(K0_Mesh_positive_positive)})')
    K0_Mesh_positive_negative = K0_Mesh[(K0_Mesh > 0) & (K_Ideal < 0)]
    K_Ideal_positive_negative = K_Ideal[(K0_Mesh > 0) & (K_Ideal < 0)]
    axes[0].scatter(K0_Mesh_positive_negative, K_Ideal_positive_negative, alpha=0.5, s=5, c='blue',label=f'1+2-({len(K0_Mesh_positive_negative)})')
    K0_Mesh_negative_negative = K0_Mesh[(K0_Mesh < 0) & (K_Ideal < 0)]
    K_Ideal_negative_negative = K_Ideal[(K0_Mesh < 0) & (K_Ideal < 0)]
    axes[0].scatter(K0_Mesh_negative_negative, K_Ideal_negative_negative, alpha=0.5, s=5, c='blue',label=f'1-2-({len(K0_Mesh_negative_negative)})')
    K0_Mesh_negative_positive = K0_Mesh[(K0_Mesh < 0) & (K_Ideal > 0)]
    K_Ideal_negative_positive = K_Ideal[(K0_Mesh < 0) & (K_Ideal > 0)]
    axes[0].scatter(K0_Mesh_negative_positive, K_Ideal_negative_positive, alpha=0.5, s=5, c='blue',label=f'1-2+({len(K0_Mesh_negative_positive)})')
    # 設定等比例
    axes[0].set_aspect('equal', adjustable='box')
    # 畫出 1:1 參考線
    lims = [
        np.min([axes[0].get_xlim(), axes[0].get_ylim()]),
        np.max([axes[0].get_xlim(), axes[0].get_ylim()]),
    ]
    axes[0].plot(lims, lims, '--', c='gray', alpha=0.75, zorder=0, label='1:1 Line')
    #--
    # 調整繪圖參數
    axes[0].set_xlabel(f'1: Half-space Analytical Solution K0_Mesh (m)')
    axes[0].set_ylabel(f'2: Ideal Numerical Solution K_Ideal (m)')
    axes[0].set_title(f'#1 Geometric Factor K Cross Plot(Linear)\nData Count = {len(K0_Mesh_positive_positive)+len(K0_Mesh_positive_negative)+len(K0_Mesh_negative_negative)+len(K0_Mesh_negative_positive)}')
    axes[0].legend(loc='upper left')
    #--
    # 子圖2
    #--
    # 繪製資料點
    K0_Mesh_positive_positive = K0_Mesh[(K0_Mesh > 0) & (K_Mesh > 0)]
    K_Mesh_positive_positive = K_Mesh[(K0_Mesh > 0) & (K_Mesh > 0)]
    axes[1].scatter(K0_Mesh_positive_positive, K_Mesh_positive_positive, alpha=0.5, s=5, c='blue',label=f'1+2+({len(K0_Mesh_positive_positive)})')
    K0_Mesh_positive_negative = K0_Mesh[(K0_Mesh > 0) & (K_Mesh < 0)]
    K_Mesh_positive_negative = K_Mesh[(K0_Mesh > 0) & (K_Mesh < 0)]
    axes[1].scatter(K0_Mesh_positive_negative, K_Mesh_positive_negative, alpha=0.5, s=5, c='blue',label=f'1+2-({len(K0_Mesh_positive_negative)})')
    K0_Mesh_negative_negative = K0_Mesh[(K0_Mesh < 0) & (K_Mesh < 0)]
    K_Mesh_negative_negative = K_Mesh[(K0_Mesh < 0) & (K_Mesh < 0)]
    axes[1].scatter(K0_Mesh_negative_negative, K_Mesh_negative_negative, alpha=0.5, s=5, c='blue',label=f'1-2-({len(K0_Mesh_negative_negative)})')
    K0_Mesh_negative_positive = K0_Mesh[(K0_Mesh < 0) & (K_Mesh > 0)]
    K_Mesh_negative_positive = K_Mesh[(K0_Mesh < 0) & (K_Mesh > 0)]
    axes[1].scatter(K0_Mesh_negative_positive, K_Mesh_negative_positive, alpha=0.5, s=5, c='blue',label=f'1-2+({len(K0_Mesh_negative_positive)})')
    # 設定等比例
    axes[1].set_aspect('equal', adjustable='box')
    # 畫出 1:1 參考線
    lims = [
        np.min([axes[1].get_xlim(), axes[1].get_ylim()]),
        np.max([axes[1].get_xlim(), axes[1].get_ylim()]),
    ]
    axes[1].plot(lims, lims, '--', c='gray', alpha=0.75, zorder=0, label='1:1 Line')
    #--
    # 調整繪圖參數
    axes[1].set_xlabel(f'1: Half-space Analytical Solution K0_Mesh (m)')
    axes[1].set_ylabel(f'2: Custom-Mesh Numerical Solution K_Mesh (m)')
    axes[1].set_title(f'#2 Geometric Factor K Cross Plot(Linear)\nData Count = {len(K0_Mesh_positive_positive)+len(K0_Mesh_positive_negative)+len(K0_Mesh_negative_negative)+len(K0_Mesh_negative_positive)}')
    axes[1].legend(loc='upper left')
    #--
    # 子圖3
    #--
    # 繪製資料點
    K_Ideal_positive_positive = K_Ideal[(K_Ideal > 0) & (K_Mesh > 0)]
    K_Mesh_positive_positive = K_Mesh[(K_Ideal > 0) & (K_Mesh > 0)]
    axes[2].scatter(K_Ideal_positive_positive, K_Mesh_positive_positive, alpha=0.5, s=5, c='blue',label=f'1+2+({len(K_Ideal_positive_positive)})')
    K_Ideal_positive_negative = K_Ideal[(K_Ideal > 0) & (K_Mesh < 0)]
    K_Mesh_positive_negative = K_Mesh[(K_Ideal > 0) & (K_Mesh < 0)]
    axes[2].scatter(K_Ideal_positive_negative, K_Mesh_positive_negative, alpha=0.5, s=5, c='blue',label=f'1+2-({len(K_Ideal_positive_negative)})')
    K_Ideal_negative_negative = K_Ideal[(K_Ideal < 0) & (K_Mesh < 0)]
    K_Mesh_negative_negative = K_Mesh[(K_Ideal < 0) & (K_Mesh < 0)]
    axes[2].scatter(K_Ideal_negative_negative, K_Mesh_negative_negative, alpha=0.5, s=5, c='blue',label=f'1-2-({len(K_Ideal_negative_negative)})')
    K_Ideal_negative_positive = K_Ideal[(K_Ideal < 0) & (K_Mesh > 0)]
    K_Mesh_negative_positive = K_Mesh[(K_Ideal < 0) & (K_Mesh > 0)]
    axes[2].scatter(K_Ideal_negative_positive, K_Mesh_negative_positive, alpha=0.5, s=5, c='blue',label=f'1-2+({len(K_Ideal_negative_positive)})')
    # 設定等比例
    axes[2].set_aspect('equal', adjustable='box')
    # 畫出 1:1 參考線
    lims = [
        np.min([axes[2].get_xlim(), axes[2].get_ylim()]),
        np.max([axes[2].get_xlim(), axes[2].get_ylim()]),
    ]
    axes[2].plot(lims, lims, '--', c='gray', alpha=0.75, zorder=0, label='1:1 Line')
    #--
    # 調整繪圖參數
    axes[2].set_xlabel(f'1: Ideal Numerical Solution K_Ideal (m)')
    axes[2].set_ylabel(f'2: Custom-Mesh Numerical Solution K_Mesh (m)')
    axes[2].set_title(f'#3 Geometric Factor K Cross Plot(Linear)\nData Count = {len(K_Ideal_positive_positive)+len(K_Ideal_positive_negative)+len(K_Ideal_negative_negative)+len(K_Ideal_negative_positive)}')
    axes[2].legend(loc='upper left')
    #--
    # 填入總標題
    #if temp_json_data["Data_Setting02_GeometricFactorByMesh_Enable"] == 'Yes' :  
    #    if temp_json_data["IdealGeometricFactorByFile_Enable"] == 'Yes' :
    #        fig.suptitle(f'{Main_FileName}\nGeometric Factor K Cross Plot\nInput File: {os.path.basename(Input_Ohm_FileName)}\nUse Custom-Mesh K Solution.\nIdeal K : Load From File', fontsize=16, fontweight='bold', y =0.9)  
    #    else:
    #        fig.suptitle(f'{Main_FileName}\nGeometric Factor K Cross Plot\nInput File: {os.path.basename(Input_Ohm_FileName)}\nUse Custom-Mesh K Solution.\nIdeal K : Custom Ideal Mesh', fontsize=16, fontweight='bold', y =0.9)  
    #else:
    fig.suptitle(f'Geometric Factor K Cross Plot\n{Main_FileName}: K_Ideal = {temp_json_data["Data_Setting03_GeometricFactorForRecalculateData"]}\nOhm File: {os.path.basename(Input_Ohm_FileName)}', fontsize=16, fontweight='bold', y =0.9)  
    # 填入版本資訊
    fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
    #--
    write_log_append(f'儲存K_CrossPlot圖片...')
    Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_02_CrossPlot_K.png')
    if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
        os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
    plt.tight_layout() 
    plt.savefig(Output_PNG_FileName, dpi=temp_PNG_DPI)
    plt.close()
    write_log_append(f'儲存K_CrossPlot圖片...完成!')
    #--------------------------------------------
    write_log_append("--")
#--------------------------------------------
# 繪圖 V/I All
Main_FileName = temp_json_data["Output_MainFileName"]
temp_PNG_DPI = 100
temp_PNG_Width = 1280
temp_PNG_Height = 720
PNG_cMin = np.min(Ohm_data['r']) # None表示自動
PNG_cMax = np.max(Ohm_data['r']) # None表示自動
# 檢查是否所有數值都很接近
if (PNG_cMin - PNG_cMax) < 0.000002:
    # 如果很接近，設定極小的偏移量
    PNG_cMin = PNG_cMin - 0.000001
    PNG_cMax = PNG_cMax + 0.000001
#--
# 建立畫布
fig, ax = plt.subplots(figsize=((temp_PNG_Width / temp_PNG_DPI, temp_PNG_Height / temp_PNG_DPI)))
# 使用 ert.show() 來顯示資料，並自動決定色階範圍
ax, cbar = ert.show(
      Ohm_data,                    # 必須的參數：DataContainerERT 物件
      vals=Ohm_data['r'],          # 要繪製的數據
      ax=ax,                       # 指定畫在剛才建立的 ax 上
      logScale=False,              # 預設值：根據數據值來決定是否使用對數尺度，這裡默認使用對數尺度
      label='V/I (Ω)',             # colorbar的標題，不填就自動產生Apparent resistivity (Ωm)。
      xlabel=None,                 # 預設值：x 軸標籤
      ylabel=None,                 # 預設值：y 軸標籤
      cMin=PNG_cMin,
      cMax=PNG_cMax
  )
# 確保是座標軸對象，並加入標題與軸標籤
ax.set_title(f"{os.path.basename(Input_Ohm_FileName)}\nV/I Distribution ({Ohm_data_All_count}) Min/Max={np.min(Ohm_data['r']):.6f}/{np.max(Ohm_data['r']):.6f}", fontsize=14)
ax.set_xlabel("")
# 不用科學記號的 colorbar 數值
cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.ScalarFormatter(useMathText=False))
cbar.ax.xaxis.get_major_formatter().set_useOffset(False) #禁用「偏移量 (Offset)」模式
cbar.ax.xaxis.get_offset_text().set_visible(False)  # 避免顯示 1eX
#--
# 填入版本資訊
fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
#--
write_log_append(f'儲存 V/I All圖片...')
Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_Distribution_VoverI_All.png')
if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
    os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
plt.tight_layout() 
plt.savefig(Output_PNG_FileName, dpi=temp_PNG_DPI)
plt.close()
write_log_append(f'儲存 V/I All圖片...完成!')
#--------------------------------------------
write_log_append('--')
#--------------------------------------------
# 繪圖 Voltage All
Main_FileName = temp_json_data["Output_MainFileName"]
temp_PNG_DPI = 100
temp_PNG_Width = 1280
temp_PNG_Height = 720
PNG_cMin = np.min(Ohm_data['r']*Ohm_data['i']) # None表示自動
PNG_cMax = np.max(Ohm_data['r']*Ohm_data['i']) # None表示自動
# 檢查是否所有數值都很接近
if (PNG_cMin - PNG_cMax) < 0.000002:
    # 如果很接近，設定極小的偏移量
    PNG_cMin = PNG_cMin - 0.000001
    PNG_cMax = PNG_cMax + 0.000001
#--
# 建立畫布
fig, ax = plt.subplots(figsize=((temp_PNG_Width / temp_PNG_DPI, temp_PNG_Height / temp_PNG_DPI)))
# 使用 ert.show() 來顯示資料，並自動決定色階範圍
ax, cbar = ert.show(
      Ohm_data,                    # 必須的參數：DataContainerERT 物件
      vals=Ohm_data['r']*Ohm_data['i'],          # 要繪製的數據
      ax=ax,                       # 指定畫在剛才建立的 ax 上
      logScale=False,              # 預設值：根據數據值來決定是否使用對數尺度，這裡默認使用對數尺度
      label='Voltage (V)',         # colorbar的標題，不填就自動產生Apparent resistivity (Ωm)。
      xlabel=None,                 # 預設值：x 軸標籤
      ylabel=None,                 # 預設值：y 軸標籤
      cMin=PNG_cMin,
      cMax=PNG_cMax
  )
# 確保是座標軸對象，並加入標題與軸標籤
ax.set_title(f"{os.path.basename(Input_Ohm_FileName)}\nVoltage Distribution ({Ohm_data_All_count}) Min/Max={np.min(Ohm_data['r']*Ohm_data['i']):.6f}/{np.max(Ohm_data['r']*Ohm_data['i']):.6f}", fontsize=14)
ax.set_xlabel("")
# 不用科學記號的 colorbar 數值
cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.ScalarFormatter(useMathText=False))
cbar.ax.xaxis.get_major_formatter().set_useOffset(False) #禁用「偏移量 (Offset)」模式
cbar.ax.xaxis.get_offset_text().set_visible(False)  # 避免顯示 1eX
#--
# 填入版本資訊
fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
#--
write_log_append(f'儲存 Voltage All圖片...')
Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_Distribution_V_All.png')
if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
    os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
plt.tight_layout() 
plt.savefig(Output_PNG_FileName, dpi=temp_PNG_DPI)
plt.close()
write_log_append(f'儲存 Voltage All圖片...完成!')
#--------------------------------------------
write_log_append('--')
#--------------------------------------------
# 繪圖 Current All
Main_FileName = temp_json_data["Output_MainFileName"]
temp_PNG_DPI = 100
temp_PNG_Width = 1280
temp_PNG_Height = 720
PNG_cMin = np.min(Ohm_data['i']) # None表示自動
PNG_cMax = np.max(Ohm_data['i']) # None表示自動
# 檢查是否所有數值都很接近
if (PNG_cMin - PNG_cMax) < 0.000002:
    # 如果很接近，設定極小的偏移量
    PNG_cMin = PNG_cMin - 0.000001
    PNG_cMax = PNG_cMax + 0.000001
#--
# 建立畫布
fig, ax = plt.subplots(figsize=((temp_PNG_Width / temp_PNG_DPI, temp_PNG_Height / temp_PNG_DPI)))
# 使用 ert.show() 來顯示資料，並自動決定色階範圍
ax, cbar = ert.show(
      Ohm_data,                    # 必須的參數：DataContainerERT 物件
      vals=Ohm_data['i'],          # 要繪製的數據
      ax=ax,                       # 指定畫在剛才建立的 ax 上
      logScale=False,              # 預設值：根據數據值來決定是否使用對數尺度，這裡默認使用對數尺度
      label='Current (A)',             # colorbar的標題，不填就自動產生Apparent resistivity (Ωm)。
      xlabel=None,                 # 預設值：x 軸標籤
      ylabel=None,                 # 預設值：y 軸標籤
      cMin=PNG_cMin,
      cMax=PNG_cMax
  )
# 確保是座標軸對象，並加入標題與軸標籤
ax.set_title(f"{os.path.basename(Input_Ohm_FileName)}\nCurrent Distribution ({Ohm_data_All_count}) Min/Max={np.min(Ohm_data['i']):.6f}/{np.max(Ohm_data['i']):.6f}", fontsize=14)
ax.set_xlabel("")
# 不用科學記號的 colorbar 數值
cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.ScalarFormatter(useMathText=False))
cbar.ax.xaxis.get_major_formatter().set_useOffset(False) #禁用「偏移量 (Offset)」模式
cbar.ax.xaxis.get_offset_text().set_visible(False)  # 避免顯示 1eX
#--
# 填入版本資訊
fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
#--
write_log_append(f'儲存 Current All圖片...')
Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_Distribution_I_All.png')
if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
    os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
plt.tight_layout() 
plt.savefig(Output_PNG_FileName, dpi=temp_PNG_DPI)
plt.close()
write_log_append(f'儲存 Current All圖片...完成!')
#--------------------------------------------
write_log_append('--')
#--------------------------------------------
# 繪圖 AppRes All
Main_FileName = temp_json_data["Output_MainFileName"]
temp_PNG_DPI = 100
temp_PNG_Width = 1280
temp_PNG_Height = 720
PNG_cMin = np.min(Ohm_data['rhoa']) # None表示自動
PNG_cMax = np.max(Ohm_data['rhoa']) # None表示自動
# 檢查是否所有數值都很接近
if (PNG_cMin - PNG_cMax) < 0.000002:
    # 如果很接近，設定極小的偏移量
    PNG_cMin = PNG_cMin - 0.000001
    PNG_cMax = PNG_cMax + 0.000001
#--
# 建立畫布
fig, ax = plt.subplots(figsize=((temp_PNG_Width / temp_PNG_DPI, temp_PNG_Height / temp_PNG_DPI)))
# 使用 ert.show() 來顯示資料，並自動決定色階範圍
ax, cbar = ert.show(
      Ohm_data,                    # 必須的參數：DataContainerERT 物件
      vals=Ohm_data['rhoa'],       # 要繪製的數據
      ax=ax,                       # 指定畫在剛才建立的 ax 上
      logScale=True,              # 預設值：根據數據值來決定是否使用對數尺度，這裡默認使用對數尺度
      label='Apparent resistivity (Ωm)',                  # colorbar的標題，不填就自動產生Apparent resistivity (Ωm)。
      xlabel=None,                 # 預設值：x 軸標籤
      ylabel=None,                 # 預設值：y 軸標籤
      cMin=PNG_cMin,
      cMax=PNG_cMax
  )
# 確保是座標軸對象，並加入標題與軸標籤
ax.set_title(f"{os.path.basename(Input_Ohm_FileName)}\nApparent Resistivity Distribution ({Ohm_data_All_count}) Min/Max={np.min(Ohm_data['rhoa']):.6f}/{np.max(Ohm_data['rhoa']):.6f}", fontsize=14)
ax.set_xlabel("")
# 不用科學記號的 colorbar 數值
cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.ScalarFormatter(useMathText=False))
cbar.ax.xaxis.get_major_formatter().set_useOffset(False) #禁用「偏移量 (Offset)」模式
cbar.ax.xaxis.get_offset_text().set_visible(False)  # 避免顯示 1eX
#--
# 填入版本資訊
fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
#--
write_log_append(f'儲存 AppRes All圖片...')
Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_Distribution_AppRes_All.png')
if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
    os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
plt.tight_layout() 
plt.savefig(Output_PNG_FileName, dpi=temp_PNG_DPI)
plt.close()
write_log_append(f'儲存 AppRes All圖片...完成!')
#--------------------------------------------
write_log_append('--')
#--------------------------------------------
# 繪圖 Error All
Main_FileName = temp_json_data["Output_MainFileName"]
temp_PNG_DPI = 100
temp_PNG_Width = 1280
temp_PNG_Height = 720
PNG_cMin = np.min(Ohm_data['err']*100) # None表示自動
PNG_cMax = np.max(Ohm_data['err']*100) # None表示自動
# 檢查是否所有數值都很接近
if (PNG_cMin - PNG_cMax) < 0.000002:
    # 如果很接近，設定極小的偏移量
    PNG_cMin = PNG_cMin - 0.000001
    PNG_cMax = PNG_cMax + 0.000001
#--
# 建立畫布
fig, ax = plt.subplots(figsize=((temp_PNG_Width / temp_PNG_DPI, temp_PNG_Height / temp_PNG_DPI)))
# 使用 ert.show() 來顯示資料，並自動決定色階範圍
ax, cbar = ert.show(
      Ohm_data,                    # 必須的參數：DataContainerERT 物件
      vals=Ohm_data['err']*100,    # 要繪製的數據
      ax=ax,                       # 指定畫在剛才建立的 ax 上
      logScale=False,              # 預設值：根據數據值來決定是否使用對數尺度，這裡默認使用對數尺度
      label='Error (%)',           # colorbar的標題，不填就自動產生Apparent resistivity (Ωm)。
      xlabel=None,                 # 預設值：x 軸標籤
      ylabel=None,                 # 預設值：y 軸標籤
      cMin=PNG_cMin,
      cMax=PNG_cMax
  )
# 確保是座標軸對象，並加入標題與軸標籤
ax.set_title(f"{os.path.basename(Input_Ohm_FileName)}\nError Distribution ({Ohm_data_All_count}) ({Ohm_data_All_count}) Min/Max={np.min(Ohm_data['err']*100):.6f}/{np.max(Ohm_data['err']*100):.6f}", fontsize=14)
ax.set_xlabel("")
# 不用科學記號的 colorbar 數值
cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.ScalarFormatter(useMathText=False))
cbar.ax.xaxis.get_major_formatter().set_useOffset(False) #禁用「偏移量 (Offset)」模式
cbar.ax.xaxis.get_offset_text().set_visible(False)  # 避免顯示 1eX
#--
# 填入版本資訊
fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
#--
write_log_append(f'儲存 Error All圖片...')
Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_Distribution_Error_All.png')
if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
    os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
plt.tight_layout() 
plt.savefig(Output_PNG_FileName, dpi=temp_PNG_DPI)
plt.close()
write_log_append(f'儲存 Error All圖片...完成!')
#--------------------------------------------
write_log_append('--')
#--------------------------------------------
# 繪圖 Geometric_Factor All
Main_FileName = temp_json_data["Output_MainFileName"]
temp_PNG_DPI = 100
temp_PNG_Width = 1280
temp_PNG_Height = 720
PNG_cMin = np.min(Ohm_data['k']) # None表示自動
PNG_cMax = np.max(Ohm_data['k']) # None表示自動
# 檢查是否所有數值都很接近
if (PNG_cMin - PNG_cMax) < 0.000002:
    # 如果很接近，設定極小的偏移量
    PNG_cMin = PNG_cMin - 0.000001
    PNG_cMax = PNG_cMax + 0.000001
#--
# 建立畫布
fig, ax = plt.subplots(figsize=((temp_PNG_Width / temp_PNG_DPI, temp_PNG_Height / temp_PNG_DPI)))
# 使用 ert.show() 來顯示資料，並自動決定色階範圍
ax, cbar = ert.show(
      Ohm_data,                    # 必須的參數：DataContainerERT 物件
      vals=Ohm_data['k'],          # 要繪製的數據
      ax=ax,                       # 指定畫在剛才建立的 ax 上
      logScale=False,              # 預設值：根據數據值來決定是否使用對數尺度，這裡默認使用對數尺度
      label='K (m)',               # colorbar的標題，不填就自動產生Apparent resistivity (Ωm)。
      xlabel=None,                 # 預設值：x 軸標籤
      ylabel=None,                 # 預設值：y 軸標籤
      cMin=PNG_cMin,
      cMax=PNG_cMax
  )
# 確保是座標軸對象，並加入標題與軸標籤
ax.set_title(f"{os.path.basename(Input_Ohm_FileName)}\nGeometric Factor K Distribution ({Ohm_data_All_count}) Min/Max={np.min(Ohm_data['k']):.6f}/{np.max(Ohm_data['k']):.6f}", fontsize=14)
ax.set_xlabel("")
# 不用科學記號的 colorbar 數值
cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.ScalarFormatter(useMathText=False))
cbar.ax.xaxis.get_major_formatter().set_useOffset(False) #禁用「偏移量 (Offset)」模式
cbar.ax.xaxis.get_offset_text().set_visible(False)  # 避免顯示 1eX
#--
# 填入版本資訊
fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
#--
write_log_append(f'儲存 Geometric_Factor All圖片...')
Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_Distribution_K_All.png')
if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
    os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
plt.tight_layout() 
plt.savefig(Output_PNG_FileName, dpi=temp_PNG_DPI)
plt.close()
write_log_append(f'儲存 Geometric_Factor All圖片...完成!')
#--------------------------------------------
write_log_append('--')
#--------------------------------------------
# 繪圖 Geometric_Factor MeshEffect = K_Mesh / K_Ideal
Main_FileName = temp_json_data["Output_MainFileName"]
temp_PNG_DPI = 100
temp_PNG_Width = 1280
temp_PNG_Height = 720
Ohm_data['MeshEffect'] = Ohm_data['k'] / K_Ideal *100 #MeshEffect = K_Mesh / K_Ideal
PNG_cMin = np.min(Ohm_data['MeshEffect']) # None表示自動
PNG_cMax = np.max(Ohm_data['MeshEffect']) # None表示自動
# 檢查是否所有數值都很接近
if (PNG_cMin - PNG_cMax) < 0.000002:
    # 如果很接近，設定極小的偏移量
    PNG_cMin = PNG_cMin - 0.000001
    PNG_cMax = PNG_cMax + 0.000001
#--
# 建立畫布
fig, ax = plt.subplots(figsize=((temp_PNG_Width / temp_PNG_DPI, temp_PNG_Height / temp_PNG_DPI)))
# 使用 ert.show() 來顯示資料，並自動決定色階範圍
ax, cbar = ert.show(
      Ohm_data,                    # 必須的參數：DataContainerERT 物件
      vals=Ohm_data['MeshEffect'],          # 要繪製的數據
      ax=ax,                       # 指定畫在剛才建立的 ax 上
      logScale=False,              # 預設值：根據數據值來決定是否使用對數尺度，這裡默認使用對數尺度
      label='MeshEffect (%)',               # colorbar的標題，不填就自動產生Apparent resistivity (Ωm)。
      xlabel=None,                 # 預設值：x 軸標籤
      ylabel=None,                 # 預設值：y 軸標籤
      cMin=PNG_cMin,
      cMax=PNG_cMax
  )
# 確保是座標軸對象，並加入標題與軸標籤
ax.set_title(f"{os.path.basename(Input_Ohm_FileName)}\nMeshEffect(K_Mesh / K_Ideal) Distribution ({Ohm_data_All_count}) Min/Max={np.min(Ohm_data['MeshEffect']):.6f}/{np.max(Ohm_data['MeshEffect']):.6f}", fontsize=14)
ax.set_xlabel("")
# 不用科學記號的 colorbar 數值
cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.ScalarFormatter(useMathText=False))
cbar.ax.xaxis.get_major_formatter().set_useOffset(False) #禁用「偏移量 (Offset)」模式
cbar.ax.xaxis.get_offset_text().set_visible(False)  # 避免顯示 1eX
#--
# 填入版本資訊
fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
#--
write_log_append(f'儲存 Geometric_Factor MeshEffect圖片...')
Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_Distribution_MeshEffect_All.png')
if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
    os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
plt.tight_layout() 
plt.savefig(Output_PNG_FileName, dpi=temp_PNG_DPI)
plt.close()
write_log_append(f'儲存 Geometric_Factor MeshEffect圖片...完成!')
#--------------------------------------------
write_log_append('--')
if temp_json_data["Data_Setting12_UseFakeData_Enable"] == 'Yes' :
    write_log_append("使用假的視電阻率資料...")
    Ohm_data['rhoa'] = (Ohm_data['rhoa']*0) + float(temp_json_data["Data_Setting13_UseFakeData_rhoa"]) 
    Ohm_data['r'] = Ohm_data['rhoa']/Ohm_data['k']
    Ohm_data['i'] = (Ohm_data['i']*0) + 1
    Ohm_data_Accept_count = Ohm_data.size()
    All_Electrode_Index_1Base = np.arange(Ohm_data.sensorCount())
    All_Electrode_Index_0Base = All_Electrode_Index_1Base-1
    Bad_Electrode_Index_1Base = np.array([])
    Bad_Electrode_Index_0Base = Bad_Electrode_Index_1Base-1
    Good_Electrode_Index_1Base = All_Electrode_Index_1Base
    Good_Electrode_Index_0Base = Good_Electrode_Index_1Base-1
    write_log_append("使用假的視電阻率資料...完成!")
else:
    #--------------------------------------------
    write_log_append("移除負的視電阻率資料...")
    # PyGimli本來就不允許電阻率為0，所以不必特別移除為0的
    write_log_append(f"移除之前的觀測資料數量: {Ohm_data_All_count}")
    Ohm_data.remove(Ohm_data['rhoa'] <= 0)
    Ohm_data_Accept_count = Ohm_data.size()
    write_log_append(f"移除之後的觀測資料數量: {Ohm_data_Accept_count}")
    write_log_append("移除負的視電阻率資料...完成!")
    write_log_append('--')
    #--
    write_log_append(f"移除過小電流(<{temp_json_data["Data_Setting03_RemoveLowCurrentData_LowerThan_A"]}[A])的視電阻率資料...")
    write_log_append(f"移除之前的觀測資料數量: {Ohm_data_All_count}")
    Ohm_data.remove(Ohm_data['i'] < temp_json_data["Data_Setting03_RemoveLowCurrentData_LowerThan_A"])
    Ohm_data_Accept_count = Ohm_data.size()
    write_log_append(f"移除之後的觀測資料數量: {Ohm_data_Accept_count}")
    write_log_append(f"移除過小電流(<{temp_json_data["Data_Setting03_RemoveLowCurrentData_LowerThan_A"]}[A])的視電阻率資料...完成!")
    write_log_append('--')
    #--
    write_log_append(f"移除過大電流(>{temp_json_data["Data_Setting04_RemoveHighCurrentData_HigherThan_A"]}[A])的視電阻率資料...")
    write_log_append(f"移除之前的觀測資料數量: {Ohm_data_All_count}")
    Ohm_data.remove(Ohm_data['i'] > temp_json_data["Data_Setting04_RemoveHighCurrentData_HigherThan_A"])
    Ohm_data_Accept_count = Ohm_data.size()
    write_log_append(f"移除之後的觀測資料數量: {Ohm_data_Accept_count}")
    write_log_append(f"移除過大電流(>{temp_json_data["Data_Setting04_RemoveHighCurrentData_HigherThan_A"]}[A])的視電阻率資料...完成!")
    write_log_append('--')
    #--
    write_log_append(f"移除過小電壓(<{temp_json_data["Data_Setting05_RemoveLowVoltageData_LowerThan_V"]}[V])的視電阻率資料...")
    write_log_append(f"移除之前的觀測資料數量: {Ohm_data_All_count}")
    Ohm_data.remove((Ohm_data['r']*Ohm_data['i']) < temp_json_data["Data_Setting05_RemoveLowVoltageData_LowerThan_V"])
    Ohm_data_Accept_count = Ohm_data.size()
    write_log_append(f"移除之後的觀測資料數量: {Ohm_data_Accept_count}")
    write_log_append(f"移除過小電壓(<{temp_json_data["Data_Setting05_RemoveLowVoltageData_LowerThan_V"]}[V])的視電阻率資料...完成!")
    write_log_append('--')
    #--
    write_log_append(f"移除過大電壓(>{temp_json_data["Data_Setting06_RemoveHighVoltageData_HigherThan_V"]}[V])的視電阻率資料...")
    write_log_append(f"移除之前的觀測資料數量: {Ohm_data_All_count}")
    Ohm_data.remove((Ohm_data['r']*Ohm_data['i']) > temp_json_data["Data_Setting06_RemoveHighVoltageData_HigherThan_V"])
    Ohm_data_Accept_count = Ohm_data.size()
    write_log_append(f"移除之後的觀測資料數量: {Ohm_data_Accept_count}")
    write_log_append(f"移除過大電壓(>{temp_json_data["Data_Setting06_RemoveHighVoltageData_HigherThan_V"]}[V])的視電阻率資料...完成!")
    write_log_append('--')
    #--
    write_log_append(f"移除過小視電阻率(<{temp_json_data["Data_Setting07_RemoveLowAppResData_LowerThan_OhmM"]}[Ohm-m])的視電阻率資料...")
    write_log_append(f"移除之前的觀測資料數量: {Ohm_data_All_count}")
    Ohm_data.remove(Ohm_data['rhoa'] < temp_json_data["Data_Setting07_RemoveLowAppResData_LowerThan_OhmM"])
    Ohm_data_Accept_count = Ohm_data.size()
    write_log_append(f"移除之後的觀測資料數量: {Ohm_data_Accept_count}")
    write_log_append(f"移除過小視電阻率(<{temp_json_data["Data_Setting07_RemoveLowAppResData_LowerThan_OhmM"]}[Ohm-m])的視電阻率資料...完成!")
    write_log_append('--')
    #--
    write_log_append(f"移除過大視電阻率(>{temp_json_data["Data_Setting08_RemoveHighAppResData_HigherThan_OhmM"]}[Ohm-m])的視電阻率資料...")
    write_log_append(f"移除之前的觀測資料數量: {Ohm_data_All_count}")
    Ohm_data.remove(Ohm_data['rhoa'] > temp_json_data["Data_Setting08_RemoveHighAppResData_HigherThan_OhmM"])
    Ohm_data_Accept_count = Ohm_data.size()
    write_log_append(f"移除之後的觀測資料數量: {Ohm_data_Accept_count}")
    write_log_append(f"移除過大視電阻率(>{temp_json_data["Data_Setting08_RemoveHighAppResData_HigherThan_OhmM"]}[Ohm-m])的視電阻率資料...完成!")
    write_log_append('--')
    #--
    write_log_append(f"移除過小網格效應(<{temp_json_data["Data_Setting10_RemoveLowMeshEffectData_LowerThan_Percent"]}[%])的視電阻率資料...")
    write_log_append(f"移除之前的觀測資料數量: {Ohm_data_All_count}")
    Ohm_data.remove(Ohm_data['MeshEffect'] < temp_json_data["Data_Setting10_RemoveLowMeshEffectData_LowerThan_Percent"])
    Ohm_data_Accept_count = Ohm_data.size()
    write_log_append(f"移除之後的觀測資料數量: {Ohm_data_Accept_count}")
    write_log_append(f"移除過小網格效應(<{temp_json_data["Data_Setting10_RemoveLowMeshEffectData_LowerThan_Percent"]}[%])的視電阻率資料...完成!")
    write_log_append('--')
    #--
    write_log_append(f"移除過大網格效應(>{temp_json_data["Data_Setting11_RemoveHighMeshEffectData_HigherThan_Percent"]}[%])的視電阻率資料...")
    write_log_append(f"移除之前的觀測資料數量: {Ohm_data_All_count}")
    Ohm_data.remove(Ohm_data['MeshEffect'] > temp_json_data["Data_Setting11_RemoveHighMeshEffectData_HigherThan_Percent"])
    Ohm_data_Accept_count = Ohm_data.size()
    write_log_append(f"移除之後的觀測資料數量: {Ohm_data_Accept_count}")
    write_log_append(f"移除過大網格效應(>{temp_json_data["Data_Setting11_RemoveHighMeshEffectData_HigherThan_Percent"]}[%])的視電阻率資料...完成!")
    write_log_append('--')
    #--
    All_Electrode_Index_1Base = np.arange(Ohm_data.sensorCount())
    All_Electrode_Index_0Base = All_Electrode_Index_1Base-1
    Bad_Electrode_Index_1Base = np.array(temp_json_data["Data_Setting09_RemoveBadElectrodeData_List"])
    Bad_Electrode_Index_0Base = Bad_Electrode_Index_1Base-1
    Good_Electrode_Index_1Base = All_Electrode_Index_1Base[~np.isin(All_Electrode_Index_1Base, Bad_Electrode_Index_1Base)]
    Good_Electrode_Index_0Base = Good_Electrode_Index_1Base-1
    write_log_append(f"移除不採用(損壞)電極(數量={len(Bad_Electrode_Index_1Base)},清單={Bad_Electrode_Index_1Base})的視電阻率資料...")
    write_log_append(f"移除之前的觀測資料數量: {Ohm_data_All_count}")
    for sensor in ['a', 'b', 'm', 'n']:
        Ohm_data.remove(np.isin(Ohm_data[sensor], Bad_Electrode_Index_1Base))
    Ohm_data_Accept_count = Ohm_data.size()
    write_log_append(f"移除之後的觀測資料數量: {Ohm_data_Accept_count}")
    write_log_append(f"移除不採用(損壞)電極(數量={len(Bad_Electrode_Index_1Base)},清單={Bad_Electrode_Index_1Base})的視電阻率資料...完成!")
    #--------------------------------------------
if Ohm_data_Accept_count == 0:
    write_log_append('--')
    write_log_append(f"錯誤：沒有可用的觀測資料。觀測資料數量 = {Ohm_data_Accept_count}。")
    write_log_append('--')
    exit(1)
write_log_append('--')
#--------------------------------------------
# 繪圖 V/I Accept
Main_FileName = temp_json_data["Output_MainFileName"]
temp_PNG_DPI = 100
temp_PNG_Width = 1280
temp_PNG_Height = 720
PNG_cMin = np.min(Ohm_data['r']) # None表示自動
PNG_cMax = np.max(Ohm_data['r']) # None表示自動
# 檢查是否所有數值都很接近
if (PNG_cMin - PNG_cMax) < 0.000002:
    # 如果很接近，設定極小的偏移量
    PNG_cMin = PNG_cMin - 0.000001
    PNG_cMax = PNG_cMax + 0.000001
#--
# 建立畫布
fig, ax = plt.subplots(figsize=((temp_PNG_Width / temp_PNG_DPI, temp_PNG_Height / temp_PNG_DPI)))
# 使用 ert.show() 來顯示資料，並自動決定色階範圍
ax, cbar = ert.show(
      Ohm_data,                    # 必須的參數：DataContainerERT 物件
      vals=Ohm_data['r'],          # 要繪製的數據
      ax=ax,                       # 指定畫在剛才建立的 ax 上
      logScale=False,              # 預設值：根據數據值來決定是否使用對數尺度，這裡默認使用對數尺度
      label='V/I (Ω)',                  # colorbar的標題，不填就自動產生Apparent resistivity (Ωm)。
      xlabel=None,                 # 預設值：x 軸標籤
      ylabel=None,                 # 預設值：y 軸標籤
      cMin=PNG_cMin,
      cMax=PNG_cMax
  )
# 確保是座標軸對象，並加入標題與軸標籤
ax.set_title(f"{os.path.basename(Input_Ohm_FileName)}\nAccepted V/I Distribution ({Ohm_data_Accept_count}/{Ohm_data_All_count}) Min/Max={np.min(Ohm_data['r']):.6f}/{np.max(Ohm_data['r']):.6f}", fontsize=14)
ax.set_xlabel("")
# 不用科學記號的 colorbar 數值
cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.ScalarFormatter(useMathText=False))
cbar.ax.xaxis.get_major_formatter().set_useOffset(False) #禁用「偏移量 (Offset)」模式
cbar.ax.xaxis.get_offset_text().set_visible(False)  # 避免顯示 1eX
#--
# 填入版本資訊
fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
#--
write_log_append(f'儲存 V/I Accept圖片...')
Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_Distribution_VoverI_Accept.png')
if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
    os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
plt.tight_layout() 
plt.savefig(Output_PNG_FileName, dpi=temp_PNG_DPI)
plt.close()
write_log_append(f'儲存 V/I Accept圖片...完成!')
#--------------------------------------------
write_log_append('--')
#--------------------------------------------
# 繪圖 Voltage Accept
Main_FileName = temp_json_data["Output_MainFileName"]
temp_PNG_DPI = 100
temp_PNG_Width = 1280
temp_PNG_Height = 720
PNG_cMin = np.min(Ohm_data['r']*Ohm_data['i']) # None表示自動
PNG_cMax = np.max(Ohm_data['r']*Ohm_data['i']) # None表示自動
# 檢查是否所有數值都很接近
if (PNG_cMin - PNG_cMax) < 0.000002:
    # 如果很接近，設定極小的偏移量
    PNG_cMin = PNG_cMin - 0.000001
    PNG_cMax = PNG_cMax + 0.000001
#--
#--
# 建立畫布
fig, ax = plt.subplots(figsize=((temp_PNG_Width / temp_PNG_DPI, temp_PNG_Height / temp_PNG_DPI)))
# 使用 ert.show() 來顯示資料，並自動決定色階範圍
ax, cbar = ert.show(
      Ohm_data,                    # 必須的參數：DataContainerERT 物件
      vals=Ohm_data['r']*Ohm_data['i'],          # 要繪製的數據
      ax=ax,                       # 指定畫在剛才建立的 ax 上
      logScale=False,              # 預設值：根據數據值來決定是否使用對數尺度，這裡默認使用對數尺度
      label='Voltage (V)',         # colorbar的標題，不填就自動產生Apparent resistivity (Ωm)。
      xlabel=None,                 # 預設值：x 軸標籤
      ylabel=None,                 # 預設值：y 軸標籤
      cMin=PNG_cMin,
      cMax=PNG_cMax
  )
# 確保是座標軸對象，並加入標題與軸標籤
ax.set_title(f"{os.path.basename(Input_Ohm_FileName)}\nAccepted Voltage Distribution ({Ohm_data_Accept_count}/{Ohm_data_All_count}) Min/Max={np.min(Ohm_data['r']*Ohm_data['i']):.6f}/{np.max(Ohm_data['r']*Ohm_data['i']):.6f}", fontsize=14)
ax.set_xlabel("")
# 不用科學記號的 colorbar 數值
cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.ScalarFormatter(useMathText=False))
cbar.ax.xaxis.get_major_formatter().set_useOffset(False) #禁用「偏移量 (Offset)」模式
cbar.ax.xaxis.get_offset_text().set_visible(False)  # 避免顯示 1eX
#--
# 填入版本資訊
fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
#--
write_log_append(f'儲存 Voltage Accept圖片...')
Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_Distribution_V_Accept.png')
if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
    os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
plt.tight_layout() 
plt.savefig(Output_PNG_FileName, dpi=temp_PNG_DPI)
plt.close()
write_log_append(f'儲存 Voltage Accept圖片...完成!')
#--------------------------------------------
write_log_append('--')
#--------------------------------------------
# 繪圖 Current Accept
Main_FileName = temp_json_data["Output_MainFileName"]
temp_PNG_DPI = 100
temp_PNG_Width = 1280
temp_PNG_Height = 720
PNG_cMin = np.min(Ohm_data['i']) # None表示自動
PNG_cMax = np.max(Ohm_data['i']) # None表示自動
# 檢查是否所有數值都很接近
if (PNG_cMin - PNG_cMax) < 0.000002:
    # 如果很接近，設定極小的偏移量
    PNG_cMin = PNG_cMin - 0.000001
    PNG_cMax = PNG_cMax + 0.000001
#--
# 建立畫布
fig, ax = plt.subplots(figsize=((temp_PNG_Width / temp_PNG_DPI, temp_PNG_Height / temp_PNG_DPI)))
# 使用 ert.show() 來顯示資料，並自動決定色階範圍
ax, cbar = ert.show(
      Ohm_data,                    # 必須的參數：DataContainerERT 物件
      vals=Ohm_data['i'],          # 要繪製的數據
      ax=ax,                       # 指定畫在剛才建立的 ax 上
      logScale=False,              # 預設值：根據數據值來決定是否使用對數尺度，這裡默認使用對數尺度
      label='Current (A)',         # colorbar的標題，不填就自動產生Apparent resistivity (Ωm)。
      xlabel=None,                 # 預設值：x 軸標籤
      ylabel=None,                 # 預設值：y 軸標籤
      cMin=PNG_cMin,
      cMax=PNG_cMax
  )
# 確保是座標軸對象，並加入標題與軸標籤
ax.set_title(f"{os.path.basename(Input_Ohm_FileName)}\nAccepted Current Distribution ({Ohm_data_Accept_count}/{Ohm_data_All_count}) Min/Max={np.min(Ohm_data['i']):.6f}/{np.max(Ohm_data['i']):.6f}", fontsize=14)
ax.set_xlabel("")
# 不用科學記號的 colorbar 數值
cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.ScalarFormatter(useMathText=False))
cbar.ax.xaxis.get_major_formatter().set_useOffset(False) #禁用「偏移量 (Offset)」模式
cbar.ax.xaxis.get_offset_text().set_visible(False)  # 避免顯示 1eX
#--
# 填入版本資訊
fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
#--
write_log_append(f'儲存 Current Accept圖片...')
Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_Distribution_I_Accept.png')
if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
    os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
plt.tight_layout() 
plt.savefig(Output_PNG_FileName, dpi=temp_PNG_DPI)
plt.close()
write_log_append(f'儲存 Current Accept圖片...完成!')
#--------------------------------------------
write_log_append('--')
#--------------------------------------------
# 繪圖 AppRes Accept
Main_FileName = temp_json_data["Output_MainFileName"]
temp_PNG_DPI = 100
temp_PNG_Width = 1280
temp_PNG_Height = 720
PNG_cMin = np.min(Ohm_data['rhoa']) # None表示自動
PNG_cMax = np.max(Ohm_data['rhoa']) # None表示自動
# 檢查是否所有數值都很接近
if (PNG_cMin - PNG_cMax) < 0.000002:
    # 如果很接近，設定極小的偏移量
    PNG_cMin = PNG_cMin - 0.000001
    PNG_cMax = PNG_cMax + 0.000001
#--
# 建立畫布
fig, ax = plt.subplots(figsize=((temp_PNG_Width / temp_PNG_DPI, temp_PNG_Height / temp_PNG_DPI)))
# 使用 ert.show() 來顯示資料，並自動決定色階範圍
ax, cbar = ert.show(
      Ohm_data,                    # 必須的參數：DataContainerERT 物件
      vals=Ohm_data['rhoa'],       # 要繪製的數據
      ax=ax,                       # 指定畫在剛才建立的 ax 上
      logScale=True,               # 預設值：根據數據值來決定是否使用對數尺度，這裡默認使用對數尺度
      label='Apparent resistivity (Ωm)',                  # colorbar的標題，不填就自動產生Apparent resistivity (Ωm)。
      xlabel=None,                 # 預設值：x 軸標籤
      ylabel=None,                 # 預設值：y 軸標籤
      cMin=PNG_cMin,
      cMax=PNG_cMax
  )
# 確保是座標軸對象，並加入標題與軸標籤
ax.set_title(f"{os.path.basename(Input_Ohm_FileName)}\nAccepted Apparent Resistivity Distribution ({Ohm_data_Accept_count}/{Ohm_data_All_count}) Min/Max={np.min(Ohm_data['rhoa']):.6f}/{np.max(Ohm_data['rhoa']):.6f}", fontsize=14)
ax.set_xlabel("")
# 不用科學記號的 colorbar 數值
cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.ScalarFormatter(useMathText=False))
cbar.ax.xaxis.get_major_formatter().set_useOffset(False) #禁用「偏移量 (Offset)」模式
cbar.ax.xaxis.get_offset_text().set_visible(False)  # 避免顯示 1eX
#--
# 填入版本資訊
fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
#--
write_log_append(f'儲存 AppRes Accept圖片...')
Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_Distribution_AppRes_Accept.png')
if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
    os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
plt.tight_layout() 
plt.savefig(Output_PNG_FileName, dpi=temp_PNG_DPI)
plt.close()
write_log_append(f'儲存 AppRes Accept圖片...完成!')
#--------------------------------------------
write_log_append('--')
#--------------------------------------------
# 繪圖 Error Accept
Main_FileName = temp_json_data["Output_MainFileName"]
temp_PNG_DPI = 100
temp_PNG_Width = 1280
temp_PNG_Height = 720
PNG_cMin = np.min(Ohm_data['err']*100) # None表示自動
PNG_cMax = np.max(Ohm_data['err']*100) # None表示自動
# 檢查是否所有數值都很接近
if (PNG_cMin - PNG_cMax) < 0.000002:
    # 如果很接近，設定極小的偏移量
    PNG_cMin = PNG_cMin - 0.000001
    PNG_cMax = PNG_cMax + 0.000001
#--
# 建立畫布
fig, ax = plt.subplots(figsize=((temp_PNG_Width / temp_PNG_DPI, temp_PNG_Height / temp_PNG_DPI)))
# 使用 ert.show() 來顯示資料，並自動決定色階範圍
ax, cbar = ert.show(
      Ohm_data,                    # 必須的參數：DataContainerERT 物件
      vals=Ohm_data['err']*100,    # 要繪製的數據
      ax=ax,                       # 指定畫在剛才建立的 ax 上
      logScale=False,              # 預設值：根據數據值來決定是否使用對數尺度，這裡默認使用對數尺度
      label='Error (%)',           # colorbar的標題，不填就自動產生Apparent resistivity (Ωm)。
      xlabel=None,                 # 預設值：x 軸標籤
      ylabel=None,                 # 預設值：y 軸標籤
      cMin=PNG_cMin,
      cMax=PNG_cMax
  )
# 確保是座標軸對象，並加入標題與軸標籤
ax.set_title(f"{os.path.basename(Input_Ohm_FileName)}\nAccepted Error Distribution ({Ohm_data_Accept_count}/{Ohm_data_All_count}) Min/Max={np.min(Ohm_data['err']*100):.6f}/{np.max(Ohm_data['err']*100):.6f}", fontsize=14)
ax.set_xlabel("")
# 不用科學記號的 colorbar 數值
cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.ScalarFormatter(useMathText=False))
cbar.ax.xaxis.get_major_formatter().set_useOffset(False) #禁用「偏移量 (Offset)」模式
cbar.ax.xaxis.get_offset_text().set_visible(False)  # 避免顯示 1eX
#--
# 填入版本資訊
fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
#--
write_log_append(f'儲存 Error Accept圖片...')
Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_Distribution_Error_Accept.png')
if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
    os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
plt.tight_layout() 
plt.savefig(Output_PNG_FileName, dpi=temp_PNG_DPI)
plt.close()
write_log_append(f'儲存 Error Accept圖片...完成!')
#--------------------------------------------
write_log_append('--')
#--------------------------------------------
# 繪圖 Geometric_Factor Accept
Main_FileName = temp_json_data["Output_MainFileName"]
temp_PNG_DPI = 100
temp_PNG_Width = 1280
temp_PNG_Height = 720
PNG_cMin = np.min(Ohm_data['k']) # None表示自動
PNG_cMax = np.max(Ohm_data['k']) # None表示自動
# 檢查是否所有數值都很接近
if (PNG_cMin - PNG_cMax) < 0.000002:
    # 如果很接近，設定極小的偏移量
    PNG_cMin = PNG_cMin - 0.000001
    PNG_cMax = PNG_cMax + 0.000001
#--
# 建立畫布
fig, ax = plt.subplots(figsize=((temp_PNG_Width / temp_PNG_DPI, temp_PNG_Height / temp_PNG_DPI)))
# 使用 ert.show() 來顯示資料，並自動決定色階範圍
ax, cbar = ert.show(
      Ohm_data,                    # 必須的參數：DataContainerERT 物件
      vals=Ohm_data['k'],          # 要繪製的數據
      ax=ax,                       # 指定畫在剛才建立的 ax 上
      logScale=False,              # 預設值：根據數據值來決定是否使用對數尺度，這裡默認使用對數尺度
      label='K (m)',               # colorbar的標題，不填就自動產生Apparent resistivity (Ωm)。
      xlabel=None,                 # 預設值：x 軸標籤
      ylabel=None,                 # 預設值：y 軸標籤
      cMin=PNG_cMin,
      cMax=PNG_cMax
  )
# 確保是座標軸對象，並加入標題與軸標籤
ax.set_title(f"{os.path.basename(Input_Ohm_FileName)}\nAccepted Geometric Factor K Distribution ({Ohm_data_Accept_count}/{Ohm_data_All_count}) Min/Max={np.min(Ohm_data['k']):.6f}/{np.max(Ohm_data['k']):.6f}", fontsize=14)
ax.set_xlabel("")
# 不用科學記號的 colorbar 數值
cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.ScalarFormatter(useMathText=False))
cbar.ax.xaxis.get_major_formatter().set_useOffset(False) #禁用「偏移量 (Offset)」模式
cbar.ax.xaxis.get_offset_text().set_visible(False)  # 避免顯示 1eX
#--
# 填入版本資訊
fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
#--
write_log_append(f'儲存 Geometric_Factor Accept圖片...')
Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_Distribution_K_Accept.png')
if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
    os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
plt.tight_layout() 
plt.savefig(Output_PNG_FileName, dpi=temp_PNG_DPI)
plt.close()
write_log_append(f'儲存 Geometric_Factor Accept圖片...完成!')
#--------------------------------------------
write_log_append('--')
#--------------------------------------------
# 繪圖 Geometric_Factor MeshEffect = K_Mesh / K_Ideal Accept
Main_FileName = temp_json_data["Output_MainFileName"]
temp_PNG_DPI = 100
temp_PNG_Width = 1280
temp_PNG_Height = 720
PNG_cMin = np.min(Ohm_data['MeshEffect']) # None表示自動
PNG_cMax = np.max(Ohm_data['MeshEffect']) # None表示自動
# 檢查是否所有數值都很接近
if (PNG_cMin - PNG_cMax) < 0.000002:
    # 如果很接近，設定極小的偏移量
    PNG_cMin = PNG_cMin - 0.000001
    PNG_cMax = PNG_cMax + 0.000001
#--
# 建立畫布
fig, ax = plt.subplots(figsize=((temp_PNG_Width / temp_PNG_DPI, temp_PNG_Height / temp_PNG_DPI)))
# 使用 ert.show() 來顯示資料，並自動決定色階範圍
ax, cbar = ert.show(
      Ohm_data,                    # 必須的參數：DataContainerERT 物件
      vals=Ohm_data['MeshEffect'],          # 要繪製的數據
      ax=ax,                       # 指定畫在剛才建立的 ax 上
      logScale=False,              # 預設值：根據數據值來決定是否使用對數尺度，這裡默認使用對數尺度
      label='MeshEffect (%)',               # colorbar的標題，不填就自動產生Apparent resistivity (Ωm)。
      xlabel=None,                 # 預設值：x 軸標籤
      ylabel=None,                 # 預設值：y 軸標籤
      cMin=PNG_cMin,
      cMax=PNG_cMax
  )
ax.set_title(f"{os.path.basename(Input_Ohm_FileName)}\nMeshEffect(K_Mesh / K_Ideal) Distribution ({Ohm_data_All_count}) Min/Max={np.min(Ohm_data['MeshEffect']):.6f}/{np.max(Ohm_data['MeshEffect']):.6f}", fontsize=14)
ax.set_xlabel("")
# 不用科學記號的 colorbar 數值
cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.ScalarFormatter(useMathText=False))
cbar.ax.xaxis.get_major_formatter().set_useOffset(False) #禁用「偏移量 (Offset)」模式
cbar.ax.xaxis.get_offset_text().set_visible(False)  # 避免顯示 1eX
#--
# 填入版本資訊
fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
#--
write_log_append(f'儲存 Geometric_Factor MeshEffect圖片...')
Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_Distribution_MeshEffect_Accept.png')
if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
    os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
plt.tight_layout() 
plt.savefig(Output_PNG_FileName, dpi=temp_PNG_DPI)
plt.close()
write_log_append(f'儲存 Geometric_Factor MeshEffect圖片...完成!')
#--------------------------------------------
write_log_append('--')
#--------------------------------------------
# 繪圖 直方圖 Accept
#--
Main_FileName = temp_json_data["Output_MainFileName"]
temp_PNG_DPI = 100
temp_PNG_Width = 1280
temp_PNG_Height = 720
#--
# 建立畫布
fig, axes = plt.subplots(1, 2, figsize=((temp_PNG_Width / temp_PNG_DPI, temp_PNG_Height / temp_PNG_DPI)))
#--
# 子圖1 視電阻率分佈直方圖 (Linear-Scale Histogram)
#--
# 直方圖統計 所有值
axes[0].hist(Ohm_data['rhoa'], bins=50, color='skyblue', edgecolor='black', alpha=0.5)
# 加入中位數線 
axes[0].axvline(np.median(Ohm_data['rhoa']), color='red', linestyle='dashed', linewidth=1.5, label=f'Median: {(np.median(Ohm_data["rhoa"])):.2f} (Ωm)')
axes[0].legend()
axes[0].set_title(f"""Apparent Resistivity Histogram (Linear-Scale)
Data count = {Ohm_data_Accept_count}, Min/Max = {np.min(Ohm_data['rhoa']):.2f}/{np.max(Ohm_data['rhoa']):.2f} (Ωm)
Mean/Median/GeometricMean = {np.mean(Ohm_data['rhoa']):.2f}/{np.median(Ohm_data['rhoa']):.2f}/{10**np.mean(np.log10(Ohm_data['rhoa'])):.2f} (Ωm)""", 
fontsize=12)
axes[0].set_xlabel('Apparent Resistivity (Ωm)')
axes[0].set_ylabel('Data Count (Count)')
axes[0].grid(True, linestyle='--', alpha=0.6)
#--
# 子圖2 視電阻率分佈直方圖 (Log-Scale Histogram)
#--
# 直方圖統計 僅正值(因為之前就移除負的，這裡就不特別檢查)
axes[1].hist(np.log10(Ohm_data['rhoa']), bins=50, color='skyblue', edgecolor='black', alpha=0.5)
# 加入中位數線 
axes[1].axvline(np.log10(np.median(Ohm_data['rhoa'])), color='red', linestyle='dashed', linewidth=1.5, label=f'Median: {(np.log10(np.median(Ohm_data["rhoa"]))):.2f} (Log10 Ωm)')
axes[1].legend()
axes[1].set_title(f"""Apparent Resistivity Histogram (Log-Scale)
Data count = {Ohm_data_Accept_count}, Min/Max = {np.log10(np.min(Ohm_data['rhoa'])):.2f}/{np.log10(np.max(Ohm_data['rhoa'])):.2f} (Log10 Ωm)
Mean/Median/GeometricMean = {np.log10(np.mean(Ohm_data['rhoa'])):.2f}/{np.log10(np.median(Ohm_data['rhoa'])):.2f}/{np.mean(np.log10(Ohm_data['rhoa'])):.2f} (Log10 Ωm)""", 
fontsize=12)
axes[1].set_xlabel('Apparent Resistivity (Log10 Ωm)')
axes[1].set_ylabel('Data Count (Count)')
axes[1].grid(True, linestyle='--', alpha=0.6)
#--
# 填入總標題
fig.suptitle(f'{os.path.splitext(os.path.basename(Input_Ohm_FileName))[0]}', fontsize=16, fontweight='bold')  
# 填入版本資訊
fig.text(0.98, 0.005, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
#--
write_log_append(f'儲存 AppRes_Histogram 統計圖片...')
Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_02_Histogram_AppRes_Accept.png')
if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
    os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
plt.tight_layout() 
plt.savefig(Output_PNG_FileName, dpi=temp_PNG_DPI)
plt.close()
write_log_append(f'儲存 AppRes_Histogram 統計圖片...完成!')
#--------------------------------------------
write_log_append("--")

#--------------------------------------------
# 逐次迭代後運行資訊更新(含畫圖與存檔)
def Inversion_Info_Update(i, inv):
    #--------------------------------------------
    # i 是當前迭代數，inv 是反演物件，但我都不取用，忽略他。
    #--
    Main_FileName = temp_json_data["Output_MainFileName"]
    #--------------------------------------------
    #--------------------------------------------
    # 展示逆推過程資訊    
    Info_Iteration_count = mgr.inv.iter
    write_log_append(f"\n--\n目前迭代次數: {Info_Iteration_count}")
    Info_Inversion_dataTrans = str(mgr.inv.dataTrans)
    write_log_append(f"逆推運算資料轉換方式: {Info_Inversion_dataTrans}")
    Info_Inversion_modelTrans = str(mgr.inv.modelTrans).replace("\n", " -> ")
    write_log_append(f"逆推運算模型轉換方式: {Info_Inversion_modelTrans}")
    if mgr.sr == True :
        write_log_append("逆推運算SR技術: 開啟")
        Info_Inversion_SR = 'Yes'
    else :
        write_log_append("逆推運算SR技術: 關閉")
        Info_Inversion_SR = 'No'
    if temp_json_data["Data_Setting02_GeometricFactorForInversion"] == 'K_Mesh' :
        write_log_append("逆推運算幾何因子: 數值模擬計算(去除地形效應)")
        Info_GeometricFactorByMesh = 'Yes'
    else :
        write_log_append("逆推運算幾何因子: 解析解(僅適用水平地層)")
        Info_GeometricFactorByMesh = 'No'       
    #--------------------------------------------
    #--------------------------------------------
    if temp_json_data["Inversion_Setting05_startModel"] > 0 :        
        Info_LastInversion_StartModelMesh_Value = np.ones(mgr.paraDomain.cellCount()) * Inversion_startModel
    elif temp_json_data["Inversion_Setting05_startModel"] == -2 : 
        Info_LastInversion_StartModelMesh_Value = Inversion_startModel
    elif temp_json_data["Inversion_Setting05_startModel"] == -3 :  
        Info_LastInversion_StartModelMesh_Value = Inversion_startModel
    else :
        Info_LastInversion_StartModelMesh_Value = mgr.inv.startModel
    #write_log_append(f"起始模型網格數值內容: {Info_LastInversion_StartModelMesh_Value}")
    Info_LastInversion_StartModelMesh_CellCount = len(Info_LastInversion_StartModelMesh_Value)
    write_log_append(f"起始模型網格數量 = {Info_LastInversion_StartModelMesh_CellCount}")
    Info_LastInversion_StartModelMesh_Value_Min = np.min(Info_LastInversion_StartModelMesh_Value)
    Info_LastInversion_StartModelMesh_Value_Max = np.max(Info_LastInversion_StartModelMesh_Value)
    write_log_append(f"起始模型網格數值(Min/Max) = {Info_LastInversion_StartModelMesh_Value_Min:.2f}/{Info_LastInversion_StartModelMesh_Value_Max:.2f}")
    #--------------------------------------------    
    write_log_append(f"限制模型網格數值(Min/Max) = {Inversion_limitModelCellMinValue:.2f}/{Inversion_limitModelCellMaxValue:.2f}")
    #--------------------------------------------    
    Info_LastInversion_ForwordH2ModelMesh_Value = mgr.fop.createMappedModel(mgr.inv.model) # 研究區域照填，附加區域延續（prolongated）
    #write_log_append(f"最後一次迭代的順推H2網格數值內容: {Info_LastInversion_ForwordH2ModelMesh_Value}")
    Info_LastInversion_ForwordH2ModelMesh_CellCount = len(Info_LastInversion_ForwordH2ModelMesh_Value)
    write_log_append(f"Remove_Runs#{Current_Remove_Runs}({Inversion_Remove_Data_Percentage}%),Iteration#{Info_Iteration_count}: 順推H2網格數值數量 = {Info_LastInversion_ForwordH2ModelMesh_CellCount}")
    Info_LastInversion_ForwordH2ModelMesh_Value_Min = np.min(Info_LastInversion_ForwordH2ModelMesh_Value)
    Info_LastInversion_ForwordH2ModelMesh_Value_Max = np.max(Info_LastInversion_ForwordH2ModelMesh_Value)
    write_log_append(f"Remove_Runs#{Current_Remove_Runs}({Inversion_Remove_Data_Percentage}%),Iteration#{Info_Iteration_count}: 順推H2網格數值(Min/Max) = {Info_LastInversion_ForwordH2ModelMesh_Value_Min:.2f}/{Info_LastInversion_ForwordH2ModelMesh_Value_Max:.2f}")
    #--
    #write_log_append("取出最後一次逆推的H2全網格...")
    LastInversion_H2FullMesh = pg.Mesh(mgr.fop.mesh())
    #write_log_append("取出最後一次逆推的H2全網格...完成!")
    #write_log_append("最後一次逆推的H2全網格填充數值...")
    LastInversion_H2FullMesh['Resistivity'] = Info_LastInversion_ForwordH2ModelMesh_Value
    LastInversion_H2FullMesh['Resistivity_(log10)'] = np.log10(LastInversion_H2FullMesh['Resistivity'])
    #write_log_append("最後一次逆推的H2全網格填充數值...完成!")    
    #--------------------------------------------
    # 輸出VTK
    # 輸出VTK前先把預設該存在的資料填1
    LastInversion_H2FullMesh['Coverage'] = np.ones(LastInversion_H2FullMesh.cellCount())
    LastInversion_H2FullMesh['S_Coverage'] = np.ones(LastInversion_H2FullMesh.cellCount())
    # 輸出    
    LastInversion_H2FullMesh.exportVTK(os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_R{Current_Remove_Runs:02d}_L{Current_lambda_number:02d}_I{Info_Iteration_count:02d}_H2.vtk'))
    #-------------------------------------------- 
    # 整理 MeshBCMarkers
    #--    
    # 印出 index, x1, y1, x2, y2, marker
    #write_log_append("index, x1, y1, x2, y2, marker")
    #for i, b in enumerate(mesh.boundaries()):
    #    write_log_append(f"{i}, {b.nodes()[0].pos()[0]:.6f}, {b.nodes()[0].pos()[1]:.6f}, {b.nodes()[1].pos()[0]:.6f}, {b.nodes()[1].pos()[1]:.6f}, {b.marker()}")
    #--
    # 儲存MeshMarkers為JSON檔案
    #write_log_append('儲存MeshBCMarkers為JSON檔案...')
    # 開啟檔案，以 UTF-8 編碼手動寫入 JSON 內容    
    with open(os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_R{Current_Remove_Runs:02d}_L{Current_lambda_number:02d}_I{Info_Iteration_count:02d}_H2BCMarkers.json'), 'w', encoding='utf-8') as f:
        #--
        # 寫入說明行
        f.write('{\n')
        f.write('"MeshBCMarkers_Readme":"index,x1[m],y1[m],x2[m],y2[m],marker",\n')
        f.write('"MeshBCMarkers":[\n')
        #--
        for i, b in enumerate(LastInversion_H2FullMesh.boundaries()):
            #--
            # 組成一列文字
            line = f'[{i}, {b.nodes()[0].pos()[0]:.6f}, {b.nodes()[0].pos()[1]:.6f}, {b.nodes()[1].pos()[0]:.6f}, {b.nodes()[1].pos()[1]:.6f}, {b.marker()}]'
            # 最後一列不加逗號，其它加逗號
            if i < LastInversion_H2FullMesh.boundaryCount() - 1:
                line += ','
            line += '\n'
            # 寫入
            f.write(line)
            #--
        #--
        # 關閉陣列與大括號
        f.write(']\n')
        f.write('}\n')
        #--
    #write_log_append('儲存MeshBCMarkers為JSON檔案...完成!')
    #--------------------------------------------   
    #--------------------------------------------
    Info_LastInversion_InversionModelMesh_Value = mgr.inv.model
    #write_log_append(f"Remove_Runs#{Current_Remove_Runs}({Inversion_Remove_Data_Percentage}%),Iteration#{Info_Iteration_count}: 逆推網格數值內容: {Info_LastInversion_InversionModelMesh_Value}")
    Info_LastInversion_InversionModelMesh_CellCount = len(Info_LastInversion_InversionModelMesh_Value)
    write_log_append(f"Remove_Runs#{Current_Remove_Runs}({Inversion_Remove_Data_Percentage}%),Iteration#{Info_Iteration_count}: 逆推網格數量 = {Info_LastInversion_InversionModelMesh_CellCount}")
    Info_LastInversion_InversionModelMesh_Value_Min = np.min(Info_LastInversion_InversionModelMesh_Value)
    Info_LastInversion_InversionModelMesh_Value_Max = np.max(Info_LastInversion_InversionModelMesh_Value)
    write_log_append(f"Remove_Runs#{Current_Remove_Runs}({Inversion_Remove_Data_Percentage}%),Iteration#{Info_Iteration_count}: 逆推網格數值(Min/Max) = {Info_LastInversion_InversionModelMesh_Value_Min:.2f}/{Info_LastInversion_InversionModelMesh_Value_Max:.2f}")
    #--
    #write_log_append("取出最後一次逆推的研究區域網格...")
    LastInversion_InversionModelMesh = pg.Mesh(mgr.paraDomain)
    #write_log_append("取出最後一次逆推的研究區域網格...完成!")
    #write_log_append("最後一次逆推的研究區域網格填充數值...")
    LastInversion_InversionModelMesh['Resistivity'] = Info_LastInversion_InversionModelMesh_Value
    LastInversion_InversionModelMesh['Resistivity_(log10)'] = np.log10(LastInversion_InversionModelMesh['Resistivity'])
    LastInversion_InversionModelMesh['Coverage'] = mgr.coverage()
    LastInversion_InversionModelMesh['S_Coverage'] = mgr.standardizedCoverage()
    #write_log_append("最後一次逆推的研究區域網格填充數值...完成!")
    #--------------------------------------------
    # 輸出VTK
    # 輸出    
    LastInversion_InversionModelMesh.exportVTK(os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_R{Current_Remove_Runs:02d}_L{Current_lambda_number:02d}_I{Info_Iteration_count:02d}_INV.vtk'))
    #-------------------------------------------- 
    # 整理 MeshBCMarkers
    #--    
    # 印出 index, x1, y1, x2, y2, marker
    #write_log_append("index, x1, y1, x2, y2, marker")
    #for i, b in enumerate(mesh.boundaries()):
    #    write_log_append(f"{i}, {b.nodes()[0].pos()[0]:.6f}, {b.nodes()[0].pos()[1]:.6f}, {b.nodes()[1].pos()[0]:.6f}, {b.nodes()[1].pos()[1]:.6f}, {b.marker()}")
    #--
    # 儲存MeshMarkers為JSON檔案
    #write_log_append('儲存MeshBCMarkers為JSON檔案...')
    # 開啟檔案，以 UTF-8 編碼手動寫入 JSON 內容    
    with open(os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_R{Current_Remove_Runs:02d}_L{Current_lambda_number:02d}_I{Info_Iteration_count:02d}_INVBCMarkers.json'), 'w', encoding='utf-8') as f:
        #--
        # 寫入說明行
        f.write('{\n')
        f.write('"MeshBCMarkers_Readme":"index,x1[m],y1[m],x2[m],y2[m],marker",\n')
        f.write('"MeshBCMarkers":[\n')
        #--
        for i, b in enumerate(LastInversion_InversionModelMesh.boundaries()):
            #--
            # 組成一列文字
            line = f'[{i}, {b.nodes()[0].pos()[0]:.6f}, {b.nodes()[0].pos()[1]:.6f}, {b.nodes()[1].pos()[0]:.6f}, {b.nodes()[1].pos()[1]:.6f}, {b.marker()}]'
            # 最後一列不加逗號，其它加逗號
            if i < LastInversion_InversionModelMesh.boundaryCount() - 1:
                line += ','
            line += '\n'
            # 寫入
            f.write(line)
            #--
        #--
        # 關閉陣列與大括號
        f.write(']\n')
        f.write('}\n')
        #--
    #write_log_append('儲存MeshBCMarkers為JSON檔案...完成!')    
    #--------------------------------------------
    #--------------------------------------------
    Info_LastInversion_Obs_dataVals = mgr.inv.dataVals
    #write_log_append(f"Remove_Runs#{Current_Remove_Runs}({Inversion_Remove_Data_Percentage}%),Iteration#{Info_Iteration_count}: 觀測資料內容: {Info_LastInversion_Obs_dataVals}")
    Info_LastInversion_Obs_dataVals_Count = len(Info_LastInversion_Obs_dataVals)
    write_log_append(f"Remove_Runs#{Current_Remove_Runs}({Inversion_Remove_Data_Percentage}%),Iteration#{Info_Iteration_count}: 觀測資料數量 = {Info_LastInversion_Obs_dataVals_Count}")
    Info_LastInversion_Obs_dataVals_Min = np.min(Info_LastInversion_Obs_dataVals)
    Info_LastInversion_Obs_dataVals_Max = np.max(Info_LastInversion_Obs_dataVals)
    write_log_append(f"Remove_Runs#{Current_Remove_Runs}({Inversion_Remove_Data_Percentage}%),Iteration#{Info_Iteration_count}: 觀測資料數值(Min/Max) = {Info_LastInversion_Obs_dataVals_Min:.2f}/{Info_LastInversion_Obs_dataVals_Max:.2f}")
    Info_LastInversion_Obs_errorVals = mgr.inv.errorVals
    #write_log_append(f"Remove_Runs#{Current_Remove_Runs}({Inversion_Remove_Data_Percentage}%),Iteration#{Info_Iteration_count}: 觀測資料估計相對誤差內容: {Info_LastInversion_Obs_errorVals}")
    Info_LastInversion_Obs_errorVals_Count = len(Info_LastInversion_Obs_errorVals)
    write_log_append(f"Remove_Runs#{Current_Remove_Runs}({Inversion_Remove_Data_Percentage}%),Iteration#{Info_Iteration_count}: 觀測資料估計相對誤差數量 = {Info_LastInversion_Obs_errorVals_Count}")
    Info_LastInversion_Obs_errorVals_Min = np.min(Info_LastInversion_Obs_errorVals)
    Info_LastInversion_Obs_errorVals_Max = np.max(Info_LastInversion_Obs_errorVals)
    write_log_append(f"Remove_Runs#{Current_Remove_Runs}({Inversion_Remove_Data_Percentage}%),Iteration#{Info_Iteration_count}: 觀測資料估計相對誤差數值(Min/Max) = {Info_LastInversion_Obs_errorVals_Min:.2f}/{Info_LastInversion_Obs_errorVals_Max:.2f}")
    Info_LastInversion_response_dataVals = mgr.inv.response
    #write_log_append(f"Remove_Runs#{Current_Remove_Runs}({Inversion_Remove_Data_Percentage}%),Iteration#{Info_Iteration_count}: 計算資料內容: {Info_LastInversion_response_dataVals}")
    Info_LastInversion_response_dataVals_Count = len(Info_LastInversion_response_dataVals)
    write_log_append(f"Remove_Runs#{Current_Remove_Runs}({Inversion_Remove_Data_Percentage}%),Iteration#{Info_Iteration_count}: 計算資料數量 = {Info_LastInversion_response_dataVals_Count}")
    Info_LastInversion_response_dataVals_Min = np.min(Info_LastInversion_response_dataVals)
    Info_LastInversion_response_dataVals_Max = np.max(Info_LastInversion_response_dataVals)    
    write_log_append(f"Remove_Runs#{Current_Remove_Runs}({Inversion_Remove_Data_Percentage}%),Iteration#{Info_Iteration_count}: 計算資料數值(Min/Max) = {Info_LastInversion_response_dataVals_Min:.2f}/{Info_LastInversion_response_dataVals_Max:.2f}")
    Info_LastInversion_Lambda = mgr.inv.inv.getLambda()
    mgr.inv.inv.setLambda(Info_LastInversion_Lambda)
    write_log_append(f"Remove_Runs#{Current_Remove_Runs}({Inversion_Remove_Data_Percentage}%),Iteration#{Info_Iteration_count}: 逆推採用Lambda = {Info_LastInversion_Lambda}")
    Info_LastInversion_RMS = mgr.inv.absrms()
    #write_log_append(f"Remove_Runs#{Current_Remove_Runs}({Inversion_Remove_Data_Percentage}%),Iteration#{Info_Iteration_count}: RMS = {Info_LastInversion_RMS:.2f}")
    Info_LastInversion_RRMS = mgr.inv.relrms()
    #write_log_append(f"Remove_Runs#{Current_Remove_Runs}({Inversion_Remove_Data_Percentage}%),Iteration#{Info_Iteration_count}: RRMS = {Info_LastInversion_RRMS:.2f}%")
    write_log_append(f"Remove_Runs#{Current_Remove_Runs}({Inversion_Remove_Data_Percentage}%),Iteration#{Info_Iteration_count}: RMS/RRMS = {Info_LastInversion_RMS:.2f}/{Info_LastInversion_RRMS:.2f}%")
    Info_LastInversion_chi2 = mgr.inv.chi2()
    write_log_append(f"Remove_Runs#{Current_Remove_Runs}({Inversion_Remove_Data_Percentage}%),Iteration#{Info_Iteration_count}: chi2 = {Info_LastInversion_chi2:.2f}")
    Info_LastInversion_PhiD = mgr.inv.phiData()
    #write_log_append(f"Remove_Runs#{Current_Remove_Runs}({Inversion_Remove_Data_Percentage}%),Iteration#{Info_Iteration_count}: PhiD = {Info_LastInversion_PhiD:.2f}")
    Info_LastInversion_PhiM = mgr.inv.phiModel()
    #write_log_append(f"Remove_Runs#{Current_Remove_Runs}({Inversion_Remove_Data_Percentage}%),Iteration#{Info_Iteration_count}: PhiM = {Info_LastInversion_PhiM:.2f}")
    Info_LastInversion_Phi = mgr.inv.phi()
    write_log_append(f"Remove_Runs#{Current_Remove_Runs}({Inversion_Remove_Data_Percentage}%),Iteration#{Info_Iteration_count}: Phi = PhiD+(lam*PhiM) =: {Info_LastInversion_PhiD:.2f}+({Info_LastInversion_Lambda}*{Info_LastInversion_PhiM:.2f}) = {Info_LastInversion_Phi:.2f}")
    #--------------------------------------------
    # Cross Plot (Obs vs Response)
    #--
    # 可填入的資訊
    PNG_Profile_Name = Main_FileName
    PNG_Main_Title01 = f"{PNG_Profile_Name}\n Observed vs. Predicted Cross Plot (Linear) " + \
        f"(Iteration={Info_Iteration_count})\n" + \
        f"Remove Runs={Current_Remove_Runs}, " + \
        f"Remove Data={Inversion_Remove_Data_Percentage}%, " + \
        f"Data Count={Info_LastInversion_Obs_dataVals_Count}, " + \
        rf"$\chi^2$={Info_LastInversion_chi2:.2f}" + \
        f"\nData EstError={Data_Settings_Relative_Error_Percentage}%, " + \
        rf"$\lambda${Current_lambda_number}={Info_LastInversion_Lambda:.2f}, " + \
        f"limits=[{Inversion_limitModelCellMinValue:.2f},{Inversion_limitModelCellMaxValue:.2f}]Ωm, " + \
        f"RRMS={Info_LastInversion_RRMS:.2f}%" 
    PNG_Main_Title02 = f"{PNG_Profile_Name}\n Observed vs. Predicted Cross Plot (abs Log10) " + \
        f"(Iteration={Info_Iteration_count})\n" + \
        f"Remove Runs={Current_Remove_Runs}, " + \
        f"Remove Data={Inversion_Remove_Data_Percentage}%, " + \
        f"Data Count={Info_LastInversion_Obs_dataVals_Count}, " + \
        rf"$\chi^2$={Info_LastInversion_chi2:.2f}" + \
        f"\nData EstError={Data_Settings_Relative_Error_Percentage}%, " + \
        rf"$\lambda${Current_lambda_number}={Info_LastInversion_Lambda:.2f}, " + \
        f"limits=[{Inversion_limitModelCellMinValue:.2f},{Inversion_limitModelCellMaxValue:.2f}]Ωm, " + \
        f"RRMS={Info_LastInversion_RRMS:.2f}%"
    temp_PNG_DPI = 100
    temp_PNG_Width = 1280
    temp_PNG_Height = 720
    Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_R{Current_Remove_Runs:02d}_L{Current_lambda_number:02d}_I{Info_Iteration_count:02d}_CrossPlot.png')
    #--
    # 建立畫布
    fig, axes = plt.subplots(1, 2, figsize=((temp_PNG_Width / temp_PNG_DPI, temp_PNG_Height / temp_PNG_DPI)))
    #--
    # 子圖1
    #--
    Overlap_First_data_Rhoa_sorted = Info_LastInversion_Obs_dataVals
    Overlap_Second_data_Rhoa_sorted = Info_LastInversion_response_dataVals
    # 繪製資料點
    Overlap_First_data_Rhoa_sorted_positive_positive = Overlap_First_data_Rhoa_sorted[(Overlap_First_data_Rhoa_sorted > 0) & (Overlap_Second_data_Rhoa_sorted > 0)]
    Overlap_Second_data_Rhoa_sorted_positive_positive = Overlap_Second_data_Rhoa_sorted[(Overlap_First_data_Rhoa_sorted > 0) & (Overlap_Second_data_Rhoa_sorted > 0)]
    axes[0].scatter(Overlap_First_data_Rhoa_sorted_positive_positive, Overlap_Second_data_Rhoa_sorted_positive_positive, alpha=0.5, s=5, c='blue',label=f'1+2+({len(Overlap_First_data_Rhoa_sorted_positive_positive)})')
    Overlap_First_data_Rhoa_sorted_positive_negative = Overlap_First_data_Rhoa_sorted[(Overlap_First_data_Rhoa_sorted > 0) & (Overlap_Second_data_Rhoa_sorted < 0)]
    Overlap_Second_data_Rhoa_sorted_positive_negative = Overlap_Second_data_Rhoa_sorted[(Overlap_First_data_Rhoa_sorted > 0) & (Overlap_Second_data_Rhoa_sorted < 0)]
    axes[0].scatter(Overlap_First_data_Rhoa_sorted_positive_negative, Overlap_Second_data_Rhoa_sorted_positive_negative, alpha=0.5, s=5, c='blue',label=f'1+2-({len(Overlap_First_data_Rhoa_sorted_positive_negative)})')
    Overlap_First_data_Rhoa_sorted_negative_negative = Overlap_First_data_Rhoa_sorted[(Overlap_First_data_Rhoa_sorted < 0) & (Overlap_Second_data_Rhoa_sorted < 0)]
    Overlap_Second_data_Rhoa_sorted_negative_negative = Overlap_Second_data_Rhoa_sorted[(Overlap_First_data_Rhoa_sorted < 0) & (Overlap_Second_data_Rhoa_sorted < 0)]
    axes[0].scatter(Overlap_First_data_Rhoa_sorted_negative_negative, Overlap_Second_data_Rhoa_sorted_negative_negative, alpha=0.5, s=5, c='blue',label=f'1-2-({len(Overlap_First_data_Rhoa_sorted_negative_negative)})')
    Overlap_First_data_Rhoa_sorted_negative_positive = Overlap_First_data_Rhoa_sorted[(Overlap_First_data_Rhoa_sorted < 0) & (Overlap_Second_data_Rhoa_sorted > 0)]
    Overlap_Second_data_Rhoa_sorted_negative_positive = Overlap_Second_data_Rhoa_sorted[(Overlap_First_data_Rhoa_sorted < 0) & (Overlap_Second_data_Rhoa_sorted > 0)]
    axes[0].scatter(Overlap_First_data_Rhoa_sorted_negative_positive, Overlap_Second_data_Rhoa_sorted_negative_positive, alpha=0.5, s=5, c='blue',label=f'1-2+({len(Overlap_First_data_Rhoa_sorted_negative_positive)})')
    # 設定等比例
    axes[0].set_aspect('equal', adjustable='box')
    # 畫出 1:1 參考線
    lims = [
        np.min([axes[0].get_xlim(), axes[0].get_ylim()]),
        np.max([axes[0].get_xlim(), axes[0].get_ylim()]),
    ]
    axes[0].plot(lims, lims, '--', c='gray', alpha=0.75, zorder=0, label='1:1 Line')
    #--
    # 調整繪圖參數
    axes[0].set_xlabel(f'1: Observed Data (Ωm)')
    axes[0].set_ylabel(f'2: Predicted Data (Ωm)')
    axes[0].set_title(PNG_Main_Title01)
    axes[0].legend(loc='upper left')
    #--
    # 子圖2
    #--
    # 繪製資料點
    Overlap_First_data_Rhoa_sorted_positive_positive_abs_log10 = np.log10(np.abs(Overlap_First_data_Rhoa_sorted[(Overlap_First_data_Rhoa_sorted > 0) & (Overlap_Second_data_Rhoa_sorted > 0)]))
    Overlap_Second_data_Rhoa_sorted_positive_positive_abs_log10 = np.log10(np.abs(Overlap_Second_data_Rhoa_sorted[(Overlap_First_data_Rhoa_sorted > 0) & (Overlap_Second_data_Rhoa_sorted > 0)]))
    axes[1].scatter(Overlap_First_data_Rhoa_sorted_positive_positive_abs_log10, Overlap_Second_data_Rhoa_sorted_positive_positive_abs_log10, alpha=0.5, s=5, c='blue',label=f'1+2+({len(Overlap_First_data_Rhoa_sorted_positive_positive_abs_log10)})')
    Overlap_First_data_Rhoa_sorted_positive_negative_abs_log10 = np.log10(np.abs(Overlap_First_data_Rhoa_sorted[(Overlap_First_data_Rhoa_sorted > 0) & (Overlap_Second_data_Rhoa_sorted < 0)]))
    Overlap_Second_data_Rhoa_sorted_positive_negative_abs_log10 = np.log10(np.abs(Overlap_Second_data_Rhoa_sorted[(Overlap_First_data_Rhoa_sorted > 0) & (Overlap_Second_data_Rhoa_sorted < 0)]))
    axes[1].scatter(Overlap_First_data_Rhoa_sorted_positive_negative_abs_log10, Overlap_Second_data_Rhoa_sorted_positive_negative_abs_log10, alpha=0.5, s=5, c='lightblue',label=f'1+2-({len(Overlap_First_data_Rhoa_sorted_positive_negative_abs_log10)})')
    Overlap_First_data_Rhoa_sorted_negative_negative_abs_log10 = np.log10(np.abs(Overlap_First_data_Rhoa_sorted[(Overlap_First_data_Rhoa_sorted < 0) & (Overlap_Second_data_Rhoa_sorted < 0)]))
    Overlap_Second_data_Rhoa_sorted_negative_negative_abs_log10 = np.log10(np.abs(Overlap_Second_data_Rhoa_sorted[(Overlap_First_data_Rhoa_sorted < 0) & (Overlap_Second_data_Rhoa_sorted < 0)]))
    axes[1].scatter(Overlap_First_data_Rhoa_sorted_negative_negative_abs_log10, Overlap_Second_data_Rhoa_sorted_negative_negative_abs_log10, alpha=0.5, s=5, c='red',label=f'1-2-({len(Overlap_First_data_Rhoa_sorted_negative_negative_abs_log10)})')
    Overlap_First_data_Rhoa_sorted_negative_positive_abs_log10 = np.log10(np.abs(Overlap_First_data_Rhoa_sorted[(Overlap_First_data_Rhoa_sorted < 0) & (Overlap_Second_data_Rhoa_sorted > 0)]))
    Overlap_Second_data_Rhoa_sorted_negative_positive_abs_log10 = np.log10(np.abs(Overlap_Second_data_Rhoa_sorted[(Overlap_First_data_Rhoa_sorted < 0) & (Overlap_Second_data_Rhoa_sorted > 0)]))
    axes[1].scatter(Overlap_First_data_Rhoa_sorted_negative_positive_abs_log10, Overlap_Second_data_Rhoa_sorted_negative_positive_abs_log10, alpha=0.5, s=5, c='lightpink',label=f'1-2+({len(Overlap_First_data_Rhoa_sorted_negative_positive_abs_log10)})')
    # 設定等比例
    axes[1].set_aspect('equal', adjustable='box')
    # 畫出 1:1 參考線
    lims = [
        np.min([axes[1].get_xlim(), axes[1].get_ylim()]),
        np.max([axes[1].get_xlim(), axes[1].get_ylim()]),
    ]
    axes[1].plot(lims, lims, '--', c='gray', alpha=0.75, zorder=0, label='1:1 Line')
    #--
    # 調整繪圖參數
    axes[1].set_xlabel(f'1: abs(Observed Data) (Log10 Ωm)')
    axes[1].set_ylabel(f'2: abs(Predicted Data) (Log10 Ohm)')
    axes[1].set_title(PNG_Main_Title02)
    axes[1].legend(loc='upper left')
    #--
    # 填入版本資訊
    fig.text(0.98, 0.005, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
    #--
    #write_log_append(f'儲存 圖片...')
    if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
        os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
    plt.tight_layout() 
    plt.savefig(Output_PNG_FileName, dpi=temp_PNG_DPI)
    plt.close()
    #write_log_append(f'儲存 圖片...完成!')
    #--------------------------------------------
    # 相對殘差百分比 統計圖
    Info_LastInversion_Relative_Misfit_Percentage = np.abs((Info_LastInversion_response_dataVals - Info_LastInversion_Obs_dataVals) / Info_LastInversion_Obs_dataVals) * 100
    #write_log_append(f"Remove_Runs#{Current_Remove_Runs}({Inversion_Remove_Data_Percentage}%),Iteration#{Info_LastInversion_Relative_Misfit_Percentage}的計算資料內容: {Info_LastInversion_Relative_Misfit_Percentage}")
    Info_LastInversion_Relative_Misfit_Percentage_Count = len(Info_LastInversion_Relative_Misfit_Percentage)
    write_log_append(f"Remove_Runs#{Current_Remove_Runs}({Inversion_Remove_Data_Percentage}%),Iteration#{Info_Iteration_count}: 相對殘差百分比數量 = {Info_LastInversion_Relative_Misfit_Percentage_Count}")
    Info_LastInversion_Relative_Misfit_Percentage_Min = np.min(Info_LastInversion_Relative_Misfit_Percentage)
    Info_LastInversion_Relative_Misfit_Percentage_Mean = np.mean(Info_LastInversion_Relative_Misfit_Percentage)
    Info_LastInversion_Relative_Misfit_Percentage_Max = np.max(Info_LastInversion_Relative_Misfit_Percentage)
    write_log_append(f"Remove_Runs#{Current_Remove_Runs}({Inversion_Remove_Data_Percentage}%),Iteration#{Info_Iteration_count}: 相對殘差百分比數值(Min/Mean/Max) = {Info_LastInversion_Relative_Misfit_Percentage_Min:.2f}%/{Info_LastInversion_Relative_Misfit_Percentage_Mean:.2f}%/{Info_LastInversion_Relative_Misfit_Percentage_Max:.2f}%")
    #--
    # 可填入的資訊
    PNG_Profile_Name = Main_FileName
    PNG_Main_Title = f"{PNG_Profile_Name} Relative Data Misfit Histogram (Green = All, Red = Top {Inversion_Remove_Data_Percentage}% High Misfit )" + \
        f" (Iteration={Info_Iteration_count})" + \
        f"\nData Count={Info_LastInversion_Obs_dataVals_Count}, " + \
        f"Data EstError={Data_Settings_Relative_Error_Percentage}%, " + \
        f"Remove Runs={Current_Remove_Runs}, " + \
        f"Remove Data={Inversion_Remove_Data_Percentage}%, " + \
        rf"$\lambda${Current_lambda_number}={Info_LastInversion_Lambda:.2f}, " + \
        f"limits=[{Inversion_limitModelCellMinValue:.2f},{Inversion_limitModelCellMaxValue:.2f}]Ωm, " + \
        f"RRMS={Info_LastInversion_RRMS:.2f}%, " + \
        rf"$\chi^2$={Info_LastInversion_chi2:.2f}"    
    #--
    PNG_DPI = 100
    PNG_Width = 1280
    PNG_Height = 720 
    Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_R{Current_Remove_Runs:02d}_L{Current_lambda_number:02d}_I{Info_Iteration_count:02d}_Misfit.png')
    #--
    # 計算要取出的資料個數 (假設 Inversion_Remove_Data_Percentage = 5)
    temp_All_Data_Count = len(Info_LastInversion_Relative_Misfit_Percentage)
    temp_Remove_Data_Count = int(np.round(temp_All_Data_Count * Inversion_Remove_Data_Percentage / 100))
    # 取得 misfit 最大的索引 (由小到大排序，取最後面的 N 個)
    temp_worst_indices = np.argsort(Info_LastInversion_Relative_Misfit_Percentage)[-temp_Remove_Data_Count:]
    # 根據索引提取出這 5% 的數據
    Relative_Misfit_Percentage_Worst_5_Percent = Info_LastInversion_Relative_Misfit_Percentage[temp_worst_indices]
    #--
    # 建立畫布
    fig, ax = plt.subplots(figsize=((PNG_Width / PNG_DPI, PNG_Height / PNG_DPI)))
    # 設定截斷閾值，單位:[%]    
    Relative_Misfit_Percentage_clip_threshold = 100 #單位:[%]
    Relative_Misfit_Percentage_Histogram_Bin_Width = 5 # 單位:[%]
    # 依照上下限截斷：所有大於 100 的都會變成 101 (確保它們掉進最後一格 [100, 105])
    Relative_Misfit_Percentage_clipped = np.clip(Info_LastInversion_Relative_Misfit_Percentage, 0, Relative_Misfit_Percentage_clip_threshold + 1)
    Relative_Misfit_Percentage_Worst_5_Percent_clipped = np.clip(Relative_Misfit_Percentage_Worst_5_Percent, 0, Relative_Misfit_Percentage_clip_threshold + 1)
    # 重新設計 Histogram_Bins_Setting ( 0-5% 第一根，5-10% 第二根，中間以 5% 為間隔到 100%，最後一根代表 >100%)
    Histogram_Bins_Setting = np.arange(0, Relative_Misfit_Percentage_clip_threshold + Relative_Misfit_Percentage_Histogram_Bin_Width + 1, Relative_Misfit_Percentage_Histogram_Bin_Width)
    # 繪製直方圖
    ax.hist(Relative_Misfit_Percentage_clipped, bins=Histogram_Bins_Setting, edgecolor='black', color='limegreen', alpha=0.7,rwidth=0.7, label='All Data')
    ax.hist(Relative_Misfit_Percentage_Worst_5_Percent_clipped, bins=Histogram_Bins_Setting, edgecolor='black', color='red', alpha=0.7,rwidth=0.7, label='Worst 5%')
    # 設定 X 軸刻度與標籤
    ax.set_xticks(Histogram_Bins_Setting)
    temp_label_str = [str(int(b)) for b in Histogram_Bins_Setting]
    temp_label_str[-1] = ">" + str(Relative_Misfit_Percentage_clip_threshold) # 將最後一個標籤改為 >100
    ax.set_xticklabels(temp_label_str)
    ax.set_title(PNG_Main_Title)
    ax.set_xlabel('Relative Data Misfit (%)')
    ax.set_ylabel('Number of Data')
    #--
    # 填入版本資訊
    fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
    #--
    #write_log_append(f'儲存 {PNG_Profile_Name} 圖片...')
    #Output_PNG_FileName = 'ABCD.png'
    if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
        os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
    plt.tight_layout() 
    plt.savefig(Output_PNG_FileName, dpi=PNG_DPI)
    plt.close()
    #write_log_append(f'儲存 {PNG_Profile_Name} 圖片...完成!')    
    #--------------------------------------------
    #--------------------------------------------
    # 儲存觀測資料與計算資料為dat檔案
    LastInversion_Data = mgr.fop.data.copy()
    LastInversion_Data['response'] = mgr.inv.response
    LastInversion_Data['Relative_Misfit_Percentage'] = Info_LastInversion_Relative_Misfit_Percentage   
    #--
    #write_log_append(f"轉換為逆推專用2D座標系統(XY座標)...")
    # 如果滿足2D情況，則強迫轉換成X有值，Y有值，Z均為0。
    LastInversion_Data.ensure2D()
    if  np.max(np.abs(pg.z(LastInversion_Data.sensorPositions()))) != 0 :
        write_log_append("Ohm檔案內容不是2D資料，無法進行後續分析，請檢查!")
        exit(1)
    #write_log_append(f"轉換為逆推專用2D座標系統(XY座標)完成!")
    #--
    # 轉換為標準XZ專用2D座標系統
    #write_log_append(f"轉換為標準2D座標系統(XZ座標)...")
    temp_sensors=LastInversion_Data.sensors()
    pg.core.swapYZ(temp_sensors)
    LastInversion_Data.setSensorPositions(temp_sensors)
    #write_log_append(f"轉換為標準2D座標系統(XZ座標)...完成!")
    #--
    LastInversion_Data.save(os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_R{Current_Remove_Runs:02d}_L{Current_lambda_number:02d}_I{Info_Iteration_count:02d}_ObsCalData.dat'),'a b m n r i rhoa k err response Relative_Misfit_Percentage')
    #--
    #write_log_append(f"轉換為逆推專用2D座標系統(XY座標)...")
    # 如果滿足2D情況，則強迫轉換成X有值，Y有值，Z均為0。
    LastInversion_Data.ensure2D()
    if  np.max(np.abs(pg.z(LastInversion_Data.sensorPositions()))) != 0 :
        write_log_append("Ohm檔案內容不是2D資料，無法進行後續分析，請檢查!")
        exit(1)
    #write_log_append(f"轉換為逆推專用2D座標系統(XY座標)完成!")
    #--
    LastInversion_CalData = mgr.fop.data.copy()
    LastInversion_CalData['rhoa'] = mgr.inv.response
    LastInversion_CalData['r'] = LastInversion_CalData['rhoa']/LastInversion_CalData['k']
    LastInversion_CalData['i'] = (LastInversion_CalData['i']*0) + 1
    #--
    #write_log_append(f"轉換為逆推專用2D座標系統(XY座標)...")
    # 如果滿足2D情況，則強迫轉換成X有值，Y有值，Z均為0。
    LastInversion_CalData.ensure2D()
    if  np.max(np.abs(pg.z(LastInversion_CalData.sensorPositions()))) != 0 :
        write_log_append("Ohm檔案內容不是2D資料，無法進行後續分析，請檢查!")
        exit(1)
    #write_log_append(f"轉換為逆推專用2D座標系統(XY座標)完成!")
    #--
    # 轉換為標準XZ專用2D座標系統
    #write_log_append(f"轉換為標準2D座標系統(XZ座標)...")
    temp_sensors=LastInversion_CalData.sensors()
    pg.core.swapYZ(temp_sensors)
    LastInversion_CalData.setSensorPositions(temp_sensors)
    #write_log_append(f"轉換為標準2D座標系統(XZ座標)...完成!")
    #--
    LastInversion_CalData.save(os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_R{Current_Remove_Runs:02d}_L{Current_lambda_number:02d}_I{Info_Iteration_count:02d}_CalData.dat'),'a b m n r i rhoa k')
    #--
    #write_log_append(f"轉換為逆推專用2D座標系統(XY座標)...")
    # 如果滿足2D情況，則強迫轉換成X有值，Y有值，Z均為0。
    LastInversion_CalData.ensure2D()
    if  np.max(np.abs(pg.z(LastInversion_CalData.sensorPositions()))) != 0 :
        write_log_append("Ohm檔案內容不是2D資料，無法進行後續分析，請檢查!")
        exit(1)
    #write_log_append(f"轉換為逆推專用2D座標系統(XY座標)完成!")
    #--------------------------------------------
    #--------------------------------------------
    #write_log_append('儲存 Output_Inversion_Log 檔案...')   
    Output_Inversion_Log = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_03_Inversion_Log.csv')
    with open(Output_Inversion_Log, 'a', encoding='utf-8') as f:
        #--
        # 內容
        line = f'{Main_FileName},{Info_Inversion_SR},{Info_GeometricFactorByMesh},{Current_Remove_Runs},{Inversion_Remove_Data_Percentage},{Info_Iteration_count},{Inversion_maxIter},' + \
        f'{Info_LastInversion_StartModelMesh_CellCount},{Info_LastInversion_StartModelMesh_Value_Min},{Info_LastInversion_StartModelMesh_Value_Max},' + \
        f'{Inversion_limitModelCellMinValue},{Inversion_limitModelCellMaxValue},' + \
        f'{Info_LastInversion_ForwordH2ModelMesh_CellCount},{Info_LastInversion_ForwordH2ModelMesh_Value_Min},{Info_LastInversion_ForwordH2ModelMesh_Value_Max},' + \
        f'{Info_LastInversion_InversionModelMesh_CellCount},{Info_LastInversion_InversionModelMesh_Value_Min},{Info_LastInversion_InversionModelMesh_Value_Max},' + \
        f'{Info_LastInversion_Obs_dataVals_Count},{Info_LastInversion_Obs_dataVals_Min},{Info_LastInversion_Obs_dataVals_Max},' + \
        f'{Info_LastInversion_Obs_errorVals_Min*100},{Info_LastInversion_Obs_errorVals_Max*100},' + \
        f'{Info_LastInversion_response_dataVals_Min},{Info_LastInversion_response_dataVals_Max},' + \
        f'{Info_LastInversion_Relative_Misfit_Percentage_Min},{Info_LastInversion_Relative_Misfit_Percentage_Mean},{Info_LastInversion_Relative_Misfit_Percentage_Max},' + \
        f'{Current_lambda_number},{Info_LastInversion_Lambda},{Info_LastInversion_RMS},{Info_LastInversion_RRMS},{Info_LastInversion_chi2},{Info_LastInversion_Phi},{Info_LastInversion_PhiD},{Info_LastInversion_PhiM}\n'    
        f.write(line)
        #--
    #write_log_append('儲存 Output_Inversion_Log 檔案...完成!')
    #--------------------------------------------
    #==============================================================================
    # Pygimli網格繪圖:  繪製H2全網格逆推剖面(電阻率、電極位置、逆推資訊)
    #--
    # 可填入的資訊
    PNG_Profile_Name = Main_FileName
    PNG_NumPy_Electrode_x = LastInversion_Data.sensors().array()[:, 0]
    PNG_NumPy_Electrode_y = LastInversion_Data.sensors().array()[:, 1]
    PNG_NumPy_Electrode_z = LastInversion_Data.sensors().array()[:, 2]
    PNG_mesh = LastInversion_H2FullMesh
    PNG_mesh_data = LastInversion_H2FullMesh['Resistivity_(log10)']
    PNG_colorbar_title = 'Resistivity (log10 Ωm)'
    PNG_colorbar_ticker_ModifyLog10ToLinear_Enable = True # True = 把colorbar數值文字從對數尺度調整成線性尺度 / False = 維持原本數值
    PNG_colorbar_ticker_ModifyLog10ToLinear_title = 'Resistivity (Ωm)'
    PNG_Main_Title = f"{PNG_Profile_Name} Inverted Resistivity Section (H2FullMesh) " + \
        f" (Iteration={Info_Iteration_count})" + \
        f"\nData Count={Info_LastInversion_Obs_dataVals_Count}, " + \
        f"Data EstError={Data_Settings_Relative_Error_Percentage}%, " + \
        f"Remove Runs={Current_Remove_Runs}, " + \
        f"Remove Data={Inversion_Remove_Data_Percentage}%, " + \
        rf"$\lambda${Current_lambda_number}={Info_LastInversion_Lambda:.2f}, " + \
        f"limits=[{Inversion_limitModelCellMinValue:.2f},{Inversion_limitModelCellMaxValue:.2f}]Ωm, " + \
        f"RRMS={Info_LastInversion_RRMS:.2f}%, " + \
        rf"$\chi^2$={Info_LastInversion_chi2:.2f}"                
    PNG_mesh_showMesh = True # True / False
    PNG_mesh_showBoundary = True # None / True / False ，某些時候None與True效果相同
    PNG_cMap = 'jet'
    PNG_cMin = np.min(PNG_mesh_data) # None表示自動
    PNG_cMax = np.max(PNG_mesh_data) # None表示自動
    # 檢查是否所有數值都很接近
    if (PNG_cMin - PNG_cMax) < 0.000002:
        # 如果很接近，設定極小的偏移量
        PNG_cMin = PNG_cMin - 0.000001
        PNG_cMax = PNG_cMax + 0.000001
    PNG_DPI = 100
    PNG_Width = 1280
    PNG_Height = 720    
    Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_R{Current_Remove_Runs:02d}_L{Current_lambda_number:02d}_I{Info_Iteration_count:02d}_H2.png')
    #--
    # 建立畫布
    fig, ax = plt.subplots(figsize=((PNG_Width / PNG_DPI, PNG_Height / PNG_DPI)))
    # 繪製網格
    ax, cbar = pg.show(PNG_mesh, 
        data=PNG_mesh_data, 
        ax=ax,
        markers=False,
        showMesh=PNG_mesh_showMesh,
        showBoundary=PNG_mesh_showBoundary,  
        label=PNG_colorbar_title,     # colorbar的標題。
        axisLabels=False,             # 阻止自動標籤(否則特定條件下會把Y軸轉換成深度)。後面自行填入標籤。
        cMap=PNG_cMap,
        cMin=PNG_cMin,
        cMax=PNG_cMax)
    # 繪製電極
    ax.plot(PNG_NumPy_Electrode_x[Good_Electrode_Index_0Base], PNG_NumPy_Electrode_y[Good_Electrode_Index_0Base], 'o', markersize=6, color='magenta', markerfacecolor='magenta', markeredgecolor='black', label='Electrode Nodes')    
    if len(Bad_Electrode_Index_0Base) >0 :
        ax.plot(PNG_NumPy_Electrode_x[Bad_Electrode_Index_0Base], PNG_NumPy_Electrode_y[Bad_Electrode_Index_0Base], 'o', markersize=6, color='magenta', markerfacecolor='lightgray', markeredgecolor='black', label='Skipped Electrode Nodes')
    ax.set_title(PNG_Main_Title, pad=3)  
    # 調整XY標籤
    ax.set_xlabel('Distance (m)')
    ax.set_ylabel('Elevation (m)')
    # 調整圖例
    ax.legend(loc='upper right',ncol=2,framealpha=0.4)
    # 調整colorbar內文字
    if PNG_colorbar_ticker_ModifyLog10ToLinear_Enable:
        cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.FuncFormatter(lambda x, pos: f'{10**x:.1f}'.rstrip('0').rstrip('.')))    
        cbar.ax.xaxis.get_offset_text().set_visible(False) # 避免顯示 1eX
        cbar.set_label(PNG_colorbar_ticker_ModifyLog10ToLinear_title) # 使用你設定的 Ωm 標題
    else:
        cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.ScalarFormatter(useMathText=False))
        cbar.ax.xaxis.get_major_formatter().set_useOffset(False) #禁用「偏移量 (Offset)」模式
        cbar.ax.xaxis.get_offset_text().set_visible(False)  # 避免顯示 1eX
    #--
    # 填入版本資訊
    fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
    # 調整邊界
    x_min, x_max = ax.get_xlim()
    y_min, y_max = ax.get_ylim()
    x_range = x_max - x_min
    y_range = y_max - y_min
    ax.set_ylim(y_min , y_max + 0.1 * y_range)
    #--
    #write_log_append(f'儲存 {PNG_Profile_Name} 圖片...')
    #Output_PNG_FileName = 'ABCD.png'
    if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
        os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
    plt.tight_layout() 
    plt.savefig(Output_PNG_FileName, dpi=PNG_DPI)
    plt.close()
    #write_log_append(f'儲存 {PNG_Profile_Name} 圖片...完成!')
    #==============================================================================
    #==============================================================================
    # Pygimli網格繪圖:  繪製H2全網格逆推剖面(電阻率、電極位置、逆推資訊) 無網格#1
    #--
    # 可填入的資訊
    PNG_Profile_Name = Main_FileName
    PNG_NumPy_Electrode_x = LastInversion_Data.sensors().array()[:, 0]
    PNG_NumPy_Electrode_y = LastInversion_Data.sensors().array()[:, 1]
    PNG_NumPy_Electrode_z = LastInversion_Data.sensors().array()[:, 2]
    PNG_mesh = LastInversion_H2FullMesh
    PNG_mesh_data = LastInversion_H2FullMesh['Resistivity_(log10)']
    PNG_colorbar_title = 'Resistivity (log10 Ωm)'
    PNG_colorbar_ticker_ModifyLog10ToLinear_Enable = True # True = 把colorbar數值文字從對數尺度調整成線性尺度 / False = 維持原本數值
    PNG_colorbar_ticker_ModifyLog10ToLinear_title = 'Resistivity (Ωm)'
    PNG_Main_Title = f"{PNG_Profile_Name} Inverted Resistivity Section (H2FullMesh) " + \
        f" (Iteration={Info_Iteration_count})" + \
        f"\nData Count={Info_LastInversion_Obs_dataVals_Count}, " + \
        f"Data EstError={Data_Settings_Relative_Error_Percentage}%, " + \
        f"Remove Runs={Current_Remove_Runs}, " + \
        f"Remove Data={Inversion_Remove_Data_Percentage}%, " + \
        rf"$\lambda${Current_lambda_number}={Info_LastInversion_Lambda:.2f}, " + \
        f"limits=[{Inversion_limitModelCellMinValue:.2f},{Inversion_limitModelCellMaxValue:.2f}]Ωm, " + \
        f"RRMS={Info_LastInversion_RRMS:.2f}%, " + \
        rf"$\chi^2$={Info_LastInversion_chi2:.2f}"                
    PNG_mesh_showMesh = False # True / False
    PNG_mesh_showBoundary = True # None / True / False ，某些時候None與True效果相同
    PNG_cMap = 'jet'
    PNG_cMin = np.min(PNG_mesh_data) # None表示自動
    PNG_cMax = np.max(PNG_mesh_data) # None表示自動
    # 檢查是否所有數值都很接近
    if (PNG_cMin - PNG_cMax) < 0.000002:
        # 如果很接近，設定極小的偏移量
        PNG_cMin = PNG_cMin - 0.000001
        PNG_cMax = PNG_cMax + 0.000001
    PNG_DPI = 100
    PNG_Width = 1280
    PNG_Height = 720    
    Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_R{Current_Remove_Runs:02d}_L{Current_lambda_number:02d}_I{Info_Iteration_count:02d}_H2_1.png')
    #--
    # 建立畫布
    fig, ax = plt.subplots(figsize=((PNG_Width / PNG_DPI, PNG_Height / PNG_DPI)))
    # 繪製網格
    ax, cbar = pg.show(PNG_mesh, 
        data=PNG_mesh_data, 
        ax=ax,
        markers=False,
        showMesh=PNG_mesh_showMesh,
        showBoundary=PNG_mesh_showBoundary,  
        label=PNG_colorbar_title,     # colorbar的標題。
        axisLabels=False,             # 阻止自動標籤(否則特定條件下會把Y軸轉換成深度)。後面自行填入標籤。
        cMap=PNG_cMap,
        cMin=PNG_cMin,
        cMax=PNG_cMax)
    # 繪製電極
    ax.plot(PNG_NumPy_Electrode_x[Good_Electrode_Index_0Base], PNG_NumPy_Electrode_y[Good_Electrode_Index_0Base], 'o', markersize=6, color='magenta', markerfacecolor='magenta', markeredgecolor='black', label='Electrode Nodes')    
    if len(Bad_Electrode_Index_0Base) >0 :
        ax.plot(PNG_NumPy_Electrode_x[Bad_Electrode_Index_0Base], PNG_NumPy_Electrode_y[Bad_Electrode_Index_0Base], 'o', markersize=6, color='magenta', markerfacecolor='lightgray', markeredgecolor='black', label='Skipped Electrode Nodes')
    ax.set_title(PNG_Main_Title, pad=3)  
    # 調整XY標籤
    ax.set_xlabel('Distance (m)')
    ax.set_ylabel('Elevation (m)')
    # 調整圖例
    ax.legend(loc='upper right',ncol=2,framealpha=0.4)
    # 調整colorbar內文字
    if PNG_colorbar_ticker_ModifyLog10ToLinear_Enable:
        cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.FuncFormatter(lambda x, pos: f'{10**x:.1f}'.rstrip('0').rstrip('.')))    
        cbar.ax.xaxis.get_offset_text().set_visible(False) # 避免顯示 1eX
        cbar.set_label(PNG_colorbar_ticker_ModifyLog10ToLinear_title) # 使用你設定的 Ωm 標題
    else:
        cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.ScalarFormatter(useMathText=False))
        cbar.ax.xaxis.get_major_formatter().set_useOffset(False) #禁用「偏移量 (Offset)」模式
        cbar.ax.xaxis.get_offset_text().set_visible(False)  # 避免顯示 1eX
    #--
    # 填入版本資訊
    fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
    # 調整邊界
    x_min, x_max = ax.get_xlim()
    y_min, y_max = ax.get_ylim()
    x_range = x_max - x_min
    y_range = y_max - y_min
    ax.set_ylim(y_min , y_max + 0.1 * y_range)
    #--
    #write_log_append(f'儲存 {PNG_Profile_Name} 圖片...')
    #Output_PNG_FileName = 'ABCD.png'
    if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
        os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
    plt.tight_layout() 
    plt.savefig(Output_PNG_FileName, dpi=PNG_DPI)
    plt.close()
    #write_log_append(f'儲存 {PNG_Profile_Name} 圖片...完成!')
    #==============================================================================
    #==============================================================================
    # Pygimli網格繪圖:  繪製研究區域網格逆推剖面(電阻率、電極位置、逆推資訊) 無coverage 有網格 #0
    #--    
    # 可填入的資訊
    PNG_Profile_Name = Main_FileName
    PNG_NumPy_Electrode_x = LastInversion_Data.sensors().array()[:, 0]
    PNG_NumPy_Electrode_y = LastInversion_Data.sensors().array()[:, 1]
    PNG_NumPy_Electrode_z = LastInversion_Data.sensors().array()[:, 2]
    PNG_mesh = LastInversion_InversionModelMesh
    PNG_mesh_data = LastInversion_InversionModelMesh['Resistivity_(log10)']
    PNG_colorbar_title = 'Resistivity (log10 Ωm)'
    PNG_colorbar_ticker_ModifyLog10ToLinear_Enable = True # True = 把colorbar數值文字從對數尺度調整成線性尺度 / False = 維持原本數值
    PNG_colorbar_ticker_ModifyLog10ToLinear_title = 'Resistivity (Ωm)'
    PNG_Main_Title = f"{PNG_Profile_Name} Inverted Resistivity Section " + \
        f" (Iteration={Info_Iteration_count})" + \
        f"\nData Count={Info_LastInversion_Obs_dataVals_Count}, " + \
        f"Data EstError={Data_Settings_Relative_Error_Percentage}%, " + \
        f"Remove Runs={Current_Remove_Runs}, " + \
        f"Remove Data={Inversion_Remove_Data_Percentage}%, " + \
        rf"$\lambda${Current_lambda_number}={Info_LastInversion_Lambda:.2f}, " + \
        f"limits=[{Inversion_limitModelCellMinValue:.2f},{Inversion_limitModelCellMaxValue:.2f}]Ωm, " + \
        f"RRMS={Info_LastInversion_RRMS:.2f}%, " + \
        rf"$\chi^2$={Info_LastInversion_chi2:.2f}"                 
    PNG_mesh_showMesh = True # True / False
    PNG_mesh_showBoundary = True # None / True / False ，某些時候None與True效果相同
    PNG_cMap = 'jet'
    PNG_cMin = np.min(PNG_mesh_data) # None表示自動
    PNG_cMax = np.max(PNG_mesh_data) # None表示自動
    # 檢查是否所有數值都很接近
    if (PNG_cMin - PNG_cMax) < 0.000002:
        # 如果很接近，設定極小的偏移量
        PNG_cMin = PNG_cMin - 0.000001
        PNG_cMax = PNG_cMax + 0.000001
    PNG_DPI = 100
    PNG_Width = 1280
    PNG_Height = 720    
    Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_R{Current_Remove_Runs:02d}_L{Current_lambda_number:02d}_I{Info_Iteration_count:02d}_INV.png')
    #--
    # 建立畫布
    fig, ax = plt.subplots(figsize=((PNG_Width / PNG_DPI, PNG_Height / PNG_DPI)))
    # 繪製網格
    ax, cbar = pg.show(PNG_mesh, 
        data=PNG_mesh_data, 
        ax=ax,
        markers=False,
        showMesh=PNG_mesh_showMesh,
        showBoundary=PNG_mesh_showBoundary,  
        label=PNG_colorbar_title,     # colorbar的標題。
        axisLabels=False,             # 阻止自動標籤(否則特定條件下會把Y軸轉換成深度)。後面自行填入標籤。
        cMap=PNG_cMap,
        cMin=PNG_cMin,
        cMax=PNG_cMax)
    # 繪製電極
    ax.plot(PNG_NumPy_Electrode_x[Good_Electrode_Index_0Base], PNG_NumPy_Electrode_y[Good_Electrode_Index_0Base], 'o', markersize=6, color='magenta', markerfacecolor='magenta', markeredgecolor='black', label='Electrode Nodes')    
    if len(Bad_Electrode_Index_0Base) >0 :
        ax.plot(PNG_NumPy_Electrode_x[Bad_Electrode_Index_0Base], PNG_NumPy_Electrode_y[Bad_Electrode_Index_0Base], 'o', markersize=6, color='magenta', markerfacecolor='lightgray', markeredgecolor='black', label='Skipped Electrode Nodes')
    ax.set_title(PNG_Main_Title, pad=3)  
    # 調整XY標籤
    ax.set_xlabel('Distance (m)')
    ax.set_ylabel('Elevation (m)')
    # 調整圖例
    ax.legend(loc='upper right',ncol=2,framealpha=0.4)
    # 調整colorbar內文字
    if PNG_colorbar_ticker_ModifyLog10ToLinear_Enable:
        cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.FuncFormatter(lambda x, pos: f'{10**x:.1f}'.rstrip('0').rstrip('.')))    
        cbar.ax.xaxis.get_offset_text().set_visible(False) # 避免顯示 1eX
        cbar.set_label(PNG_colorbar_ticker_ModifyLog10ToLinear_title) # 使用你設定的 Ωm 標題
    else:
        cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.ScalarFormatter(useMathText=False))
        cbar.ax.xaxis.get_major_formatter().set_useOffset(False) #禁用「偏移量 (Offset)」模式
        cbar.ax.xaxis.get_offset_text().set_visible(False)  # 避免顯示 1eX
    #--
    # 填入版本資訊
    fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
    # 調整邊界
    x_min, x_max = ax.get_xlim()
    y_min, y_max = ax.get_ylim()
    x_range = x_max - x_min
    y_range = y_max - y_min
    ax.set_ylim(y_min , y_max + 0.1 * y_range)
    #--
    #write_log_append(f'儲存 {PNG_Profile_Name} 圖片...')
    #Output_PNG_FileName = 'ABCD.png'
    if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
        os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
    plt.tight_layout() 
    plt.savefig(Output_PNG_FileName, dpi=PNG_DPI)
    plt.close()
    #write_log_append(f'儲存 {PNG_Profile_Name} 圖片...完成!')
    #==============================================================================
    #==============================================================================
    # Pygimli網格繪圖:  繪製研究區域網格逆推剖面(電阻率、電極位置、逆推資訊) 無coverage 無網格 #1
    #--    
    # 可填入的資訊
    PNG_Profile_Name = Main_FileName
    PNG_NumPy_Electrode_x = LastInversion_Data.sensors().array()[:, 0]
    PNG_NumPy_Electrode_y = LastInversion_Data.sensors().array()[:, 1]
    PNG_NumPy_Electrode_z = LastInversion_Data.sensors().array()[:, 2]
    PNG_mesh = LastInversion_InversionModelMesh
    PNG_mesh_data = LastInversion_InversionModelMesh['Resistivity_(log10)']
    PNG_colorbar_title = 'Resistivity (log10 Ωm)'
    PNG_colorbar_ticker_ModifyLog10ToLinear_Enable = True # True = 把colorbar數值文字從對數尺度調整成線性尺度 / False = 維持原本數值
    PNG_colorbar_ticker_ModifyLog10ToLinear_title = 'Resistivity (Ωm)'
    PNG_Main_Title = f"{PNG_Profile_Name} Inverted Resistivity Section " + \
        f" (Iteration={Info_Iteration_count})" + \
        f"\nData Count={Info_LastInversion_Obs_dataVals_Count}, " + \
        f"Data EstError={Data_Settings_Relative_Error_Percentage}%, " + \
        f"Remove Runs={Current_Remove_Runs}, " + \
        f"Remove Data={Inversion_Remove_Data_Percentage}%, " + \
        rf"$\lambda${Current_lambda_number}={Info_LastInversion_Lambda:.2f}, " + \
        f"limits=[{Inversion_limitModelCellMinValue:.2f},{Inversion_limitModelCellMaxValue:.2f}]Ωm, " + \
        f"RRMS={Info_LastInversion_RRMS:.2f}%, " + \
        rf"$\chi^2$={Info_LastInversion_chi2:.2f}"                 
    PNG_mesh_showMesh = False # True / False
    PNG_mesh_showBoundary = True # None / True / False ，某些時候None與True效果相同
    PNG_cMap = 'jet'
    PNG_cMin = np.min(PNG_mesh_data) # None表示自動
    PNG_cMax = np.max(PNG_mesh_data) # None表示自動
    # 檢查是否所有數值都很接近
    if (PNG_cMin - PNG_cMax) < 0.000002:
        # 如果很接近，設定極小的偏移量
        PNG_cMin = PNG_cMin - 0.000001
        PNG_cMax = PNG_cMax + 0.000001
    PNG_DPI = 100
    PNG_Width = 1280
    PNG_Height = 720    
    Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_R{Current_Remove_Runs:02d}_L{Current_lambda_number:02d}_I{Info_Iteration_count:02d}_INV1.png')
    #--
    # 建立畫布
    fig, ax = plt.subplots(figsize=((PNG_Width / PNG_DPI, PNG_Height / PNG_DPI)))
    # 繪製網格
    ax, cbar = pg.show(PNG_mesh, 
        data=PNG_mesh_data, 
        ax=ax,
        markers=False,
        showMesh=PNG_mesh_showMesh,
        showBoundary=PNG_mesh_showBoundary,  
        label=PNG_colorbar_title,     # colorbar的標題。
        axisLabels=False,             # 阻止自動標籤(否則特定條件下會把Y軸轉換成深度)。後面自行填入標籤。
        cMap=PNG_cMap,
        cMin=PNG_cMin,
        cMax=PNG_cMax)
    # 繪製電極
    ax.plot(PNG_NumPy_Electrode_x[Good_Electrode_Index_0Base], PNG_NumPy_Electrode_y[Good_Electrode_Index_0Base], 'o', markersize=6, color='magenta', markerfacecolor='magenta', markeredgecolor='black', label='Electrode Nodes')    
    if len(Bad_Electrode_Index_0Base) >0 :
        ax.plot(PNG_NumPy_Electrode_x[Bad_Electrode_Index_0Base], PNG_NumPy_Electrode_y[Bad_Electrode_Index_0Base], 'o', markersize=6, color='magenta', markerfacecolor='lightgray', markeredgecolor='black', label='Skipped Electrode Nodes')
    ax.set_title(PNG_Main_Title, pad=3)  
    # 調整XY標籤
    ax.set_xlabel('Distance (m)')
    ax.set_ylabel('Elevation (m)')
    # 調整圖例
    ax.legend(loc='upper right',ncol=2,framealpha=0.4)
    # 調整colorbar內文字
    if PNG_colorbar_ticker_ModifyLog10ToLinear_Enable:
        cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.FuncFormatter(lambda x, pos: f'{10**x:.1f}'.rstrip('0').rstrip('.')))    
        cbar.ax.xaxis.get_offset_text().set_visible(False) # 避免顯示 1eX
        cbar.set_label(PNG_colorbar_ticker_ModifyLog10ToLinear_title) # 使用你設定的 Ωm 標題
    else:
        cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.ScalarFormatter(useMathText=False))
        cbar.ax.xaxis.get_major_formatter().set_useOffset(False) #禁用「偏移量 (Offset)」模式
        cbar.ax.xaxis.get_offset_text().set_visible(False)  # 避免顯示 1eX
    #--
    # 填入版本資訊
    fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
    # 調整邊界
    x_min, x_max = ax.get_xlim()
    y_min, y_max = ax.get_ylim()
    x_range = x_max - x_min
    y_range = y_max - y_min
    ax.set_ylim(y_min , y_max + 0.1 * y_range)
    #--
    #write_log_append(f'儲存 {PNG_Profile_Name} 圖片...')
    #Output_PNG_FileName = 'ABCD.png'
    if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
        os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
    plt.tight_layout() 
    plt.savefig(Output_PNG_FileName, dpi=PNG_DPI)
    plt.close()
    #write_log_append(f'儲存 {PNG_Profile_Name} 圖片...完成!')
    #==============================================================================
    #==============================================================================
    # Pygimli網格繪圖:  繪製研究區域網格逆推剖面(電阻率、電極位置、逆推資訊) 無coverage 有網格 自訂colorbar #2
    #--    
    # 可填入的資訊
    PNG_Profile_Name = Main_FileName
    PNG_NumPy_Electrode_x = LastInversion_Data.sensors().array()[:, 0]
    PNG_NumPy_Electrode_y = LastInversion_Data.sensors().array()[:, 1]
    PNG_NumPy_Electrode_z = LastInversion_Data.sensors().array()[:, 2]
    PNG_mesh = LastInversion_InversionModelMesh
    PNG_mesh_data = LastInversion_InversionModelMesh['Resistivity_(log10)']
    PNG_colorbar_title = 'Resistivity (log10 Ωm)'
    PNG_colorbar_ticker_ModifyLog10ToLinear_Enable = True # True = 把colorbar數值文字從對數尺度調整成線性尺度 / False = 維持原本數值
    PNG_colorbar_ticker_ModifyLog10ToLinear_title = 'Resistivity (Ωm)'
    PNG_Main_Title = f"{PNG_Profile_Name} Inverted Resistivity Section " + \
        f" (Iteration={Info_Iteration_count})" + \
        f"\nData Count={Info_LastInversion_Obs_dataVals_Count}, " + \
        f"Data EstError={Data_Settings_Relative_Error_Percentage}%, " + \
        f"Remove Runs={Current_Remove_Runs}, " + \
        f"Remove Data={Inversion_Remove_Data_Percentage}%, " + \
        rf"$\lambda${Current_lambda_number}={Info_LastInversion_Lambda:.2f}, " + \
        f"limits=[{Inversion_limitModelCellMinValue:.2f},{Inversion_limitModelCellMaxValue:.2f}]Ωm, " + \
        f"RRMS={Info_LastInversion_RRMS:.2f}%, " + \
        rf"$\chi^2$={Info_LastInversion_chi2:.2f}"                 
    PNG_mesh_showMesh = True # True / False
    PNG_mesh_showBoundary = True # None / True / False ，某些時候None與True效果相同
    PNG_cMap = 'jet'
    PNG_cMin = np.log10(temp_json_data['Output_Inversion_ColorBarResistivityMin']) # None表示自動
    PNG_cMax = np.log10(temp_json_data['Output_Inversion_ColorBarResistivityMax']) # None表示自動
    PNG_DPI = 100
    PNG_Width = 1280
    PNG_Height = 720    
    Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_R{Current_Remove_Runs:02d}_L{Current_lambda_number:02d}_I{Info_Iteration_count:02d}_INV2.png')
    #--
    # 建立畫布
    fig, ax = plt.subplots(figsize=((PNG_Width / PNG_DPI, PNG_Height / PNG_DPI)))
    # 繪製網格
    ax, cbar = pg.show(PNG_mesh, 
        data=PNG_mesh_data, 
        ax=ax,
        markers=False,
        showMesh=PNG_mesh_showMesh,
        showBoundary=PNG_mesh_showBoundary,  
        label=PNG_colorbar_title,     # colorbar的標題。
        axisLabels=False,             # 阻止自動標籤(否則特定條件下會把Y軸轉換成深度)。後面自行填入標籤。
        cMap=PNG_cMap,
        cMin=PNG_cMin,
        cMax=PNG_cMax)
    # 繪製電極
    ax.plot(PNG_NumPy_Electrode_x[Good_Electrode_Index_0Base], PNG_NumPy_Electrode_y[Good_Electrode_Index_0Base], 'o', markersize=6, color='magenta', markerfacecolor='magenta', markeredgecolor='black', label='Electrode Nodes')    
    if len(Bad_Electrode_Index_0Base) >0 :
        ax.plot(PNG_NumPy_Electrode_x[Bad_Electrode_Index_0Base], PNG_NumPy_Electrode_y[Bad_Electrode_Index_0Base], 'o', markersize=6, color='magenta', markerfacecolor='lightgray', markeredgecolor='black', label='Skipped Electrode Nodes')
    ax.set_title(PNG_Main_Title, pad=3)  
    # 調整XY標籤
    ax.set_xlabel('Distance (m)')
    ax.set_ylabel('Elevation (m)')
    # 調整圖例
    ax.legend(loc='upper right',ncol=2,framealpha=0.4)
    # 調整colorbar內文字
    if PNG_colorbar_ticker_ModifyLog10ToLinear_Enable:
        cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.FuncFormatter(lambda x, pos: f'{10**x:.1f}'.rstrip('0').rstrip('.')))    
        cbar.ax.xaxis.get_offset_text().set_visible(False) # 避免顯示 1eX
        cbar.set_label(PNG_colorbar_ticker_ModifyLog10ToLinear_title) # 使用你設定的 Ωm 標題
    else:
        cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.ScalarFormatter(useMathText=False))
        cbar.ax.xaxis.get_major_formatter().set_useOffset(False) #禁用「偏移量 (Offset)」模式
        cbar.ax.xaxis.get_offset_text().set_visible(False)  # 避免顯示 1eX
    #--
    # 填入版本資訊
    fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
    # 調整邊界
    x_min, x_max = ax.get_xlim()
    y_min, y_max = ax.get_ylim()
    x_range = x_max - x_min
    y_range = y_max - y_min
    ax.set_ylim(y_min , y_max + 0.1 * y_range)
    #--
    #write_log_append(f'儲存 {PNG_Profile_Name} 圖片...')
    #Output_PNG_FileName = 'ABCD.png'
    if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
        os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
    plt.tight_layout() 
    plt.savefig(Output_PNG_FileName, dpi=PNG_DPI)
    plt.close()
    #write_log_append(f'儲存 {PNG_Profile_Name} 圖片...完成!')
    #==============================================================================
    #==============================================================================
    # Pygimli網格繪圖:  繪製研究區域網格逆推剖面(電阻率、電極位置、逆推資訊) 無coverage 無網格 自訂colorbar #3
    #--    
    # 可填入的資訊
    PNG_Profile_Name = Main_FileName
    PNG_NumPy_Electrode_x = LastInversion_Data.sensors().array()[:, 0]
    PNG_NumPy_Electrode_y = LastInversion_Data.sensors().array()[:, 1]
    PNG_NumPy_Electrode_z = LastInversion_Data.sensors().array()[:, 2]
    PNG_mesh = LastInversion_InversionModelMesh
    PNG_mesh_data = LastInversion_InversionModelMesh['Resistivity_(log10)']
    PNG_colorbar_title = 'Resistivity (log10 Ωm)'
    PNG_colorbar_ticker_ModifyLog10ToLinear_Enable = True # True = 把colorbar數值文字從對數尺度調整成線性尺度 / False = 維持原本數值
    PNG_colorbar_ticker_ModifyLog10ToLinear_title = 'Resistivity (Ωm)'
    PNG_Main_Title = f"{PNG_Profile_Name} Inverted Resistivity Section " + \
        f" (Iteration={Info_Iteration_count})" + \
        f"\nData Count={Info_LastInversion_Obs_dataVals_Count}, " + \
        f"Data EstError={Data_Settings_Relative_Error_Percentage}%, " + \
        f"Remove Runs={Current_Remove_Runs}, " + \
        f"Remove Data={Inversion_Remove_Data_Percentage}%, " + \
        rf"$\lambda${Current_lambda_number}={Info_LastInversion_Lambda:.2f}, " + \
        f"limits=[{Inversion_limitModelCellMinValue:.2f},{Inversion_limitModelCellMaxValue:.2f}]Ωm, " + \
        f"RRMS={Info_LastInversion_RRMS:.2f}%, " + \
        rf"$\chi^2$={Info_LastInversion_chi2:.2f}"                 
    PNG_mesh_showMesh = False # True / False
    PNG_mesh_showBoundary = True # None / True / False ，某些時候None與True效果相同
    PNG_cMap = 'jet'
    PNG_cMin = np.log10(temp_json_data['Output_Inversion_ColorBarResistivityMin']) # None表示自動
    PNG_cMax = np.log10(temp_json_data['Output_Inversion_ColorBarResistivityMax']) # None表示自動
    PNG_DPI = 100
    PNG_Width = 1280
    PNG_Height = 720    
    Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_R{Current_Remove_Runs:02d}_L{Current_lambda_number:02d}_I{Info_Iteration_count:02d}_INV3.png')
    #--
    # 建立畫布
    fig, ax = plt.subplots(figsize=((PNG_Width / PNG_DPI, PNG_Height / PNG_DPI)))
    # 繪製網格
    ax, cbar = pg.show(PNG_mesh, 
        data=PNG_mesh_data, 
        ax=ax,
        markers=False,
        showMesh=PNG_mesh_showMesh,
        showBoundary=PNG_mesh_showBoundary,  
        label=PNG_colorbar_title,     # colorbar的標題。
        axisLabels=False,             # 阻止自動標籤(否則特定條件下會把Y軸轉換成深度)。後面自行填入標籤。
        cMap=PNG_cMap,
        cMin=PNG_cMin,
        cMax=PNG_cMax)
    # 繪製電極
    ax.plot(PNG_NumPy_Electrode_x[Good_Electrode_Index_0Base], PNG_NumPy_Electrode_y[Good_Electrode_Index_0Base], 'o', markersize=6, color='magenta', markerfacecolor='magenta', markeredgecolor='black', label='Electrode Nodes')    
    if len(Bad_Electrode_Index_0Base) >0 :
        ax.plot(PNG_NumPy_Electrode_x[Bad_Electrode_Index_0Base], PNG_NumPy_Electrode_y[Bad_Electrode_Index_0Base], 'o', markersize=6, color='magenta', markerfacecolor='lightgray', markeredgecolor='black', label='Skipped Electrode Nodes')
    ax.set_title(PNG_Main_Title, pad=3)  
    # 調整XY標籤
    ax.set_xlabel('Distance (m)')
    ax.set_ylabel('Elevation (m)')
    # 調整圖例
    ax.legend(loc='upper right',ncol=2,framealpha=0.4)
    # 調整colorbar內文字
    if PNG_colorbar_ticker_ModifyLog10ToLinear_Enable:
        cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.FuncFormatter(lambda x, pos: f'{10**x:.1f}'.rstrip('0').rstrip('.')))    
        cbar.ax.xaxis.get_offset_text().set_visible(False) # 避免顯示 1eX
        cbar.set_label(PNG_colorbar_ticker_ModifyLog10ToLinear_title) # 使用你設定的 Ωm 標題
    else:
        cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.ScalarFormatter(useMathText=False))
        cbar.ax.xaxis.get_major_formatter().set_useOffset(False) #禁用「偏移量 (Offset)」模式
        cbar.ax.xaxis.get_offset_text().set_visible(False)  # 避免顯示 1eX
    #--
    # 填入版本資訊
    fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
    # 調整邊界
    x_min, x_max = ax.get_xlim()
    y_min, y_max = ax.get_ylim()
    x_range = x_max - x_min
    y_range = y_max - y_min
    ax.set_ylim(y_min , y_max + 0.1 * y_range)
    #--
    #write_log_append(f'儲存 {PNG_Profile_Name} 圖片...')
    #Output_PNG_FileName = 'ABCD.png'
    if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
        os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
    plt.tight_layout() 
    plt.savefig(Output_PNG_FileName, dpi=PNG_DPI)
    plt.close()
    #write_log_append(f'儲存 {PNG_Profile_Name} 圖片...完成!')
    #==============================================================================
    if temp_json_data["Output_Inversion_XMinMax_Enable"] == 'Yes' :
        #==============================================================================
        # Pygimli網格繪圖:  繪製研究區域網格逆推剖面(電阻率、電極位置、逆推資訊) 無coverage 無網格 自訂colorbar 自訂XY範圍#3a
        #--    
        # 可填入的資訊
        PNG_Profile_Name = Main_FileName
        PNG_NumPy_Electrode_x = LastInversion_Data.sensors().array()[:, 0]
        PNG_NumPy_Electrode_y = LastInversion_Data.sensors().array()[:, 1]
        PNG_NumPy_Electrode_z = LastInversion_Data.sensors().array()[:, 2]
        PNG_mesh = LastInversion_InversionModelMesh
        PNG_mesh_data = LastInversion_InversionModelMesh['Resistivity_(log10)']
        PNG_colorbar_title = 'Resistivity (log10 Ωm)'
        PNG_colorbar_ticker_ModifyLog10ToLinear_Enable = True # True = 把colorbar數值文字從對數尺度調整成線性尺度 / False = 維持原本數值
        PNG_colorbar_ticker_ModifyLog10ToLinear_title = 'Resistivity (Ωm)'
        PNG_Main_Title = f"{PNG_Profile_Name} Inverted Resistivity Section " + \
            f" (Iteration={Info_Iteration_count})" + \
            f"\nData Count={Info_LastInversion_Obs_dataVals_Count}, " + \
            f"Data EstError={Data_Settings_Relative_Error_Percentage}%, " + \
            f"Remove Runs={Current_Remove_Runs}, " + \
            f"Remove Data={Inversion_Remove_Data_Percentage}%, " + \
            rf"$\lambda${Current_lambda_number}={Info_LastInversion_Lambda:.2f}, " + \
            f"limits=[{Inversion_limitModelCellMinValue:.2f},{Inversion_limitModelCellMaxValue:.2f}]Ωm, " + \
            f"RRMS={Info_LastInversion_RRMS:.2f}%, " + \
            rf"$\chi^2$={Info_LastInversion_chi2:.2f}"                 
        PNG_mesh_showMesh = False # True / False
        PNG_mesh_showBoundary = True # None / True / False ，某些時候None與True效果相同
        PNG_cMap = 'jet'
        PNG_cMin = np.log10(temp_json_data['Output_Inversion_ColorBarResistivityMin']) # None表示自動
        PNG_cMax = np.log10(temp_json_data['Output_Inversion_ColorBarResistivityMax']) # None表示自動
        PNG_DPI = 100
        PNG_Width = 1280
        PNG_Height = 720    
        Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_R{Current_Remove_Runs:02d}_L{Current_lambda_number:02d}_I{Info_Iteration_count:02d}_INV3a.png')
        #--
        # 建立畫布
        fig, ax = plt.subplots(figsize=((PNG_Width / PNG_DPI, PNG_Height / PNG_DPI)))
        # 繪製網格
        ax, cbar = pg.show(PNG_mesh, 
            data=PNG_mesh_data, 
            ax=ax,
            markers=False,
            showMesh=PNG_mesh_showMesh,
            showBoundary=PNG_mesh_showBoundary,  
            label=PNG_colorbar_title,     # colorbar的標題。
            axisLabels=False,             # 阻止自動標籤(否則特定條件下會把Y軸轉換成深度)。後面自行填入標籤。
            cMap=PNG_cMap,
            cMin=PNG_cMin,
            cMax=PNG_cMax)
        # 繪製電極
        ax.plot(PNG_NumPy_Electrode_x[Good_Electrode_Index_0Base], PNG_NumPy_Electrode_y[Good_Electrode_Index_0Base], 'o', markersize=6, color='magenta', markerfacecolor='magenta', markeredgecolor='black', label='Electrode Nodes')    
        if len(Bad_Electrode_Index_0Base) >0 :
            ax.plot(PNG_NumPy_Electrode_x[Bad_Electrode_Index_0Base], PNG_NumPy_Electrode_y[Bad_Electrode_Index_0Base], 'o', markersize=6, color='magenta', markerfacecolor='lightgray', markeredgecolor='black', label='Skipped Electrode Nodes')
        ax.set_title(PNG_Main_Title, pad=3)  
        # 調整XY標籤
        ax.set_xlabel('Distance (m)')
        ax.set_ylabel('Elevation (m)')
        # 調整圖例
        ax.legend(loc='upper right',ncol=2,framealpha=0.4)
        # 調整colorbar內文字
        if PNG_colorbar_ticker_ModifyLog10ToLinear_Enable:
            cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.FuncFormatter(lambda x, pos: f'{10**x:.1f}'.rstrip('0').rstrip('.')))    
            cbar.ax.xaxis.get_offset_text().set_visible(False) # 避免顯示 1eX
            cbar.set_label(PNG_colorbar_ticker_ModifyLog10ToLinear_title) # 使用你設定的 Ωm 標題
        else:
            cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.ScalarFormatter(useMathText=False))
            cbar.ax.xaxis.get_major_formatter().set_useOffset(False) #禁用「偏移量 (Offset)」模式
            cbar.ax.xaxis.get_offset_text().set_visible(False)  # 避免顯示 1eX
        #--
        # 填入版本資訊
        fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
        # 調整邊界
        x_min, x_max = ax.get_xlim()
        y_min, y_max = ax.get_ylim()
        x_range = x_max - x_min
        y_range = y_max - y_min    
        #--
        # 依照參數設定繪製範圍
        ax.set_xlim(temp_json_data['Output_Inversion_XMin'] , temp_json_data['Output_Inversion_XMax'])
        ax.set_ylim(temp_json_data['Output_Inversion_YMin'] , temp_json_data['Output_Inversion_YMax'])
        #--
        #write_log_append(f'儲存 {PNG_Profile_Name} 圖片...')
        #Output_PNG_FileName = 'ABCD.png'
        if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
            os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
        plt.tight_layout() 
        plt.savefig(Output_PNG_FileName, dpi=PNG_DPI)
        plt.close()
        #write_log_append(f'儲存 {PNG_Profile_Name} 圖片...完成!')
        #==============================================================================
    #==============================================================================
    # Pygimli網格繪圖:  繪製研究區域網格逆推剖面(電阻率、電極位置、逆推資訊) 有coverage 有網格 #C0
    #--    
    # 可填入的資訊
    PNG_Profile_Name = Main_FileName
    PNG_NumPy_Electrode_x = LastInversion_Data.sensors().array()[:, 0]
    PNG_NumPy_Electrode_y = LastInversion_Data.sensors().array()[:, 1]
    PNG_NumPy_Electrode_z = LastInversion_Data.sensors().array()[:, 2]
    PNG_mesh = LastInversion_InversionModelMesh
    PNG_mesh_data = LastInversion_InversionModelMesh['Resistivity_(log10)']
    PNG_mesh_coverage = LastInversion_InversionModelMesh['Coverage']
    PNG_colorbar_title = 'Resistivity (log10 Ωm)'
    PNG_colorbar_ticker_ModifyLog10ToLinear_Enable = True # True = 把colorbar數值文字從對數尺度調整成線性尺度 / False = 維持原本數值
    PNG_colorbar_ticker_ModifyLog10ToLinear_title = 'Resistivity (Ωm)'
    PNG_Main_Title = f"{PNG_Profile_Name} Inverted Resistivity Section with Coverage " + \
        f" (Iteration={Info_Iteration_count})" + \
        f"\nData Count={Info_LastInversion_Obs_dataVals_Count}, " + \
        f"Data EstError={Data_Settings_Relative_Error_Percentage}%, " + \
        f"Remove Runs={Current_Remove_Runs}, " + \
        f"Remove Data={Inversion_Remove_Data_Percentage}%, " + \
        rf"$\lambda${Current_lambda_number}={Info_LastInversion_Lambda:.2f}, " + \
        f"limits=[{Inversion_limitModelCellMinValue:.2f},{Inversion_limitModelCellMaxValue:.2f}]Ωm, " + \
        f"RRMS={Info_LastInversion_RRMS:.2f}%, " + \
        rf"$\chi^2$={Info_LastInversion_chi2:.2f}"                 
    PNG_mesh_showMesh = True # True / False
    PNG_mesh_showBoundary = True # None / True / False ，某些時候None與True效果相同
    PNG_cMap = 'jet'
    PNG_cMin = np.min(PNG_mesh_data) # None表示自動
    PNG_cMax = np.max(PNG_mesh_data) # None表示自動
    # 檢查是否所有數值都很接近
    if (PNG_cMin - PNG_cMax) < 0.000002:
        # 如果很接近，設定極小的偏移量
        PNG_cMin = PNG_cMin - 0.000001
        PNG_cMax = PNG_cMax + 0.000001
    PNG_DPI = 100
    PNG_Width = 1280
    PNG_Height = 720    
    Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_R{Current_Remove_Runs:02d}_L{Current_lambda_number:02d}_I{Info_Iteration_count:02d}_INVC.png')
    #--
    # 建立畫布
    fig, ax = plt.subplots(figsize=((PNG_Width / PNG_DPI, PNG_Height / PNG_DPI)))
    # 繪製網格
    ax, cbar = pg.show(PNG_mesh, 
        data=PNG_mesh_data, 
        coverage=PNG_mesh_coverage,
        ax=ax,
        markers=False,
        showMesh=PNG_mesh_showMesh,
        showBoundary=PNG_mesh_showBoundary,  
        label=PNG_colorbar_title,     # colorbar的標題。
        axisLabels=False,             # 阻止自動標籤(否則特定條件下會把Y軸轉換成深度)。後面自行填入標籤。
        cMap=PNG_cMap,
        cMin=PNG_cMin,
        cMax=PNG_cMax)
    # 繪製電極
    ax.plot(PNG_NumPy_Electrode_x[Good_Electrode_Index_0Base], PNG_NumPy_Electrode_y[Good_Electrode_Index_0Base], 'o', markersize=6, color='magenta', markerfacecolor='magenta', markeredgecolor='black', label='Electrode Nodes')    
    if len(Bad_Electrode_Index_0Base) >0 :
        ax.plot(PNG_NumPy_Electrode_x[Bad_Electrode_Index_0Base], PNG_NumPy_Electrode_y[Bad_Electrode_Index_0Base], 'o', markersize=6, color='magenta', markerfacecolor='lightgray', markeredgecolor='black', label='Skipped Electrode Nodes')
    ax.set_title(PNG_Main_Title, pad=3)  
    # 調整XY標籤
    ax.set_xlabel('Distance (m)')
    ax.set_ylabel('Elevation (m)')
    # 調整圖例
    ax.legend(loc='upper right',ncol=2,framealpha=0.4)
    # 調整colorbar內文字
    if PNG_colorbar_ticker_ModifyLog10ToLinear_Enable:
        cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.FuncFormatter(lambda x, pos: f'{10**x:.1f}'.rstrip('0').rstrip('.')))    
        cbar.ax.xaxis.get_offset_text().set_visible(False) # 避免顯示 1eX
        cbar.set_label(PNG_colorbar_ticker_ModifyLog10ToLinear_title) # 使用你設定的 Ωm 標題
    else:
        cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.ScalarFormatter(useMathText=False))
        cbar.ax.xaxis.get_major_formatter().set_useOffset(False) #禁用「偏移量 (Offset)」模式
        cbar.ax.xaxis.get_offset_text().set_visible(False)  # 避免顯示 1eX
    #--
    # 填入版本資訊
    fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
    # 調整邊界
    x_min, x_max = ax.get_xlim()
    y_min, y_max = ax.get_ylim()
    x_range = x_max - x_min
    y_range = y_max - y_min
    ax.set_ylim(y_min , y_max + 0.1 * y_range)
    #--
    #write_log_append(f'儲存 {PNG_Profile_Name} 圖片...')
    #Output_PNG_FileName = 'ABCD.png'
    if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
        os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
    plt.tight_layout() 
    plt.savefig(Output_PNG_FileName, dpi=PNG_DPI)
    plt.close()
    #write_log_append(f'儲存 {PNG_Profile_Name} 圖片...完成!')
    #==============================================================================
    #==============================================================================
    # Pygimli網格繪圖:  繪製研究區域網格逆推剖面(電阻率、電極位置、逆推資訊) 有coverage 無網格 #C1
    #--    
    # 可填入的資訊
    PNG_Profile_Name = Main_FileName
    PNG_NumPy_Electrode_x = LastInversion_Data.sensors().array()[:, 0]
    PNG_NumPy_Electrode_y = LastInversion_Data.sensors().array()[:, 1]
    PNG_NumPy_Electrode_z = LastInversion_Data.sensors().array()[:, 2]
    PNG_mesh = LastInversion_InversionModelMesh
    PNG_mesh_data = LastInversion_InversionModelMesh['Resistivity_(log10)']
    PNG_mesh_coverage = LastInversion_InversionModelMesh['Coverage']
    PNG_colorbar_title = 'Resistivity (log10 Ωm)'
    PNG_colorbar_ticker_ModifyLog10ToLinear_Enable = True # True = 把colorbar數值文字從對數尺度調整成線性尺度 / False = 維持原本數值
    PNG_colorbar_ticker_ModifyLog10ToLinear_title = 'Resistivity (Ωm)'
    PNG_Main_Title = f"{PNG_Profile_Name} Inverted Resistivity Section with Coverage " + \
        f" (Iteration={Info_Iteration_count})" + \
        f"\nData Count={Info_LastInversion_Obs_dataVals_Count}, " + \
        f"Data EstError={Data_Settings_Relative_Error_Percentage}%, " + \
        f"Remove Runs={Current_Remove_Runs}, " + \
        f"Remove Data={Inversion_Remove_Data_Percentage}%, " + \
        rf"$\lambda${Current_lambda_number}={Info_LastInversion_Lambda:.2f}, " + \
        f"limits=[{Inversion_limitModelCellMinValue:.2f},{Inversion_limitModelCellMaxValue:.2f}]Ωm, " + \
        f"RRMS={Info_LastInversion_RRMS:.2f}%, " + \
        rf"$\chi^2$={Info_LastInversion_chi2:.2f}"                 
    PNG_mesh_showMesh = False # True / False
    PNG_mesh_showBoundary = True # None / True / False ，某些時候None與True效果相同
    PNG_cMap = 'jet'
    PNG_cMin = np.min(PNG_mesh_data) # None表示自動
    PNG_cMax = np.max(PNG_mesh_data) # None表示自動
    # 檢查是否所有數值都很接近
    if (PNG_cMin - PNG_cMax) < 0.000002:
        # 如果很接近，設定極小的偏移量
        PNG_cMin = PNG_cMin - 0.000001
        PNG_cMax = PNG_cMax + 0.000001
    PNG_DPI = 100
    PNG_Width = 1280
    PNG_Height = 720    
    Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_R{Current_Remove_Runs:02d}_L{Current_lambda_number:02d}_I{Info_Iteration_count:02d}_INVC1.png')
    #--
    # 建立畫布
    fig, ax = plt.subplots(figsize=((PNG_Width / PNG_DPI, PNG_Height / PNG_DPI)))
    # 繪製網格
    ax, cbar = pg.show(PNG_mesh, 
        data=PNG_mesh_data, 
        coverage=PNG_mesh_coverage,
        ax=ax,
        markers=False,
        showMesh=PNG_mesh_showMesh,
        showBoundary=PNG_mesh_showBoundary,  
        label=PNG_colorbar_title,     # colorbar的標題。
        axisLabels=False,             # 阻止自動標籤(否則特定條件下會把Y軸轉換成深度)。後面自行填入標籤。
        cMap=PNG_cMap,
        cMin=PNG_cMin,
        cMax=PNG_cMax)
    # 繪製電極
    ax.plot(PNG_NumPy_Electrode_x[Good_Electrode_Index_0Base], PNG_NumPy_Electrode_y[Good_Electrode_Index_0Base], 'o', markersize=6, color='magenta', markerfacecolor='magenta', markeredgecolor='black', label='Electrode Nodes')    
    if len(Bad_Electrode_Index_0Base) >0 :
        ax.plot(PNG_NumPy_Electrode_x[Bad_Electrode_Index_0Base], PNG_NumPy_Electrode_y[Bad_Electrode_Index_0Base], 'o', markersize=6, color='magenta', markerfacecolor='lightgray', markeredgecolor='black', label='Skipped Electrode Nodes')
    ax.set_title(PNG_Main_Title, pad=3)  
    # 調整XY標籤
    ax.set_xlabel('Distance (m)')
    ax.set_ylabel('Elevation (m)')
    # 調整圖例
    ax.legend(loc='upper right',ncol=2,framealpha=0.4)
    # 調整colorbar內文字
    if PNG_colorbar_ticker_ModifyLog10ToLinear_Enable:
        cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.FuncFormatter(lambda x, pos: f'{10**x:.1f}'.rstrip('0').rstrip('.')))    
        cbar.ax.xaxis.get_offset_text().set_visible(False) # 避免顯示 1eX
        cbar.set_label(PNG_colorbar_ticker_ModifyLog10ToLinear_title) # 使用你設定的 Ωm 標題
    else:
        cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.ScalarFormatter(useMathText=False))
        cbar.ax.xaxis.get_major_formatter().set_useOffset(False) #禁用「偏移量 (Offset)」模式
        cbar.ax.xaxis.get_offset_text().set_visible(False)  # 避免顯示 1eX
    #--
    # 填入版本資訊
    fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
    # 調整邊界
    x_min, x_max = ax.get_xlim()
    y_min, y_max = ax.get_ylim()
    x_range = x_max - x_min
    y_range = y_max - y_min
    ax.set_ylim(y_min , y_max + 0.1 * y_range)
    #--
    #write_log_append(f'儲存 {PNG_Profile_Name} 圖片...')
    #Output_PNG_FileName = 'ABCD.png'
    if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
        os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
    plt.tight_layout() 
    plt.savefig(Output_PNG_FileName, dpi=PNG_DPI)
    plt.close()
    #write_log_append(f'儲存 {PNG_Profile_Name} 圖片...完成!')
    #==============================================================================
    #==============================================================================
    # Pygimli網格繪圖:  繪製研究區域網格逆推剖面(電阻率、電極位置、逆推資訊) 有coverage 有網格 自訂colorbar #C2
    #--    
    # 可填入的資訊
    PNG_Profile_Name = Main_FileName
    PNG_NumPy_Electrode_x = LastInversion_Data.sensors().array()[:, 0]
    PNG_NumPy_Electrode_y = LastInversion_Data.sensors().array()[:, 1]
    PNG_NumPy_Electrode_z = LastInversion_Data.sensors().array()[:, 2]
    PNG_mesh = LastInversion_InversionModelMesh
    PNG_mesh_data = LastInversion_InversionModelMesh['Resistivity_(log10)']
    PNG_mesh_coverage = LastInversion_InversionModelMesh['Coverage']
    PNG_colorbar_title = 'Resistivity (log10 Ωm)'
    PNG_colorbar_ticker_ModifyLog10ToLinear_Enable = True # True = 把colorbar數值文字從對數尺度調整成線性尺度 / False = 維持原本數值
    PNG_colorbar_ticker_ModifyLog10ToLinear_title = 'Resistivity (Ωm)'
    PNG_Main_Title = f"{PNG_Profile_Name} Inverted Resistivity Section with Coverage " + \
        f" (Iteration={Info_Iteration_count})" + \
        f"\nData Count={Info_LastInversion_Obs_dataVals_Count}, " + \
        f"Data EstError={Data_Settings_Relative_Error_Percentage}%, " + \
        f"Remove Runs={Current_Remove_Runs}, " + \
        f"Remove Data={Inversion_Remove_Data_Percentage}%, " + \
        rf"$\lambda${Current_lambda_number}={Info_LastInversion_Lambda:.2f}, " + \
        f"limits=[{Inversion_limitModelCellMinValue:.2f},{Inversion_limitModelCellMaxValue:.2f}]Ωm, " + \
        f"RRMS={Info_LastInversion_RRMS:.2f}%, " + \
        rf"$\chi^2$={Info_LastInversion_chi2:.2f}"                 
    PNG_mesh_showMesh = True # True / False
    PNG_mesh_showBoundary = True # None / True / False ，某些時候None與True效果相同
    PNG_cMap = 'jet'
    PNG_cMin = np.log10(temp_json_data['Output_Inversion_ColorBarResistivityMin']) # None表示自動
    PNG_cMax = np.log10(temp_json_data['Output_Inversion_ColorBarResistivityMax']) # None表示自動
    PNG_DPI = 100
    PNG_Width = 1280
    PNG_Height = 720    
    Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_R{Current_Remove_Runs:02d}_L{Current_lambda_number:02d}_I{Info_Iteration_count:02d}_INVC2.png')
    #--
    # 建立畫布
    fig, ax = plt.subplots(figsize=((PNG_Width / PNG_DPI, PNG_Height / PNG_DPI)))
    # 繪製網格
    ax, cbar = pg.show(PNG_mesh, 
        data=PNG_mesh_data, 
        coverage=PNG_mesh_coverage,
        ax=ax,
        markers=False,
        showMesh=PNG_mesh_showMesh,
        showBoundary=PNG_mesh_showBoundary,  
        label=PNG_colorbar_title,     # colorbar的標題。
        axisLabels=False,             # 阻止自動標籤(否則特定條件下會把Y軸轉換成深度)。後面自行填入標籤。
        cMap=PNG_cMap,
        cMin=PNG_cMin,
        cMax=PNG_cMax)
    # 繪製電極
    ax.plot(PNG_NumPy_Electrode_x[Good_Electrode_Index_0Base], PNG_NumPy_Electrode_y[Good_Electrode_Index_0Base], 'o', markersize=6, color='magenta', markerfacecolor='magenta', markeredgecolor='black', label='Electrode Nodes')    
    if len(Bad_Electrode_Index_0Base) >0 :
        ax.plot(PNG_NumPy_Electrode_x[Bad_Electrode_Index_0Base], PNG_NumPy_Electrode_y[Bad_Electrode_Index_0Base], 'o', markersize=6, color='magenta', markerfacecolor='lightgray', markeredgecolor='black', label='Skipped Electrode Nodes')
    ax.set_title(PNG_Main_Title, pad=3)  
    # 調整XY標籤
    ax.set_xlabel('Distance (m)')
    ax.set_ylabel('Elevation (m)')
    # 調整圖例
    ax.legend(loc='upper right',ncol=2,framealpha=0.4)
    # 調整colorbar內文字
    if PNG_colorbar_ticker_ModifyLog10ToLinear_Enable:
        cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.FuncFormatter(lambda x, pos: f'{10**x:.1f}'.rstrip('0').rstrip('.')))    
        cbar.ax.xaxis.get_offset_text().set_visible(False) # 避免顯示 1eX
        cbar.set_label(PNG_colorbar_ticker_ModifyLog10ToLinear_title) # 使用你設定的 Ωm 標題
    else:
        cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.ScalarFormatter(useMathText=False))
        cbar.ax.xaxis.get_major_formatter().set_useOffset(False) #禁用「偏移量 (Offset)」模式
        cbar.ax.xaxis.get_offset_text().set_visible(False)  # 避免顯示 1eX
    #--
    # 填入版本資訊
    fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
    # 調整邊界
    x_min, x_max = ax.get_xlim()
    y_min, y_max = ax.get_ylim()
    x_range = x_max - x_min
    y_range = y_max - y_min
    ax.set_ylim(y_min , y_max + 0.1 * y_range)
    #--
    #write_log_append(f'儲存 {PNG_Profile_Name} 圖片...')
    #Output_PNG_FileName = 'ABCD.png'
    if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
        os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
    plt.tight_layout() 
    plt.savefig(Output_PNG_FileName, dpi=PNG_DPI)
    plt.close()
    #write_log_append(f'儲存 {PNG_Profile_Name} 圖片...完成!')
    #==============================================================================
    #==============================================================================
    # Pygimli網格繪圖:  繪製研究區域網格逆推剖面(電阻率、電極位置、逆推資訊) 有coverage 無網格 自訂colorbar #C3
    #--    
    # 可填入的資訊
    PNG_Profile_Name = Main_FileName
    PNG_NumPy_Electrode_x = LastInversion_Data.sensors().array()[:, 0]
    PNG_NumPy_Electrode_y = LastInversion_Data.sensors().array()[:, 1]
    PNG_NumPy_Electrode_z = LastInversion_Data.sensors().array()[:, 2]
    PNG_mesh = LastInversion_InversionModelMesh
    PNG_mesh_data = LastInversion_InversionModelMesh['Resistivity_(log10)']
    PNG_mesh_coverage = LastInversion_InversionModelMesh['Coverage']
    PNG_colorbar_title = 'Resistivity (log10 Ωm)'
    PNG_colorbar_ticker_ModifyLog10ToLinear_Enable = True # True = 把colorbar數值文字從對數尺度調整成線性尺度 / False = 維持原本數值
    PNG_colorbar_ticker_ModifyLog10ToLinear_title = 'Resistivity (Ωm)'
    PNG_Main_Title = f"{PNG_Profile_Name} Inverted Resistivity Section with Coverage " + \
        f" (Iteration={Info_Iteration_count})" + \
        f"\nData Count={Info_LastInversion_Obs_dataVals_Count}, " + \
        f"Data EstError={Data_Settings_Relative_Error_Percentage}%, " + \
        f"Remove Runs={Current_Remove_Runs}, " + \
        f"Remove Data={Inversion_Remove_Data_Percentage}%, " + \
        rf"$\lambda${Current_lambda_number}={Info_LastInversion_Lambda:.2f}, " + \
        f"limits=[{Inversion_limitModelCellMinValue:.2f},{Inversion_limitModelCellMaxValue:.2f}]Ωm, " + \
        f"RRMS={Info_LastInversion_RRMS:.2f}%, " + \
        rf"$\chi^2$={Info_LastInversion_chi2:.2f}"                 
    PNG_mesh_showMesh = False # True / False
    PNG_mesh_showBoundary = True # None / True / False ，某些時候None與True效果相同
    PNG_cMap = 'jet'
    PNG_cMin = np.log10(temp_json_data['Output_Inversion_ColorBarResistivityMin']) # None表示自動
    PNG_cMax = np.log10(temp_json_data['Output_Inversion_ColorBarResistivityMax']) # None表示自動
    PNG_DPI = 100
    PNG_Width = 1280
    PNG_Height = 720    
    Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_R{Current_Remove_Runs:02d}_L{Current_lambda_number:02d}_I{Info_Iteration_count:02d}_INVC3.png')
    #--
    # 建立畫布
    fig, ax = plt.subplots(figsize=((PNG_Width / PNG_DPI, PNG_Height / PNG_DPI)))
    # 繪製網格
    ax, cbar = pg.show(PNG_mesh, 
        data=PNG_mesh_data, 
        coverage=PNG_mesh_coverage,
        ax=ax,
        markers=False,
        showMesh=PNG_mesh_showMesh,
        showBoundary=PNG_mesh_showBoundary,  
        label=PNG_colorbar_title,     # colorbar的標題。
        axisLabels=False,             # 阻止自動標籤(否則特定條件下會把Y軸轉換成深度)。後面自行填入標籤。
        cMap=PNG_cMap,
        cMin=PNG_cMin,
        cMax=PNG_cMax)
    # 繪製電極
    ax.plot(PNG_NumPy_Electrode_x[Good_Electrode_Index_0Base], PNG_NumPy_Electrode_y[Good_Electrode_Index_0Base], 'o', markersize=6, color='magenta', markerfacecolor='magenta', markeredgecolor='black', label='Electrode Nodes')    
    if len(Bad_Electrode_Index_0Base) >0 :
        ax.plot(PNG_NumPy_Electrode_x[Bad_Electrode_Index_0Base], PNG_NumPy_Electrode_y[Bad_Electrode_Index_0Base], 'o', markersize=6, color='magenta', markerfacecolor='lightgray', markeredgecolor='black', label='Skipped Electrode Nodes')
    ax.set_title(PNG_Main_Title, pad=3)  
    # 調整XY標籤
    ax.set_xlabel('Distance (m)')
    ax.set_ylabel('Elevation (m)')
    # 調整圖例
    ax.legend(loc='upper right',ncol=2,framealpha=0.4)
    # 調整colorbar內文字
    if PNG_colorbar_ticker_ModifyLog10ToLinear_Enable:
        cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.FuncFormatter(lambda x, pos: f'{10**x:.1f}'.rstrip('0').rstrip('.')))    
        cbar.ax.xaxis.get_offset_text().set_visible(False) # 避免顯示 1eX
        cbar.set_label(PNG_colorbar_ticker_ModifyLog10ToLinear_title) # 使用你設定的 Ωm 標題
    else:
        cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.ScalarFormatter(useMathText=False))
        cbar.ax.xaxis.get_major_formatter().set_useOffset(False) #禁用「偏移量 (Offset)」模式
        cbar.ax.xaxis.get_offset_text().set_visible(False)  # 避免顯示 1eX
    #--
    # 填入版本資訊
    fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
    # 調整邊界
    x_min, x_max = ax.get_xlim()
    y_min, y_max = ax.get_ylim()
    x_range = x_max - x_min
    y_range = y_max - y_min
    ax.set_ylim(y_min , y_max + 0.1 * y_range)
    #--
    #write_log_append(f'儲存 {PNG_Profile_Name} 圖片...')
    #Output_PNG_FileName = 'ABCD.png'
    if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
        os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
    plt.tight_layout() 
    plt.savefig(Output_PNG_FileName, dpi=PNG_DPI)
    plt.close()
    #write_log_append(f'儲存 {PNG_Profile_Name} 圖片...完成!')
    #==============================================================================
    if temp_json_data["Output_Inversion_XMinMax_Enable"] == 'Yes' :
        #==============================================================================
        # Pygimli網格繪圖:  繪製研究區域網格逆推剖面(電阻率、電極位置、逆推資訊) 有coverage 無網格 自訂colorbar #C3
        #--    
        # 可填入的資訊
        PNG_Profile_Name = Main_FileName
        PNG_NumPy_Electrode_x = LastInversion_Data.sensors().array()[:, 0]
        PNG_NumPy_Electrode_y = LastInversion_Data.sensors().array()[:, 1]
        PNG_NumPy_Electrode_z = LastInversion_Data.sensors().array()[:, 2]
        PNG_mesh = LastInversion_InversionModelMesh
        PNG_mesh_data = LastInversion_InversionModelMesh['Resistivity_(log10)']
        PNG_mesh_coverage = LastInversion_InversionModelMesh['Coverage']
        PNG_colorbar_title = 'Resistivity (log10 Ωm)'
        PNG_colorbar_ticker_ModifyLog10ToLinear_Enable = True # True = 把colorbar數值文字從對數尺度調整成線性尺度 / False = 維持原本數值
        PNG_colorbar_ticker_ModifyLog10ToLinear_title = 'Resistivity (Ωm)'
        PNG_Main_Title = f"{PNG_Profile_Name} Inverted Resistivity Section with Coverage " + \
            f" (Iteration={Info_Iteration_count})" + \
            f"\nData Count={Info_LastInversion_Obs_dataVals_Count}, " + \
            f"Data EstError={Data_Settings_Relative_Error_Percentage}%, " + \
            f"Remove Runs={Current_Remove_Runs}, " + \
            f"Remove Data={Inversion_Remove_Data_Percentage}%, " + \
            rf"$\lambda${Current_lambda_number}={Info_LastInversion_Lambda:.2f}, " + \
            f"limits=[{Inversion_limitModelCellMinValue:.2f},{Inversion_limitModelCellMaxValue:.2f}]Ωm, " + \
            f"RRMS={Info_LastInversion_RRMS:.2f}%, " + \
            rf"$\chi^2$={Info_LastInversion_chi2:.2f}"                 
        PNG_mesh_showMesh = False # True / False
        PNG_mesh_showBoundary = True # None / True / False ，某些時候None與True效果相同
        PNG_cMap = 'jet'
        PNG_cMin = np.log10(temp_json_data['Output_Inversion_ColorBarResistivityMin']) # None表示自動
        PNG_cMax = np.log10(temp_json_data['Output_Inversion_ColorBarResistivityMax']) # None表示自動
        PNG_DPI = 100
        PNG_Width = 1280
        PNG_Height = 720    
        Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_R{Current_Remove_Runs:02d}_L{Current_lambda_number:02d}_I{Info_Iteration_count:02d}_INVC3a.png')
        #--
        # 建立畫布
        fig, ax = plt.subplots(figsize=((PNG_Width / PNG_DPI, PNG_Height / PNG_DPI)))
        # 繪製網格
        ax, cbar = pg.show(PNG_mesh, 
            data=PNG_mesh_data, 
            coverage=PNG_mesh_coverage,
            ax=ax,
            markers=False,
            showMesh=PNG_mesh_showMesh,
            showBoundary=PNG_mesh_showBoundary,  
            label=PNG_colorbar_title,     # colorbar的標題。
            axisLabels=False,             # 阻止自動標籤(否則特定條件下會把Y軸轉換成深度)。後面自行填入標籤。
            cMap=PNG_cMap,
            cMin=PNG_cMin,
            cMax=PNG_cMax)
        # 繪製電極
        ax.plot(PNG_NumPy_Electrode_x[Good_Electrode_Index_0Base], PNG_NumPy_Electrode_y[Good_Electrode_Index_0Base], 'o', markersize=6, color='magenta', markerfacecolor='magenta', markeredgecolor='black', label='Electrode Nodes')    
        if len(Bad_Electrode_Index_0Base) >0 :
            ax.plot(PNG_NumPy_Electrode_x[Bad_Electrode_Index_0Base], PNG_NumPy_Electrode_y[Bad_Electrode_Index_0Base], 'o', markersize=6, color='magenta', markerfacecolor='lightgray', markeredgecolor='black', label='Skipped Electrode Nodes')
        ax.set_title(PNG_Main_Title, pad=3)  
        # 調整XY標籤
        ax.set_xlabel('Distance (m)')
        ax.set_ylabel('Elevation (m)')
        # 調整圖例
        ax.legend(loc='upper right',ncol=2,framealpha=0.4)
        # 調整colorbar內文字
        if PNG_colorbar_ticker_ModifyLog10ToLinear_Enable:
            cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.FuncFormatter(lambda x, pos: f'{10**x:.1f}'.rstrip('0').rstrip('.')))    
            cbar.ax.xaxis.get_offset_text().set_visible(False) # 避免顯示 1eX
            cbar.set_label(PNG_colorbar_ticker_ModifyLog10ToLinear_title) # 使用你設定的 Ωm 標題
        else:
            cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.ScalarFormatter(useMathText=False))
            cbar.ax.xaxis.get_major_formatter().set_useOffset(False) #禁用「偏移量 (Offset)」模式
            cbar.ax.xaxis.get_offset_text().set_visible(False)  # 避免顯示 1eX
        #--
        # 填入版本資訊
        fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
        # 調整邊界
        x_min, x_max = ax.get_xlim()
        y_min, y_max = ax.get_ylim()
        x_range = x_max - x_min
        y_range = y_max - y_min    
        #--
        # 依照參數設定繪製範圍
        ax.set_xlim(temp_json_data['Output_Inversion_XMin'] , temp_json_data['Output_Inversion_XMax'])
        ax.set_ylim(temp_json_data['Output_Inversion_YMin'] , temp_json_data['Output_Inversion_YMax'])
        #--
        #write_log_append(f'儲存 {PNG_Profile_Name} 圖片...')
        #Output_PNG_FileName = 'ABCD.png'
        if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
            os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
        plt.tight_layout() 
        plt.savefig(Output_PNG_FileName, dpi=PNG_DPI)
        plt.close()
        #write_log_append(f'儲存 {PNG_Profile_Name} 圖片...完成!')
        #==============================================================================
    #==============================================================================
    # 繪圖 AppRes Obs
    #--    
    # 可填入的資訊 
    PNG_Profile_Name = Main_FileName
    PNG_colorbar_title = 'Apparent Resistivity (log10 Ωm)'
    PNG_Obs_AppRes=np.log10(Info_LastInversion_Obs_dataVals)
    PNG_colorbar_ticker_ModifyLog10ToLinear_Enable = True # True = 把colorbar數值文字從對數尺度調整成線性尺度 / False = 維持原本數值
    PNG_colorbar_ticker_ModifyLog10ToLinear_title = 'Apparent Resistivity (Ωm)'
    PNG_Main_Title = f"{PNG_Profile_Name} Observed Data Apparent Resistivity Distribution " + \
        f" (Iteration={Info_Iteration_count})" + \
        f"\nData Count={Info_LastInversion_Obs_dataVals_Count}, " + \
        f"Data EstError={Data_Settings_Relative_Error_Percentage}%, " + \
        f"Remove Runs={Current_Remove_Runs}, " + \
        f"Remove Data={Inversion_Remove_Data_Percentage}%, " + \
        rf"$\lambda${Current_lambda_number}={Info_LastInversion_Lambda:.2f}, " + \
        f"limits=[{Inversion_limitModelCellMinValue:.2f},{Inversion_limitModelCellMaxValue:.2f}]Ωm, " + \
        f"RRMS={Info_LastInversion_RRMS:.2f}%, " + \
        rf"$\chi^2$={Info_LastInversion_chi2:.2f}" 
    PNG_DPI = 100
    PNG_Width = 1280
    PNG_Height = 720    
    Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_R{Current_Remove_Runs:02d}_L{Current_lambda_number:02d}_I{Info_Iteration_count:02d}_DataObs.png')
    #--
    # 建立畫布
    fig, ax = plt.subplots(figsize=((PNG_Width / PNG_DPI, PNG_Height / PNG_DPI)))
    # 使用 ert.show() 來顯示資料，並自動決定色階範圍
    ax, cbar = ert.show(
          Ohm_data,                    # 必須的參數：DataContainerERT 物件
          vals=PNG_Obs_AppRes,       # 要繪製的數據
          ax=ax,                       # 指定畫在剛才建立的 ax 上
          label=PNG_colorbar_title,                  # colorbar的標題，不填就自動產生Apparent resistivity (Ωm)。
          xlabel=None,                 # 預設值：x 軸標籤
          ylabel=None                  # 預設值：y 軸標籤
      )
    # 
    ax.set_title(PNG_Main_Title, pad=3) 
    ax.set_xlabel("")
    # 調整colorbar內文字
    if PNG_colorbar_ticker_ModifyLog10ToLinear_Enable:
        cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.FuncFormatter(lambda x, pos: f'{10**x:.1f}'.rstrip('0').rstrip('.')))    
        cbar.ax.xaxis.get_offset_text().set_visible(False) # 避免顯示 1eX
        cbar.set_label(PNG_colorbar_ticker_ModifyLog10ToLinear_title) # 使用你設定的 Ωm 標題
    else:
        cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.ScalarFormatter(useMathText=False))
        cbar.ax.xaxis.get_major_formatter().set_useOffset(False) #禁用「偏移量 (Offset)」模式
        cbar.ax.xaxis.get_offset_text().set_visible(False)  # 避免顯示 1eX
    #--
    # 填入版本資訊
    fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
    #--
    #write_log_append(f'儲存 {PNG_Profile_Name} 圖片...')
    if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
        os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
    plt.tight_layout() 
    plt.savefig(Output_PNG_FileName, dpi=PNG_DPI)
    plt.close()
    #write_log_append(f'儲存 {PNG_Profile_Name} 圖片...完成!')
    #==============================================================================
    #==============================================================================
    # 繪圖 AppRes Cal
    #--    
    # 可填入的資訊 
    PNG_Profile_Name = Main_FileName
    PNG_colorbar_title = 'Apparent Resistivity (log10 Ωm)'
    PNG_Cal_AppRes=np.log10(Info_LastInversion_response_dataVals)
    PNG_colorbar_ticker_ModifyLog10ToLinear_Enable = True # True = 把colorbar數值文字從對數尺度調整成線性尺度 / False = 維持原本數值
    PNG_colorbar_ticker_ModifyLog10ToLinear_title = 'Apparent Resistivity (Ωm)'
    PNG_Main_Title = f"{PNG_Profile_Name} Predicted Data Apparent Resistivity Distribution " + \
        f" (Iteration={Info_Iteration_count})" + \
        f"\nData Count={Info_LastInversion_Obs_dataVals_Count}, " + \
        f"Data EstError={Data_Settings_Relative_Error_Percentage}%, " + \
        f"Remove Runs={Current_Remove_Runs}, " + \
        f"Remove Data={Inversion_Remove_Data_Percentage}%, " + \
        rf"$\lambda${Current_lambda_number}={Info_LastInversion_Lambda:.2f}, " + \
        f"limits=[{Inversion_limitModelCellMinValue:.2f},{Inversion_limitModelCellMaxValue:.2f}]Ωm, " + \
        f"RRMS={Info_LastInversion_RRMS:.2f}%, " + \
        rf"$\chi^2$={Info_LastInversion_chi2:.2f}" 
    PNG_DPI = 100
    PNG_Width = 1280
    PNG_Height = 720    
    Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_R{Current_Remove_Runs:02d}_L{Current_lambda_number:02d}_I{Info_Iteration_count:02d}_DataCal.png')
    #--
    # 建立畫布
    fig, ax = plt.subplots(figsize=((PNG_Width / PNG_DPI, PNG_Height / PNG_DPI)))
    # 使用 ert.show() 來顯示資料，並自動決定色階範圍
    ax, cbar = ert.show(
          Ohm_data,                    # 必須的參數：DataContainerERT 物件
          vals=PNG_Cal_AppRes,       # 要繪製的數據
          ax=ax,                       # 指定畫在剛才建立的 ax 上
          label=PNG_colorbar_title,                  # colorbar的標題，不填就自動產生Apparent resistivity (Ωm)。
          xlabel=None,                 # 預設值：x 軸標籤
          ylabel=None                  # 預設值：y 軸標籤
      )
    # 
    ax.set_title(PNG_Main_Title, pad=3) 
    ax.set_xlabel("")
    # 調整colorbar內文字
    if PNG_colorbar_ticker_ModifyLog10ToLinear_Enable:
        cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.FuncFormatter(lambda x, pos: f'{10**x:.1f}'.rstrip('0').rstrip('.')))    
        cbar.ax.xaxis.get_offset_text().set_visible(False) # 避免顯示 1eX
        cbar.set_label(PNG_colorbar_ticker_ModifyLog10ToLinear_title) # 使用你設定的 Ωm 標題
    else:
        cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.ScalarFormatter(useMathText=False))
        cbar.ax.xaxis.get_major_formatter().set_useOffset(False) #禁用「偏移量 (Offset)」模式
        cbar.ax.xaxis.get_offset_text().set_visible(False)  # 避免顯示 1eX
    #--
    # 填入版本資訊
    fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
    #--
    #write_log_append(f'儲存 {PNG_Profile_Name} 圖片...')
    if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
        os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
    plt.tight_layout() 
    plt.savefig(Output_PNG_FileName, dpi=PNG_DPI)
    plt.close()
    #write_log_append(f'儲存 {PNG_Profile_Name} 圖片...完成!')
    #==============================================================================
    #==============================================================================
    # 繪圖 AppRes Misfit
    #--    
    # 可填入的資訊 
    PNG_Profile_Name = Main_FileName
    PNG_colorbar_title = 'Relative Data Misfit (%)'
    PNG_Misfit=(1-(Info_LastInversion_response_dataVals/Info_LastInversion_Obs_dataVals))*100
    PNG_colorbar_ticker_ModifyLog10ToLinear_Enable = False # True = 把colorbar數值文字從對數尺度調整成線性尺度 / False = 維持原本數值
    PNG_colorbar_ticker_ModifyLog10ToLinear_title = 'Relative Data Misfit (%)'
    PNG_Main_Title = f"{PNG_Profile_Name} Relative Data Misfit Distribution " + \
        f" (Iteration={Info_Iteration_count})" + \
        f"\nData Count={Info_LastInversion_Obs_dataVals_Count}, " + \
        f"Data EstError={Data_Settings_Relative_Error_Percentage}%, " + \
        f"Remove Runs={Current_Remove_Runs}, " + \
        f"Remove Data={Inversion_Remove_Data_Percentage}%, " + \
        rf"$\lambda${Current_lambda_number}={Info_LastInversion_Lambda:.2f}, " + \
        f"limits=[{Inversion_limitModelCellMinValue:.2f},{Inversion_limitModelCellMaxValue:.2f}]Ωm, " + \
        f"RRMS={Info_LastInversion_RRMS:.2f}%, " + \
        rf"$\chi^2$={Info_LastInversion_chi2:.2f}" 
    PNG_DPI = 100
    PNG_Width = 1280
    PNG_Height = 720    
    Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_R{Current_Remove_Runs:02d}_L{Current_lambda_number:02d}_I{Info_Iteration_count:02d}_DataRMisfit.png')
    #--
    # 建立畫布
    fig, ax = plt.subplots(figsize=((PNG_Width / PNG_DPI, PNG_Height / PNG_DPI)))
    # 使用 ert.show() 來顯示資料，並自動決定色階範圍
    ax, cbar = ert.show(
          Ohm_data,                    # 必須的參數：DataContainerERT 物件
          vals=PNG_Misfit,       # 要繪製的數據
          ax=ax,                       # 指定畫在剛才建立的 ax 上
          label=PNG_colorbar_title,                  # colorbar的標題，不填就自動產生Apparent resistivity (Ωm)。
          cMin=-np.max(np.abs(PNG_Misfit)),              # 強制對稱範圍
          cMax=np.max(np.abs(PNG_Misfit)),              # 強制對稱範圍
          cMap="bwr",              # 藍白紅配色 (Blue-White-Red)
          xlabel=None,                 # 預設值：x 軸標籤
          ylabel=None                  # 預設值：y 軸標籤
      )
    # 
    ax.set_title(PNG_Main_Title, pad=3) 
    ax.set_xlabel("")
    # 調整colorbar內文字
    if PNG_colorbar_ticker_ModifyLog10ToLinear_Enable:
        cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.FuncFormatter(lambda x, pos: f'{10**x:.1f}'.rstrip('0').rstrip('.')))    
        cbar.ax.xaxis.get_offset_text().set_visible(False) # 避免顯示 1eX
        cbar.set_label(PNG_colorbar_ticker_ModifyLog10ToLinear_title) # 使用你設定的 Ωm 標題
    else:
        cbar.ax.xaxis.set_major_formatter(plt.matplotlib.ticker.ScalarFormatter(useMathText=False))
        cbar.ax.xaxis.get_major_formatter().set_useOffset(False) #禁用「偏移量 (Offset)」模式
        cbar.ax.xaxis.get_offset_text().set_visible(False)  # 避免顯示 1eX
    #--
    # 填入版本資訊
    fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
    #--
    #write_log_append(f'儲存 {PNG_Profile_Name} 圖片...')
    if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
        os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
    plt.tight_layout() 
    plt.savefig(Output_PNG_FileName, dpi=PNG_DPI)
    plt.close()
    #write_log_append(f'儲存 {PNG_Profile_Name} 圖片...完成!')
    #==============================================================================  
    write_log_append("--")
#--------------------------------------------
#--------------------------------------------
# 逆推參數(終止疊代任務相關)
#Default_maxIter = 20 #預設值20，我規定成必填項目。
#Default_dPhi = 2 #預設值2，單位[%]，我規定不允許改變。[終止疊代任務門檻]：定義目標函數最小化的「相對改善率」下限。當疊代效益 < 1% 時，視為模型已達穩定狀態，提前終止逆推，防止對噪聲過度擬合。
# 逆推參數(正則化相關)
#Default_lam = 20 #預設值200，我規定成必填項目。
#Default_lambdaFactor = 1 #預設值1，我規定不允許改變。
#Default_isReference = False #預設值關閉，我規定不允許改變。是否要讓起始模型也同時成為先驗模型。 
# 逆推參數(資料擬合相關)
#Default_robustData = False #預設值關閉，我規定不允許改變。False表示使用一般模式(L2範數)，誤差會被平方，適合資料品質好時可達最佳效果。True表示使用強健模式，誤差會被重新加權，來容忍資料品質不好的離群點多的情況。
#Default_blockyModel = False #預設值關閉，我規定不允許改變。False表示空間格子應該像漸層，True表示空間格子像塊狀。
# 逆推參數
#Default_showProgress = False #預設值關閉，我規定不允許改變。
#Default_verbose = False # 預設值關閉，我規定成必填項目。
#Default_debug = False # 預設值關閉，我規定不允許改變。
# limits=[0, 0] # 預設值是[0, 0]。是線性數值，單位:[Ohm-m]
#--------------------------------------------
# 準備逆推參數
Inversion_Remove_Data_Times = temp_json_data["Inversion_Setting01_Remove_Data_Times"] #建議值 = 3，不想刪資料就設定「0」
Inversion_Remove_Data_Percentage = temp_json_data["Inversion_Setting02_Remove_Data_Percentage"] #建議值 = 5 ，單位:[%]
Inversion_lam_list = temp_json_data["Inversion_Setting03_Lambda"] #預設值20
write_log_append(f"遞減Lambda清單 = {Inversion_lam_list}")
Inversion_lam_list_count = len(Inversion_lam_list) 
write_log_append(f"遞減Lambda清單數量 = {Inversion_lam_list_count}")
write_log_append("--")
Inversion_maxIter = temp_json_data["Inversion_Setting04_maxIter"] #預設值20
if temp_json_data["Inversion_Setting05_startModel"] > 0 :
    Inversion_startModel = temp_json_data["Inversion_Setting05_startModel"] #預設值「None」，None表示使用資料的中位數。
elif temp_json_data["Inversion_Setting05_startModel"] == -2 :    
    #--------------------------------------------
    write_log_append(f"全網格數量={mesh.cellCount()},研究區域網格數量={np.sum(mesh.cellMarkers() == 2)}.")
    write_log_append("使用電阻率欄位設定起始模型電阻率...")
    if mesh.haveData("Resistivity"):
        write_log_append(f'設定起始模型電阻率(Min/Max) = {np.min(mesh["Resistivity"][(mesh.cellMarkers() == 2)])}/{np.max(mesh["Resistivity"][(mesh.cellMarkers() == 2)])}')
        Inversion_startModel = mesh["Resistivity"][(mesh.cellMarkers() == 2)]
    else:
        write_log_append('沒有找到電阻率資訊，改用資料的中位數的均質模型。')
        Inversion_startModel = None #預設值「None」，None表示使用資料的中位數。
    write_log_append("使用電阻率欄位設定起始模型電阻率...完成!")  
elif temp_json_data["Inversion_Setting05_startModel"] == -3 :    
    #--------------------------------------------
    # 建立網格
    temp_mesh = pg.Mesh(2)
    # 使用計算出的節點座標創建網格
    write_log_append("讀取 .vtk 檔...")
    temp_mesh.load(temp_json_data["InputFile05_StudyAreaStartModelVTK_FileName"])
    write_log_append("讀取 .vtk 檔...完成!")
    #--------------------------------------------
    write_log_append(f"全網格數量={mesh.cellCount()},研究區域網格數量={np.sum(mesh.cellMarkers() == 2)}.")
    write_log_append(f"起始模型網格數量={temp_mesh.cellCount()}.")
    if temp_mesh.cellCount() == np.sum(mesh.cellMarkers() == 2) :
        write_log_append("起始模型網格數量與研究區域網格數量相等!")
        write_log_append("使用電阻率欄位設定起始模型電阻率...")
        if temp_mesh.haveData("Resistivity"):
            write_log_append(f'設定起始模型電阻率(Min/Max) = {np.min(temp_mesh["Resistivity"])}/{np.max(temp_mesh["Resistivity"])}')
            Inversion_startModel = temp_mesh["Resistivity"]
        else:
            write_log_append('沒有找到電阻率資訊，改用資料的中位數的均質模型。')
            Inversion_startModel = None #預設值「None」，None表示使用資料的中位數。
        write_log_append("使用電阻率欄位設定起始模型電阻率...完成!")    
else:
    Inversion_startModel = None #預設值「None」，None表示使用資料的中位數。
if temp_json_data["Inversion_Setting06_verbose_Enable"] == 'Yes' :
    Inversion_verbose = True #預設值關閉「False」，要開啟填「True」。
else:
    Inversion_verbose = False #預設值關閉「False」，要開啟填「True」。
Inversion_limitModelCellMinValue = temp_json_data["Inversion_Setting07_limitModelCellMinValue"] #預設值0
Inversion_limitModelCellMaxValue = temp_json_data["Inversion_Setting08_limitModelCellMaxValue"] #預設值0
if Inversion_limitModelCellMinValue >= Inversion_limitModelCellMaxValue:
    Inversion_limitModelCellMinValue = 0
    Inversion_limitModelCellMaxValue = 0
if temp_json_data["Inversion_Setting09_SR_Enable"] == 'Yes' :
    Inversion_SR = True #預設值開啟「True」，要關閉填「False」。
else:
    Inversion_SR = False #預設值開啟「True」，要關閉填「False」。
#--
# 輸出逆推紀錄檔案 (檔頭部分)
Output_Inversion_Log = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_03_Inversion_Log.csv')
#write_log_append('儲存CSV檔案...')
with open(Output_Inversion_Log, 'w', encoding='utf-8') as f:
    #--
    # 前方固定內容
    line = 'Main_FileName,SR,GeometricFactorByMesh,Remove_Runs,Remove_Data[%],Iteration,Max_Iteration,' + \
    'StartModel_Cell_Count,StartModel_Cell_Value_Min[Ohm-m],StartModel_Cell_Value_Max[Ohm-m],' + \
    'LimitModel_Cell_Value_Min[Ohm-m],LimitModel_Cell_Value_Max[Ohm-m],' + \
    'ForwardH2Model_Cell_Count,ForwardH2Model_Cell_Value_Min[Ohm-m],ForwardH2Model_Cell_Value_Max[Ohm-m],' + \
    'InversionModel_Cell_Count,InversionModel_Cell_Value_Min[Ohm-m],InversionModel_Cell_Value_Max[Ohm-m],' + \
    'Obs_Data_Count,Obs_Data_Value_Min[Ohm-m],Obs_Data_Value_Max[Ohm-m],' + \
    'Obs_Data_Relative_Error_Min[%],Obs_Data_Relative_Error_Max[%],' + \
    'Cal_Data_Value_Min[Ohm-m],Cal_Data_Value_Max[Ohm-m],' + \
    'Relative_Misfit_Min[%],Relative_Misfit_Mean[%],Relative_Misfit_Max[%],' + \
    'Lambda_Index,Lambda,RMS,RRMS[%],Chi2,Phi,PhiD,PhiM\n'    
    f.write(line)
    #--
#write_log_append('儲存CSV檔案...完成!')
#--
write_log_append("用data建立ERTManager物件...")
mgr = ert.ERTManager(Ohm_data, sr=Inversion_SR)    
write_log_append("建立ERTManager物件...完成")
#--
write_log_append("使用管理器設定PostStep...")
# 告訴反演器：每次迭代結束，就去執行一次「Inversion_Info_Update」
mgr.inv.setPostStep(Inversion_Info_Update)
write_log_append("使用管理器設定PostStep...完成!")
#--
write_log_append("**使用管理器運行逆推...")
#--
if temp_json_data["Inversion_Setting00_getOptimizeLambda_Enable"] == 'Yes' :
    #--
    # 第0次(沒刪除資料)
    Current_Remove_Runs = 0
    write_log_append(f'逆推進度({Current_Remove_Runs}/{Inversion_Remove_Data_Times})...')
    Continue_Inversion_startModel = Inversion_startModel
    for lambda_index in range(1):
        Current_lambda_number =  lambda_index + 1
        write_log_append(f"使用自動lam進行逆推...")
        Inversion_lam = temp_json_data["Inversion_Setting00_getOptimizeLambda_StartingLambda"]
        Inversion_maxIter = 1
        if lambda_index == 0 :
            write_log_append("沒有可接關的模型，用參數決定的起始模型!")
            mgr.inv.inv.setOptimizeLambda(True)
            mgr.invert(Ohm_data,mesh=mesh, lam=Inversion_lam, maxIter=Inversion_maxIter, startModel=Inversion_startModel, verbose=Inversion_verbose, limits=[Inversion_limitModelCellMinValue, Inversion_limitModelCellMaxValue])
        else :
            write_log_append("有可接關的模型，採用此模型作為起始模型!")
            mgr.invert(Ohm_data,mesh=mesh, lam=Inversion_lam, maxIter=Inversion_maxIter, startModel=Continue_Inversion_startModel, verbose=Inversion_verbose, limits=[Inversion_limitModelCellMinValue, Inversion_limitModelCellMaxValue])
        write_log_append(f"使用自動lam進行逆推...完成!")
        write_log_append('更新一個「接關的起始模型」...')
        Continue_Inversion_startModel = mgr.inv.model
        write_log_append('更新一個「接關的起始模型」...完成')
        #--
        Output_Inversion_Log = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_03_Inversion_Log.csv')
        write_log_append('載入 Output_Inversion_Log 檔案...')
        try:
            #--------------------------------------------
            # 使用 np.loadtxt 載入 CSV 檔案 並強制所有內容為字串 (不含標頭)
            # dtype='str' 或 dtype=object：強制 NumPy 將每個單元格視為字串。
            # delimiter=','：指定逗號分隔。
            # skiprows=1：跳過標頭行。
            Inversion_Log_Matrix = np.loadtxt(
                Output_Inversion_Log, 
                dtype='str',
                delimiter=',', 
                skiprows=1,
                encoding='utf-8'
            )    
            #--------------------------------------------
            # 獨立載入標頭
            # 讀取整個檔案的第一行
            with open(Output_Inversion_Log, 'r', encoding='utf-8') as f:
                header_line = f.readline().strip()
            Inversion_Log_DataHeader = header_line.split(',')
            #--------------------------------------------
        except FileNotFoundError:
            write_log_append(f"錯誤：找不到檔案 {Input_v299Scsv_FileName}")
            exit(1) # 回傳1表示一般性錯誤
        except Exception as e:
            write_log_append(f"程式運行時發生錯誤: {e}")
            exit(1) # 回傳1表示一般性錯誤
        #--
        # 強制確保 Inversion_Log_Matrix 是 numpy 陣列
        Inversion_Log_Matrix = np.array(Inversion_Log_Matrix)
        # 如果只有一列數據導致維度變成 (N,)，將其轉回 (1, N) 或 (M, N)
        if Inversion_Log_Matrix.ndim == 1:
            Inversion_Log_Matrix = Inversion_Log_Matrix.reshape(1, -1)    
        write_log_append('載入 Output_Inversion_Log 檔案...完成!')
        #--
        # 目標函數下降比例: dPhi = current_Phi / last_Phi
        phi_list = Inversion_Log_Matrix[:, Inversion_Log_DataHeader.index('Phi')].astype(float)
        # current_phi = phi_list[-1]
        # last_phi = phi_list[-2]
        remove_runs_list = Inversion_Log_Matrix[:, Inversion_Log_DataHeader.index('Remove_Runs')]
        remove_data_list = Inversion_Log_Matrix[:, Inversion_Log_DataHeader.index('Remove_Data[%]')]
        iteration_list = Inversion_Log_Matrix[:, Inversion_Log_DataHeader.index('Iteration')]
        if Inversion_Log_Matrix.shape[0] < 2:
            # 如果只有一維，代表只有一筆紀錄，dPhi 無法計算 (設定為預設值) 代表當前目標函數與上一次完全一樣，能量下降率為 0%
            dPhi = 1.0 
        else:
            # 正常計算
            dPhi = phi_list[-1] / phi_list[-2]
        #--
        # 輸出停止原因檔案 
        Output_Inversion_Log = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_03_Inversion_Log.csv')+'.stop'
        if lambda_index == 0 :
            file_mode = 'w'
        else :
            file_mode = 'a'
        with open(Output_Inversion_Log, file_mode, encoding='utf-8') as f:
            #--
            if (dPhi > (1.0 - mgr.inv.minDPhi / 100.0)) and mgr.inv.iter >= 2:
                line=(f"Remove_Runs#{remove_runs_list[-1]}({remove_data_list[-1]}%),Iteration#{iteration_list[-1]}，運行結束原因: 已達到中止準則「dPhi({(1-dPhi)*100:.2f}%) < minDPhi({mgr.inv.minDPhi}%)」。")
            if mgr.inv.chi2() <= 1 and mgr.inv.stopAtChi1:
                line=(f"Remove_Runs#{remove_runs_list[-1]}({remove_data_list[-1]}%),Iteration#{iteration_list[-1]}，運行結束原因: 已達到中止準則「chi² <= 1」。目前 chi² = {mgr.inv.chi2():.2f}。")
            if mgr.inv.iter == Inversion_maxIter:
                line=(f"Remove_Runs#{remove_runs_list[-1]}({remove_data_list[-1]}%),Iteration#{iteration_list[-1]}，運行結束原因: 已達到設定的最大迭帶次數「iter == maxIter」。目前 iter = {mgr.inv.iter}。")   
            write_log_append(line)
            f.write(line+"\n")
        #--
        #--------------------------------------------
        # 取得運行結束時間
        program_end_time = datetime.now()
        # 計算時間差 (timedelta)
        time_difference = program_end_time - program_start_time
        total_seconds = time_difference.total_seconds()
        hours = int(total_seconds // 3600)
        minutes = int((total_seconds % 3600) // 60)
        seconds = int(total_seconds % 60)
        milliseconds = int((total_seconds % 1) * 1000)
        #write_log_append(f"程式結束運行...時間: {program_end_time.strftime('%Y-%m-%d %H:%M:%S')}")
        write_log_append(f"花費時間: {hours:02d}時 {minutes:02d}分 {seconds:02d}.{milliseconds:03d}秒")
        write_log_append('--')
        # 輸出花費時間檔案 
        Output_Inversion_Log = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_03_Inversion_Log.csv')+'.time'
        #write_log_append('儲存time檔案...')
        if lambda_index == 0 :
            file_mode = 'w'
        else :
            file_mode = 'a'
        with open(Output_Inversion_Log, file_mode, encoding='utf-8') as f:
            #--
            line = f"花費時間: {hours:02d}時 {minutes:02d}分 {seconds:02d}.{milliseconds:03d}秒"  
            f.write(line+"\n")
            #--
        #write_log_append('儲存time檔案...完成!')
        #--
        #--------------------------------------------
    write_log_append(f'逆推進度({Current_Remove_Runs}/{Inversion_Remove_Data_Times})...完成!')
    #--
else:
    #--
    # 第0次(沒刪除資料)
    Current_Remove_Runs = 0
    write_log_append(f'逆推進度({Current_Remove_Runs}/{Inversion_Remove_Data_Times})...')
    Continue_Inversion_startModel = Inversion_startModel
    for lambda_index in range(Inversion_lam_list_count):
        Current_lambda_number =  lambda_index + 1
        write_log_append(f"使用第{Current_lambda_number}個lam進行逆推(lam={Inversion_lam_list[lambda_index]})...")
        Inversion_lam = Inversion_lam_list[lambda_index]
        if lambda_index == 0 :
            write_log_append("沒有可接關的模型，用參數決定的起始模型!")
            mgr.invert(Ohm_data,mesh=mesh, lam=Inversion_lam, maxIter=Inversion_maxIter, startModel=Inversion_startModel, verbose=Inversion_verbose, limits=[Inversion_limitModelCellMinValue, Inversion_limitModelCellMaxValue])
        else :
            write_log_append("有可接關的模型，採用此模型作為起始模型!")
            mgr.invert(Ohm_data,mesh=mesh, lam=Inversion_lam, maxIter=Inversion_maxIter, startModel=Continue_Inversion_startModel, verbose=Inversion_verbose, limits=[Inversion_limitModelCellMinValue, Inversion_limitModelCellMaxValue])
        write_log_append(f"使用第{lambda_index+1}個lam進行逆推(lam={Inversion_lam_list[lambda_index]})...完成!")
        write_log_append('更新一個「接關的起始模型」...')
        Continue_Inversion_startModel = mgr.inv.model
        write_log_append('更新一個「接關的起始模型」...完成')
        #--
        Output_Inversion_Log = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_03_Inversion_Log.csv')
        write_log_append('載入 Output_Inversion_Log 檔案...')
        try:
            #--------------------------------------------
            # 使用 np.loadtxt 載入 CSV 檔案 並強制所有內容為字串 (不含標頭)
            # dtype='str' 或 dtype=object：強制 NumPy 將每個單元格視為字串。
            # delimiter=','：指定逗號分隔。
            # skiprows=1：跳過標頭行。
            Inversion_Log_Matrix = np.loadtxt(
                Output_Inversion_Log, 
                dtype='str',
                delimiter=',', 
                skiprows=1,
                encoding='utf-8'
            )    
            #--------------------------------------------
            # 獨立載入標頭
            # 讀取整個檔案的第一行
            with open(Output_Inversion_Log, 'r', encoding='utf-8') as f:
                header_line = f.readline().strip()
            Inversion_Log_DataHeader = header_line.split(',')
            #--------------------------------------------
        except FileNotFoundError:
            write_log_append(f"錯誤：找不到檔案 {Input_v299Scsv_FileName}")
            exit(1) # 回傳1表示一般性錯誤
        except Exception as e:
            write_log_append(f"程式運行時發生錯誤: {e}")
            exit(1) # 回傳1表示一般性錯誤
        #--
        # 強制確保 Inversion_Log_Matrix 是 numpy 陣列
        Inversion_Log_Matrix = np.array(Inversion_Log_Matrix)
        # 如果只有一列數據導致維度變成 (N,)，將其轉回 (1, N) 或 (M, N)
        if Inversion_Log_Matrix.ndim == 1:
            Inversion_Log_Matrix = Inversion_Log_Matrix.reshape(1, -1)    
        write_log_append('載入 Output_Inversion_Log 檔案...完成!')
        #--
        # 目標函數下降比例: dPhi = current_Phi / last_Phi
        phi_list = Inversion_Log_Matrix[:, Inversion_Log_DataHeader.index('Phi')].astype(float)
        # current_phi = phi_list[-1]
        # last_phi = phi_list[-2]
        remove_runs_list = Inversion_Log_Matrix[:, Inversion_Log_DataHeader.index('Remove_Runs')]
        remove_data_list = Inversion_Log_Matrix[:, Inversion_Log_DataHeader.index('Remove_Data[%]')]
        iteration_list = Inversion_Log_Matrix[:, Inversion_Log_DataHeader.index('Iteration')]
        if Inversion_Log_Matrix.shape[0] < 2:
            # 如果只有一維，代表只有一筆紀錄，dPhi 無法計算 (設定為預設值) 代表當前目標函數與上一次完全一樣，能量下降率為 0%
            dPhi = 1.0 
        else:
            # 正常計算
            dPhi = phi_list[-1] / phi_list[-2]
        #--
        # 輸出停止原因檔案 
        Output_Inversion_Log = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_03_Inversion_Log.csv')+'.stop'
        if lambda_index == 0 :
            file_mode = 'w'
        else :
            file_mode = 'a'
        with open(Output_Inversion_Log, file_mode, encoding='utf-8') as f:
            #--
            if (dPhi > (1.0 - mgr.inv.minDPhi / 100.0)) and mgr.inv.iter >= 2:
                line=(f"Remove_Runs#{remove_runs_list[-1]}({remove_data_list[-1]}%),Iteration#{iteration_list[-1]}，運行結束原因: 已達到中止準則「dPhi({(1-dPhi)*100:.2f}%) < minDPhi({mgr.inv.minDPhi}%)」。")
            if mgr.inv.chi2() <= 1 and mgr.inv.stopAtChi1:
                line=(f"Remove_Runs#{remove_runs_list[-1]}({remove_data_list[-1]}%),Iteration#{iteration_list[-1]}，運行結束原因: 已達到中止準則「chi² <= 1」。目前 chi² = {mgr.inv.chi2():.2f}。")
            if mgr.inv.iter == Inversion_maxIter:
                line=(f"Remove_Runs#{remove_runs_list[-1]}({remove_data_list[-1]}%),Iteration#{iteration_list[-1]}，運行結束原因: 已達到設定的最大迭帶次數「iter == maxIter」。目前 iter = {mgr.inv.iter}。")   
            write_log_append(line)
            f.write(line+"\n")
        #--
        #--------------------------------------------
        # 取得運行結束時間
        program_end_time = datetime.now()
        # 計算時間差 (timedelta)
        time_difference = program_end_time - program_start_time
        total_seconds = time_difference.total_seconds()
        hours = int(total_seconds // 3600)
        minutes = int((total_seconds % 3600) // 60)
        seconds = int(total_seconds % 60)
        milliseconds = int((total_seconds % 1) * 1000)
        #write_log_append(f"程式結束運行...時間: {program_end_time.strftime('%Y-%m-%d %H:%M:%S')}")
        write_log_append(f"花費時間: {hours:02d}時 {minutes:02d}分 {seconds:02d}.{milliseconds:03d}秒")
        write_log_append('--')
        # 輸出花費時間檔案 
        Output_Inversion_Log = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_03_Inversion_Log.csv')+'.time'
        #write_log_append('儲存time檔案...')
        if lambda_index == 0 :
            file_mode = 'w'
        else :
            file_mode = 'a'
        with open(Output_Inversion_Log, file_mode, encoding='utf-8') as f:
            #--
            line = f"花費時間: {hours:02d}時 {minutes:02d}分 {seconds:02d}.{milliseconds:03d}秒"  
            f.write(line+"\n")
            #--
        #write_log_append('儲存time檔案...完成!')
        #--
        #--------------------------------------------
    write_log_append(f'逆推進度({Current_Remove_Runs}/{Inversion_Remove_Data_Times})...完成!')
    #--
    # 預設方式儲存結果
    Output_saveResult_FolderName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{temp_json_data["Output_MainFileName"]}_R{Current_Remove_Runs:02d}_L{Current_lambda_number:02d}_I{mgr.inv.iter:02d}')
    mgr.saveResult(Output_saveResult_FolderName)
    write_log_append("**使用管理器運行逆推...完成!")
    #--
    write_log_append('--')
    #--
    for i in range(Inversion_Remove_Data_Times):
        #第i次刪除資料
        Current_Remove_Runs = Current_Remove_Runs + 1     
        #--
        # 1. 刪除資料
        #--
        # 計算要刪除的資料數量
        temp_All_Data_Count = len(Ohm_data['rhoa'])
        temp_Remove_Data_Count = int(np.round(temp_All_Data_Count * Inversion_Remove_Data_Percentage /100 ))
        temp_LastInversion_Relative_Misfit_Percentage = np.abs((mgr.inv.response - mgr.inv.dataVals) / mgr.inv.dataVals) * 100
        # 取得 misfit 最大的索引
        temp_worst_indices = np.argsort(temp_LastInversion_Relative_Misfit_Percentage)[-temp_Remove_Data_Count:]
        # 轉換成要刪除的遮罩
        temp_remove_mask = np.zeros(temp_All_Data_Count, dtype=bool)
        temp_remove_mask[temp_worst_indices] = True    
        # 執行刪除
        write_log_append(f"刪除之前的觀測資料數量: {Ohm_data_All_count}")
        Ohm_data.remove(temp_remove_mask)
        Ohm_data_Accept_count = Ohm_data.size()
        write_log_append(f"刪除之後的觀測資料數量: {Ohm_data_Accept_count}")    
        write_log_append(f'已刪除 {temp_Remove_Data_Count} 筆資料 (約 {Inversion_Remove_Data_Percentage}%)')
        #--
        # 2. 重新運行逆推
        #--
        write_log_append("用data建立ERTManager物件...")
        mgr = ert.ERTManager(Ohm_data, sr=Inversion_SR)    
        write_log_append("建立ERTManager物件...完成")
        #--
        write_log_append("使用管理器設定PostStep...")
        # 告訴反演器：每次迭代結束，就去執行一次「Inversion_Info_Update」
        mgr.inv.setPostStep(Inversion_Info_Update)
        write_log_append("使用管理器設定PostStep...完成!")
        #--
        write_log_append("**使用管理器運行逆推...")
        #--
        write_log_append(f'逆推進度({Current_Remove_Runs}/{Inversion_Remove_Data_Times})...')
        Continue_Inversion_startModel = Inversion_startModel
        for lambda_index in range(Inversion_lam_list_count):
            Current_lambda_number =  lambda_index + 1
            write_log_append(f"使用第{Current_lambda_number}個lam進行逆推(lam={Inversion_lam_list[lambda_index]})...")
            Inversion_lam = Inversion_lam_list[lambda_index]
            if lambda_index == 0 :
                write_log_append("沒有可接關的模型，用參數決定的起始模型!")
                mgr.invert(Ohm_data,mesh=mesh, lam=Inversion_lam, maxIter=Inversion_maxIter, startModel=Inversion_startModel, verbose=Inversion_verbose, limits=[Inversion_limitModelCellMinValue, Inversion_limitModelCellMaxValue])
            else :
                write_log_append("有可接關的模型，採用此模型作為起始模型!")
                mgr.invert(Ohm_data,mesh=mesh, lam=Inversion_lam, maxIter=Inversion_maxIter, startModel=Continue_Inversion_startModel, verbose=Inversion_verbose, limits=[Inversion_limitModelCellMinValue, Inversion_limitModelCellMaxValue])
            write_log_append(f"使用第{lambda_index+1}個lam進行逆推(lam={Inversion_lam_list[lambda_index]})...完成!")
            write_log_append('更新一個「接關的起始模型」...')
            Continue_Inversion_startModel = mgr.inv.model
            write_log_append('更新一個「接關的起始模型」...完成')
            #--
            Output_Inversion_Log = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_03_Inversion_Log.csv')
            write_log_append('載入 Output_Inversion_Log 檔案...')
            try:
                #--------------------------------------------
                # 使用 np.loadtxt 載入 CSV 檔案 並強制所有內容為字串 (不含標頭)
                # dtype='str' 或 dtype=object：強制 NumPy 將每個單元格視為字串。
                # delimiter=','：指定逗號分隔。
                # skiprows=1：跳過標頭行。
                Inversion_Log_Matrix = np.loadtxt(
                    Output_Inversion_Log, 
                    dtype='str',
                    delimiter=',', 
                    skiprows=1,
                    encoding='utf-8'
                )    
                #--------------------------------------------
                # 獨立載入標頭
                # 讀取整個檔案的第一行
                with open(Output_Inversion_Log, 'r', encoding='utf-8') as f:
                    header_line = f.readline().strip()
                Inversion_Log_DataHeader = header_line.split(',')
                #--------------------------------------------
            except FileNotFoundError:
                write_log_append(f"錯誤：找不到檔案 {Input_v299Scsv_FileName}")
                exit(1) # 回傳1表示一般性錯誤
            except Exception as e:
                write_log_append(f"程式運行時發生錯誤: {e}")
                exit(1) # 回傳1表示一般性錯誤
            #--
            # 強制確保 Inversion_Log_Matrix 是 numpy 陣列
            Inversion_Log_Matrix = np.array(Inversion_Log_Matrix)
            # 如果只有一列數據導致維度變成 (N,)，將其轉回 (1, N) 或 (M, N)
            if Inversion_Log_Matrix.ndim == 1:
                Inversion_Log_Matrix = Inversion_Log_Matrix.reshape(1, -1)    
            write_log_append('載入 Output_Inversion_Log 檔案...完成!')
            #--
            # 目標函數下降比例: dPhi = current_Phi / last_Phi
            phi_list = Inversion_Log_Matrix[:, Inversion_Log_DataHeader.index('Phi')].astype(float)
            # current_phi = phi_list[-1]
            # last_phi = phi_list[-2]
            remove_runs_list = Inversion_Log_Matrix[:, Inversion_Log_DataHeader.index('Remove_Runs')]
            remove_data_list = Inversion_Log_Matrix[:, Inversion_Log_DataHeader.index('Remove_Data[%]')]
            iteration_list = Inversion_Log_Matrix[:, Inversion_Log_DataHeader.index('Iteration')]
            if Inversion_Log_Matrix.shape[0] < 2:
                # 如果只有一維，代表只有一筆紀錄，dPhi 無法計算 (設定為預設值) 代表當前目標函數與上一次完全一樣，能量下降率為 0%
                dPhi = 1.0 
            else:
                # 正常計算
                dPhi = phi_list[-1] / phi_list[-2]
            #--
            # 輸出停止原因檔案 
            Output_Inversion_Log = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_03_Inversion_Log.csv')+'.stop'
            if lambda_index == 0 :
                file_mode = 'w'
            else :
                file_mode = 'a'
            with open(Output_Inversion_Log, file_mode, encoding='utf-8') as f:
                #--
                if (dPhi > (1.0 - mgr.inv.minDPhi / 100.0)) and mgr.inv.iter >= 2:
                    line=(f"Remove_Runs#{remove_runs_list[-1]}({remove_data_list[-1]}%),Iteration#{iteration_list[-1]}，運行結束原因: 已達到中止準則「dPhi({(1-dPhi)*100:.2f}%) < minDPhi({mgr.inv.minDPhi}%)」。")
                elif mgr.inv.chi2() <= 1 and mgr.inv.stopAtChi1:
                    line=(f"Remove_Runs#{remove_runs_list[-1]}({remove_data_list[-1]}%),Iteration#{iteration_list[-1]}，運行結束原因: 已達到中止準則「chi² <= 1」。目前 chi² = {mgr.inv.chi2():.2f}。")
                elif mgr.inv.iter == Inversion_maxIter:
                    line=(f"Remove_Runs#{remove_runs_list[-1]}({remove_data_list[-1]}%),Iteration#{iteration_list[-1]}，運行結束原因: 已達到設定的最大迭帶次數「iter == maxIter」。目前 iter = {mgr.inv.iter}。")   
                else: 
                    line=(f"Remove_Runs#{remove_runs_list[-1]}({remove_data_list[-1]}%),Iteration#{iteration_list[-1]}，運行結束原因: ???。目前 iter = {mgr.inv.iter}。")   
                write_log_append(line)
                f.write(line+"\n")
            #--
            #--------------------------------------------
            # 取得運行結束時間
            program_end_time = datetime.now()
            # 計算時間差 (timedelta)
            time_difference = program_end_time - program_start_time
            total_seconds = time_difference.total_seconds()
            hours = int(total_seconds // 3600)
            minutes = int((total_seconds % 3600) // 60)
            seconds = int(total_seconds % 60)
            milliseconds = int((total_seconds % 1) * 1000)
            #write_log_append(f"程式結束運行...時間: {program_end_time.strftime('%Y-%m-%d %H:%M:%S')}")
            write_log_append(f"花費時間: {hours:02d}時 {minutes:02d}分 {seconds:02d}.{milliseconds:03d}秒")
            write_log_append('--')
            # 輸出花費時間檔案 
            Output_Inversion_Log = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_03_Inversion_Log.csv')+'.time'
            #write_log_append('儲存time檔案...')
            with open(Output_Inversion_Log, 'a', encoding='utf-8') as f:
                #--
                line = f"花費時間: {hours:02d}時 {minutes:02d}分 {seconds:02d}.{milliseconds:03d}秒"  
                f.write(line+"\n")
                #--
            #write_log_append('儲存time檔案...完成!')
            #--
            #--------------------------------------------
        write_log_append(f'逆推進度({Current_Remove_Runs}/{Inversion_Remove_Data_Times})...完成!')  
        #--
        # 預設方式儲存結果
        Output_saveResult_FolderName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{temp_json_data["Output_MainFileName"]}_R{Current_Remove_Runs:02d}_L{Current_lambda_number:02d}_I{mgr.inv.iter:02d}')
        mgr.saveResult(Output_saveResult_FolderName)
        write_log_append("**使用管理器運行逆推...完成!")
        #--
    #--------------------------------------------
    #--------------------------------------------
    # 繪製收斂曲線圖
    #--
    Output_Inversion_Log = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_03_Inversion_Log.csv')
    write_log_append('載入 Output_Inversion_Log 檔案...')
    try:
        #--------------------------------------------
        # 使用 np.loadtxt 載入 CSV 檔案 並強制所有內容為字串 (不含標頭)
        # dtype='str' 或 dtype=object：強制 NumPy 將每個單元格視為字串。
        # delimiter=','：指定逗號分隔。
        # skiprows=1：跳過標頭行。
        Inversion_Log_Matrix = np.loadtxt(
            Output_Inversion_Log, 
            dtype='str',
            delimiter=',', 
            skiprows=1,
            encoding='utf-8'
        )    
        #--------------------------------------------
        # 獨立載入標頭
        # 讀取整個檔案的第一行
        with open(Output_Inversion_Log, 'r', encoding='utf-8') as f:
            header_line = f.readline().strip()
        Inversion_Log_DataHeader = header_line.split(',')
        #--------------------------------------------
    except FileNotFoundError:
        write_log_append(f"錯誤：找不到檔案 {Input_v299Scsv_FileName}")
        exit(1) # 回傳1表示一般性錯誤
    except Exception as e:
        write_log_append(f"程式運行時發生錯誤: {e}")
        exit(1) # 回傳1表示一般性錯誤
    #--
    # 強制確保 Inversion_Log_Matrix 是 numpy 陣列
    Inversion_Log_Matrix = np.array(Inversion_Log_Matrix)
    # 如果只有一列數據導致維度變成 (N,)，將其轉回 (1, N) 或 (M, N)
    if Inversion_Log_Matrix.ndim == 1:
        Inversion_Log_Matrix = Inversion_Log_Matrix.reshape(1, -1)    
    write_log_append('載入 Output_Inversion_Log 檔案...完成!')
    #--
    PNG_DPI = 100
    PNG_Width = 1280
    PNG_Height = 720    
    Output_PNG_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_04_Convergence_Curve.png')
    #--
    # 建立畫布
    fig, ax = plt.subplots(figsize=((PNG_Width / PNG_DPI, PNG_Height / PNG_DPI)))
    # 轉換成數值矩陣以便繪圖
    Main_FileName_list = Inversion_Log_Matrix[:, Inversion_Log_DataHeader.index('Main_FileName')]
    Remove_Runs_list = Inversion_Log_Matrix[:, Inversion_Log_DataHeader.index('Remove_Runs')].astype(int)
    Iteration_list = Inversion_Log_Matrix[:, Inversion_Log_DataHeader.index('Iteration')].astype(int)
    RRMS_list = Inversion_Log_Matrix[:, Inversion_Log_DataHeader.index('RRMS[%]')].astype(float)
    Chi2_list = Inversion_Log_Matrix[:, Inversion_Log_DataHeader.index('Chi2')].astype(float)
    # 取出獨立的 Remove_Runs 清單，並產生顏色清單
    Unique_Remove_Runs_list = np.unique(Remove_Runs_list)
    Unique_Remove_Runs_colors = [plt.cm.viridis(i) for i in np.linspace(0, 1, len(Unique_Remove_Runs_list))]
    # 繪製折線圖
    for Remove_Runs_ID, Remove_Runs_Color in zip(Unique_Remove_Runs_list, Unique_Remove_Runs_colors):
        mask = (Remove_Runs_list == Remove_Runs_ID)
        mask2 = (Iteration_list[mask] ==0)
        # 原本可能會是[0,1,0,1]
        #ax.plot(Iteration_list[mask], RRMS_list[mask], color=Remove_Runs_Color, alpha=0.5, linewidth=1.2, label=f'Remove Runs #{Remove_Runs_ID}, IterCount={np.max(Iteration_list[mask])}')
        # 就要修改為[0,1,2,3]來繪圖
        Iteration_list[mask] = np.arange(len(Iteration_list[mask]))
        ax.plot(Iteration_list[mask], RRMS_list[mask], color=Remove_Runs_Color, alpha=0.5, linewidth=1.2, label=f'Remove Runs #{Remove_Runs_ID}, IterCount={np.max(Iteration_list[mask])}')
        ax.scatter(Iteration_list[mask][mask2], RRMS_list[mask][mask2], facecolor='none', marker='o',s=100, edgecolors='black', zorder=5)
    # 繪製散點圖
    if np.max(Chi2_list) > np.min(Chi2_list):
        scatter_circle = ax.scatter(Iteration_list[Chi2_list>=1.0], RRMS_list[Chi2_list>=1.0], 
                                   c=(Chi2_list[Chi2_list>=1.0]), 
                                   cmap='RdYlGn_r', vmin=1.0,
                                   marker='o', edgecolors='black', s=50, zorder=3, alpha=0.6,
                                   label=r'$\chi^2 \geq 1$ (Underfit)')
        scatter_square = ax.scatter(Iteration_list[Chi2_list<1.0], RRMS_list[Chi2_list<1.0], 
                                   c=(Chi2_list[Chi2_list<1.0]), 
                                   cmap='RdYlGn', vmax=1.0,
                                   marker='s', edgecolors='black', s=50, zorder=4, alpha=0.6,
                                   label=r'$\chi^2 < 1$ (Overfit)')
    else:
        scatter_circle = ax.scatter(Iteration_list[Chi2_list>=1.0], RRMS_list[Chi2_list>=1.0], 
                                   c=(Chi2_list[Chi2_list>=1.0]), 
                                   cmap='RdYlGn_r',
                                   marker='o', edgecolors='black', s=50, zorder=3, alpha=0.6,
                                   label=r'$\chi^2 \geq 1$ (Underfit)')
        scatter_square = ax.scatter(Iteration_list[Chi2_list<1.0], RRMS_list[Chi2_list<1.0], 
                                   c=(Chi2_list[Chi2_list<1.0]), 
                                   cmap='RdYlGn',
                                   marker='s', edgecolors='black', s=50, zorder=4, alpha=0.6,
                                   label=r'$\chi^2 < 1$ (Overfit)')
    # 設定繪圖參數
    ax.set_title('Iteration vs RRMS Log Plot', pad=20)
    ax.set_title(f"{os.path.basename(Main_FileName_list[0])} Convergence Curve "+f"\nData EstError={Data_Settings_Relative_Error_Percentage}%, "+rf"$\lambda$={Inversion_lam_list}", fontsize=14)
    ax.set_xlabel('Iteration')
    ax.set_ylabel('RRMS [%]')
    ax.set_yscale('log')
    #ax.yaxis.set_major_formatter(plt.matplotlib.ticker.ScalarFormatter(useMathText=False))
    #ax.yaxis.get_major_formatter().set_scientific(False)
    ax.yaxis.set_major_formatter(plt.matplotlib.ticker.ScalarFormatter())
    #ax.yaxis.set_minor_formatter(plt.matplotlib.ticker.ScalarFormatter())
    ax.yaxis.set_minor_formatter(plt.matplotlib.ticker.FormatStrFormatter('%g'))    
    ax.yaxis.get_major_formatter().set_scientific(False)
    #ax.yaxis.get_minor_formatter().set_scientific(False)
    #ax.yaxis.set_major_formatter(plt.matplotlib.ticker.FuncFormatter(lambda y, _: f'{y:g}'))
    #ax.yaxis.get_minor_formatter(plt.matplotlib.ticker.FuncFormatter(lambda y, _: f'{y:g}'))
    ax.grid(True, which='both', linestyle=':', alpha=0.4)
    ax.legend(loc='upper right')
    #--
    # 填入版本資訊
    fig.text(0.98, 0.01, ERTMaker_Info, ha='right', va='bottom', fontsize=8, color='gray')
    #--
    # 設置對齊的colorbar
    plt.tight_layout()
    cbar1 = fig.colorbar(scatter_circle, ax=ax, shrink=0.49, pad=0.01, anchor=(0, 1.0), panchor=False)
    cbar1.ax.set_title(r'  $\chi^2$', fontsize=9, pad=10)
    cbar1_pos = cbar1.ax.get_position(original=False).bounds
    # 追加新的軸來放另一隻colorbar
    cax = fig.add_axes(ax.get_position().bounds)
    cbar2 = fig.colorbar(scatter_square, ax=cax, shrink=0.49, pad=0.01, anchor=(0, 0.0), panchor=False)
    cbar2_pos = cbar2.ax.get_position(original=False).bounds
    # 再次設定正確的位置
    cax.set_position(ax.get_position().bounds)
    # 對齊第一個colorbar
    new_cbar2_pos = [cbar1_pos[0], cbar2_pos[1], cbar2_pos[2], cbar2_pos[3]]
    cbar2.ax.set_position(new_cbar2_pos)
    # 隱藏沒用的新的軸
    cax.set_axis_off()
    #--
    #write_log_append(f'儲存 圖片...')
    if os.path.dirname(Output_PNG_FileName): # 防止空路徑報錯
        os.makedirs(os.path.dirname(Output_PNG_FileName), exist_ok=True)
    plt.savefig(Output_PNG_FileName, dpi=temp_PNG_DPI)
    plt.close()
    #write_log_append(f'儲存 圖片...完成!')
    #--------------------------------------------

#--------------------------------------------
write_log_append('--')
#--------------------------------------------
# 取得運行結束時間
program_end_time = datetime.now()
# 計算時間差 (timedelta)
time_difference = program_end_time - program_start_time
total_seconds = time_difference.total_seconds()
hours = int(total_seconds // 3600)
minutes = int((total_seconds % 3600) // 60)
seconds = int(total_seconds % 60)
milliseconds = int((total_seconds % 1) * 1000)
write_log_append(f"程式結束運行...時間: {program_end_time.strftime('%Y-%m-%d %H:%M:%S')}")
write_log_append(f"最終花費時間: {hours:02d}時 {minutes:02d}分 {seconds:02d}.{milliseconds:03d}秒")
write_log_append('--')
# 輸出花費時間檔案 
Output_Inversion_Log = os.path.join(temp_json_data['OutputMainFolderPath'],f'{Main_FileName}_03_Inversion_Log.csv')+'.time'
#write_log_append('儲存time檔案...')
with open(Output_Inversion_Log, 'a', encoding='utf-8') as f:
    #--
    line = f"最終花費時間: {hours:02d}時 {minutes:02d}分 {seconds:02d}.{milliseconds:03d}秒"  
    f.write(line+"\n")
    #--
#write_log_append('儲存time檔案...完成!')
#--
# 移動Log檔案到輸出資料夾
Output_Log_FileName = os.path.join(temp_json_data['OutputMainFolderPath'],'ERTMaker_Inversion2D.log')
if os.path.dirname(Output_Log_FileName): # 防止空路徑報錯
    os.makedirs(os.path.dirname(Output_Log_FileName), exist_ok=True)
# 移動檔案
shutil.move('ERTMaker_Inversion2D.log', Output_Log_FileName)
#--------------------------------------------
