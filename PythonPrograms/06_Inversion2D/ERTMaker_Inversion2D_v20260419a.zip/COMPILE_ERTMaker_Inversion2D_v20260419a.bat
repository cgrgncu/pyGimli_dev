..\PythonEnv\Python.exe -m py_compile ERTMaker_Inversion2D_v20260419a.py
PAUSE