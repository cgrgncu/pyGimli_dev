.\PythonEnv\Python.exe -m py_compile ERTMaker_v299ScsvToUrf_v20260217a.py
PAUSE