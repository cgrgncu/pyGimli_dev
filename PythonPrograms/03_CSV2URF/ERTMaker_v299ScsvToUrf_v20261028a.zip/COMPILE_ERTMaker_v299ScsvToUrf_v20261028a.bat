.\PythonEnv\Python.exe -m py_compile ERTMaker_v299ScsvToUrf_v20261028a.py
PAUSE